# 沛城C语言编码规范

> 来源：`D:/AI/【规范】沛城C语言编码规范.pdf`。本文件供 `通用-代码审查-模版二` 的“编码规范检查”模块引用。

> 处理说明：正文按 PDF 文本层提取；PDF 中包含图片对象的页面已补充“图片内容文字化补充”，避免审查时遗漏截图里的规范信息。

## 审查使用说明

- 做编码规范检查时，优先按“规则索引”定位违反条目，再结合“PDF正文按页提取”核对原文语境。
- 表格中的“规范违反条目”建议填写规则编号和标题，例如 `4.2 规则-大括号风格`。
- 对图片页中的结构、设置步骤、代码片段触发方式、嵌套深度计算和 inline 限制，应以“图片内容文字化补充”为准一并检查。
- 没有被本规范覆盖但确有维护风险的问题，可在报告中标为“通用C代码建议项”，不要冒充规范原文。

## 规则索引

| 编号 | 条目 | 审查要点 | 常见触发点 |
|---|---|---|---|
| 1.2 | 代码总体原则 | 清晰第一、简洁为美、统一风格；优先写给人读，再让机器执行。 | 逻辑绕、重复堆叠、风格与项目不一致。 |
| 2.1 | .h头文件结构 | 头文件只放对外声明，建议顺序为文件头注释、头文件保护宏、头文件引用、对外宏定义、对外类型定义、对外函数声明。 | 内部声明放进头文件、缺少保护宏、头文件职责混乱。 |
| 2.2 | .c源文件结构 | 源文件放实现细节，建议顺序为文件头注释、头文件引用、模块内宏、模块内类型、函数声明、静态变量、函数定义。 | 实现细节外泄、静态变量和函数散落、文件结构难读。 |
| 3.1 | 规则-通用命名 | 使用 snake_case；名称要有描述性；避免无意义编号和非通用缩写；禁止单字符业务名称，循环变量除外。 | a、b、tmp、flag0、BMS_ctrl 这类难以表达业务含义的命名。 |
| 3.2 | 规则-具体命名 | 变量小写下划线；宏/常量大写下划线；结构体 _t、枚举 _e、联合体 _u；文件名小写下划线；对外接口带模块前缀。 | 类型后缀缺失、文件名大小写混杂、对外接口没有模块归属。 |
| 3.3 | 建议-常用缩写 | 只使用规范列出的或行业公认缩写，如 bms、soc、soh、can、adc、cur、vol、cfg、err、init 等。 | 开发者自造缩写导致审查和维护困难。 |
| 4.1 | 规则-缩进与空格 | 4 个空格缩进，TAB 转 4 空格；关键字与括号之间加空格；逗号、for 分号后加空格；运算符前后加空格；注释符后加空格。 | 2 空格缩进、if(a)、return(0)、a+b、//注释 等格式问题。 |
| 4.2 | 规则-大括号风格 | 采用 Allman 风格，左右大括号单独一行；if/for/do/while 即使一行也加大括号；case 内定义变量时必须加大括号。 | K&R 风格、单行 if 无大括号、case 内变量作用域不清。 |
| 4.3 | 规则-行长度 | 每行不超过 120 字符；超长时在逗号、分号或低优先级操作符处换行，续行缩进 4 空格。 | 长函数调用、长表达式、长注释超过 120 列。 |
| 4.4 | 规则-嵌套深度 | 控制结构嵌套深度不超过 4；if/else if/else 同组计 1 层；switch 计 1 层，case 内逻辑从 2 层起。 | 多层 if、循环内套 switch、异常逻辑向右漂移。 |
| 4.5 | 建议-行间隔 | 相关代码保持紧凑，不同逻辑块之间用空行分隔。 | 代码块粘连或空行过多影响阅读。 |
| 4.6 | 建议-一行只写一条语句 | 每行只写一条可执行语句，避免多个赋值、判断或函数调用挤在一行。 | a=1; b=2; 这种紧凑写法。 |
| 5.1 | 建议-注释通用规范 | 注释解释意图、约束、单位、异常条件和风险，不重复代码字面含义。 | 注释缺失、注释与代码不一致、只翻译代码。 |
| 5.2 | 建议-文件头注释 | 文件头应包含版权、功能描述、修改记录等信息。 | 新增文件缺少用途说明和修改记录。 |
| 5.3 | 建议-函数注释 | 对外函数和复杂函数写清功能、参数、返回值、关键约束。 | 接口语义不明、错误码含义不清。 |
| 5.4 | 建议-代码注释 | 单行注释用 //，多行注释用 /* */；注释放在代码上方或右侧；行内注释与代码至少两个空格，// 后一个空格。 | 行内注释贴太近、注释位置混乱。 |
| 6.1 | 建议-函数单一职责 | 函数只做一件事，复杂流程拆成多个职责明确的小函数。 | 一个函数同时做采集、换算、告警、上报、存储。 |
| 6.2 | 规则-函数长度不超过50行 | 函数非空非注释行不超过 50 行，过长应拆分。 | 初始化、协议解析、状态机函数过长。 |
| 6.3 | 建议-参数个数不超过5个 | 参数过多时用结构体封装相关配置，降低调用顺序出错风险。 | 函数 6 个及以上参数，且参数类型相近。 |
| 6.4 | 规则-圈复杂度限制 | 单个函数圈复杂度不超过 9，文件平均每个函数圈复杂度不超过 5。 | 大量 if/else、switch/case、循环、&&、||、?: 叠加。 |
| 6.5 | 建议-重复代码提炼函数 | 重复逻辑应抽出函数或公共辅助逻辑。 | 复制粘贴同类判断、同类参数校验。 |
| 6.6 | 规则-外部函数入参合法性检查 | 未使用 static 修饰的外部函数，需要检查入参合法性。 | 对外接口直接解引用指针、未校验索引和长度。 |
| 6.7 | 规则-错误返回码全面处理 | 调用有错误码的函数后必须处理返回值。 | 忽略初始化、读写、通信函数返回码。 |
| 6.8 | 规则-不变指针参数使用const | 函数不会修改的指针形参加 const。 | 只读 buffer、配置结构体未加 const。 |
| 6.9 | 规则-非参数输入有效性检查 | 检查数据文件、公共变量、全局状态等非参数输入的有效性。 | 依赖全局状态但未检查初始化和范围。 |
| 6.10 | 规则-内部函数使用static | 仅文件内部使用的函数增加 static 修饰。 | 内部辅助函数暴露为外部符号。 |
| 7.1 | 规则-局部变量大小不超过256字节 | 避免在栈上定义超过 256 字节的大对象。 | 函数内大数组、大结构体局部变量。 |
| 7.2 | 规则-防止差1错误 | 循环边界、数组索引、长度计算要防止 off-by-one。 | <= 最大下标、长度和索引混用。 |
| 7.3 | 规则-整数安全 | 关注整数溢出、回卷、符号混用、范围钳位和单位一致性。 | 计数器自增无上限、abs 误用、无符号减法回卷。 |
| 7.4 | 规则-字符串操作安全 | 字符串复制、拼接、格式化要检查目标缓冲区长度和结尾 0。 | strcpy/sprintf 无长度限制、memcpy 长度来自外部未校验。 |
| 7.5 | 规则-if必须加else，switch必须有default | if 语句必须加 else 分支，卫语句例外；switch 必须有 default。 | 异常路径未闭合、枚举扩展后未兜底。 |
| 7.6 | 规则-禁止goto | 禁止使用 goto 语句。 | 用 goto 跳转清理或跳出多层逻辑。 |
| 7.7 | 规则-内存申请后必须释放 | malloc/calloc/realloc 后所有退出路径都要释放。 | 错误分支提前 return 导致泄漏。 |
| 7.8 | 规则-指针或内存操作检查索引 | 数组、指针偏移、内存访问前检查索引和长度。 | 外部传入 index 直接访问数组。 |
| 7.9 | 规则-禁止引用已释放内存 | free 后不得继续访问，必要时置 NULL。 | use-after-free、悬空指针复用。 |
| 8.1 | 规则-中断中只做最小必要操作 | 中断里不能延时或执行耗时操作，只缓存数据、置标志、清中断。 | ISR 内做复杂计算、通信、等待、告警处理。 |
| 8.2 | 建议-合理使用inline函数 | 高频调用且小于 10 行的小函数可用 static inline；避免全局 inline。 | 宏能改成类型安全的小内联函数，或 inline 函数过大。 |
| 9.1 | 规则-多语句宏do-while(0) | 多语句宏使用 do { ... } while (0) 包裹，while (0) 后不在宏定义内部额外加分号。 | 宏展开破坏 if/else 结构。 |
| 9.2 | 规则-宏表达式完备括号 | 宏定义表达式和参数都加括号。 | SQUARE(x) x*x 这类优先级问题。 |
| 9.3 | 规则-宏参数调用限制 | 带参数宏调用时，不允许传入带操作符的参数。 | 宏调用传入 a + b、i++ 导致展开副作用。 |
| 9.4 | 建议-优先函数代替宏 | 除非必要，应尽量用函数替代宏。 | 复杂逻辑写在宏里导致调试困难。 |
| 9.5 | 建议-宏不改变程序流 | 宏定义中尽量不使用 return、continue、break 等改变程序流的语句。 | 宏调用点看不出函数会提前返回。 |
| 10.1 | 规则-文件统一UTF-8编码 | 代码文件统一使用 UTF-8 编码。 | 新增文件编码不一致导致中文乱码。 |
| 10.2 | 规则-防止除零 | 进行除法运算前检查除数是否为 0。 | 外部采样值、配置值、计数值直接作除数。 |
| 10.3 | 规则-不能使用魔鬼数字 | 不能直观理解的数字要定义宏、枚举或补注释。 | 协议 ID、阈值、延时、倍率裸写。 |
| 10.4 | 规则-BIT位赋予意义 | 单个 BIT 位要命名，多 BIT 位共同使用时要加注释说明含义。 | FLAG_0、FLAG_1 或位域含义不明。 |
| 10.5 | 规则-严禁未初始化变量作为右值 | 变量作为右值前必须初始化。 | 局部变量在条件分支未赋值即使用。 |
| 10.6 | 建议-就近初始化变量 | 变量在首次使用前初始化，初始化位置离使用位置越近越好。 | 函数开头集中声明大量变量但很久后才使用。 |
| 10.7 | 建议-用括号明确表达式顺序 | 复杂表达式用括号表达意图，减少对默认优先级的依赖。 | 混合 &&、||、位运算、移位和比较。 |
| 10.8 | 建议-类型定义使用typedef | 结构体、枚举等类型建议用 typedef 提升可读性。 | 重复书写 struct xxx。 |
| 10.9 | 建议-优先使用位域提升可读性 | 嵌入式或硬件状态场景可用位域表达多个标志位，跨平台场景谨慎使用。 | 多 BIT 位用纯数字掩码表达，含义难读。 |

## 图片内容文字化补充

### 第5页 .h 头文件结构图

图片展示头文件总体组织：文件头注释、头文件保护宏、头文件引用、宏定义、类型定义、函数声明。图片说明一级类别注释左右各约 40 个星号，二级类别注释左右各约 20 个星号，后续层级继续减半。

### 第6页 cell_voltage.h 示例图

图片给出头文件示例：文件头注释包含 copyright、功能描述、修改记录；随后是头文件保护宏、头文件引用、对外宏定义，并用模块化大注释分隔。

### 第7页 .c 源文件结构图

图片展示源文件总体组织：文件头注释、头文件引用、模块内宏定义、模块内类型定义、函数声明、模块内静态变量定义、函数定义。

### 第16页 缩进设置与正反示例图

图片强调 VSCode 中 Tab Size 设置为 4；正面示例使用 4 空格缩进，反面示例使用 2 空格。预处理指令通常顶格，多层嵌套预处理可缩进 4 格。

### 第21页 120 列垂直标尺设置图

图片展示在 VSCode 设置中搜索 Editor: Rulers，进入 settings.json，添加 editor.rulers 配置：column 为 120，color 为 #ff9900，用垂直标尺提示行长限制。

### 第23页 嵌套深度计算图

图片说明嵌套深度是当前代码块被控制结构直接或间接包裹的层数；if/else if/else 同组计 1 层，嵌套 if 才加 1；每嵌套一层循环加 1；switch 本身计 1 层，case/default 内逻辑从 2 层开始；函数调用、宏和条件编译、普通花括号作用域不计入运行时嵌套深度。

### 第33页 VSCode 全局代码片段创建图

图片展示创建全局代码片段步骤：设置齿轮、代码片段、新建全局代码片段文件、输入文件名，随后生成 .code-snippets 模板。

### 第34页 代码片段字段说明图

图片说明代码片段字段：scope 表示适用语言，不写则适用于所有语言；prefix 是触发关键词；body 是片段内容且支持多行；description 是可选说明。示例包含 function comment 和 file comment 两类片段。

### 第36页 代码注释与片段触发图

图片展示输入 fun 可弹出函数注释代码片段并快速生成函数注释；单行注释使用 //，多行注释使用 /* */；注释放在代码上方或右侧；行内 // 与代码至少两个空格，// 与注释正文之间一个空格。

### 第88页 static inline 说明图

图片说明高频调用小函数可使用 static inline；相比宏有类型检查、减少展开陷阱且更便于调试；仅使用 static inline，避免全局 inline 导致代码膨胀，函数行数建议不超过 10 行。

## PDF正文按页提取

### 第1页

【规范】沛城C语言编码规范

### 第2页

目录
1. 规范定制说明
1.1 前言
1.2 代码总体原则
1.2.1 清晰第一
1.2.2 简洁为美
1.2.3 统一风格
1.3 规则说明
2. 总体文件组织设计结构
2.1 .h头文件结构
2.2 .c源文件结构
3. 命名规范
3.1 规则-通用规范
3.2 规则-具体命名
3.3 建议-常用缩写
4. 编码风格
4.1 规则-缩进与空格
4.2 规则-大括号风格
4.3 规则-行长度
4.4 规则-嵌套深度
4.5 建议-行间隔
4.6 建议-一行只写一条语句
5. 注释规范
5.1 建议-通用规范
5.2 建议-文件头注释
5.3 建议-函数注释
5.4 建议-代码注释
6. 函数规范
6.1 建议-函数应单一职责，只做一件事
6.2 规则-函数长度不超过50行（非空非注释行）

### 第3页

6.3 建议-参数个数不超过5个
6.4 规则-单个函数圈复杂度不超过9，整体文件的平均每个函数圈复杂…
6.5 建议-重复代码应该尽可能提炼成函数
6.6 规则-外部函数（未使用static修饰），需要对函数入参的合法性进…
6.7 规则-对函数的错误返回码要全面处理
6.8 规则-函数不变指针参数使用const
6.9 规则-检查函数所有非参数输入的有效性，如数据文件、公共变量等
6.10 规则-在源文件范围内声明和定义的所有函数，除非是供外部调用…
7. 安全性
7.1 规则-局部变量大小不能超过256字节
7.2 规则-编程时，要防止差1错误
7.3 规则-整数安全
7.4 规则-字符串操作安全
7.5 规则-if语句必须加上else分支（卫语句例外，其他场景均需要）；s…
7.6 规则-禁止使用goto语句
7.7 规则-内存申请后必须有对应释放操作
7.8 规则-指针或内存操作必须检查索引的有效性
7.9 规则-禁止引用已经释放的内存空间
8. 代码效率
8.1 规则-中断中不能执行延时或其他耗时操作，只做最小必要操作
8.2 建议-合理使用 inline 函数（减少函数调用栈开销）
9. 宏定义
9.1 规则-多语句宏使用do-while(0)包裹（注意：最后的while (0)后没有…
9.2 规则-用宏定义表达式时，要使用完备的括号
9.3 规则-使用带参数的宏时，不允许在宏调用时，传入带操作符的参数
9.4 建议-除非必要，应尽可能使用函数代替宏
9.5 建议-宏定义中尽量不使用return、continue、break等改变程序流…
10. 其他基本规范
10.1 规则-文件统一使用utf-8编码
10.2 规则-进行除法运算时需要防止除零操作
10.3 规则-不能使用魔鬼数字，不能直观理解的数字需要加上注释，特…
10.4 规则-BIT位使用时需要赋予意义，多BIT位共同使用时需要添加注释
10.5 规则-严禁使用未经初始化的变量为右值

### 第4页

1. 规范定制说明
1.1 前言
为提高产品代码质量，指导广大软件开发人员编写出简洁、可维护、可靠、可测试、高
效、可移植的代码，编写了本规范
1.2 代码总体原则
1.2.1 清晰第一
清晰性是易于维护、易于重构的程序必须具备的特征。
“程序必须为阅读它的人而编写，只是顺便用于机器执行” --Harold Abelson 和 Gerald Jay
Sussman
1.2.2 简洁为美
简洁就是易于理解并且易于实现。代码越长越难以看懂，也就越容易在修改时引入错误。写
的代码越多，意味着出错的地方越多，也就意味着代码的可靠性越低。因此，我们提倡大家
通过编写简洁明了的代码来提升代码可靠性。
1.2.3 统一风格
产品所有人共同使用同一种风格所带来的好处，远远超出为了统一而付出的代价
1.3 规则说明
10.6 建议-在首次使用前初始化变量，初始化的地方离使用的地方越近…
10.7 建议-用括号明确表达式的操作顺序，避免过分依赖默认优先级
10.8 建议-类型定义
10.9 建议-优先使用位域提升可读性
章节
软件助理工程师
软件工程师及
2.总体文件组织设计结构
必须掌握
必须掌握
3.命名规范
必须掌握
必须掌握

### 第5页

2. 总体文件组织设计结构
2.1 .h头文件结构
头文件中放置的应该都是对外的声明，内部使用的声明不要放在里面；大体上一般包含有：
注：
1) 这里*比较多，主要考虑可以跟其他注释区分开，凸显出模块注释
2) 如果有二级类别注释，减少*的数量，当前归档，一级类别注释左右各40个*，二级类别注
释左右各20个*，依次减少二分之一，如下图
4.编码风格
必须掌握
必须掌握
5.注释规范
必须掌握
必须掌握
6.函数规范
需要了解
必须掌握
7.安全性
需要了解
必须掌握
8.代码效率
需要了解
必须掌握
9.宏定义
必须掌握
必须掌握
10.其他基本规范
必须掌握
必须掌握

### 第6页

示例：
cell_voltage.h
复制代码
/**
 * Copyright (c) 2025, Company Name
 * 功能描述: 电芯电压采集模块核心接口声明
 * 修改记录:
 *   修改人    修改日期    修改内容
 *   -----    ----------  ------------
 *   name     yyyy-mm-dd  初始版本，完成基础接口定义
 *   name     yyyy-mm-dd  新增xx函数，修复xx参数定义错误
 */
/**************************************** 头文件保护宏
****************************************/
#ifndef _CELL_VOLTAGE_H
#define _CELL_VOLTAGE_H
/**************************************** 头文件引用
****************************************/
#include "bms_common.h"
/**************************************** 宏定义（对外宏定义）
***************************************/
#define CELL_MAX_NUM        16      // 最大电芯数量（根据硬件配置修改）
#define CELL_SAMPLE_FREQ_HZ 100     // 采集频率(Hz)

### 第7页

2.2 .c源文件结构
源文件放置具体的实现细节，大体上一般包含有：
/**************************************** 类型定义（对外类型定义）
*********************************/
// 电芯状态枚举（对外枚举）
typedef enum
{
    CELL_STATE_NORMAL,       // 正常
    CELL_STATE_OVERVOLTAGE,  // 过压
    CELL_STATE_UNDERVOLTAGE, // 欠压
    CELL_STATE_DISCONNECTED  // 断线（采集异常）
} CELL_State_xxx_e;
/**************************************** 函数声明（对外接口）
************************************/
/**
 * 函数功能  初始化电芯电压采集模块
 * 参数     init_param: 初始化参数（如采集通道、基准电压等，具体类型见.c实
现）
 * 返回值   BMS_error_e: 错误码（SUCCESS/ERR_HW_INIT/ERR_CHANNEL_INVALID
等）
 */
BMS_error_e CELL_voltage_init(void *init_param);
#
dif /*
CELL VOLTAGE H */

### 第8页

示例：
cell_voltage.c
复制代码
/**
 * Copyright (c) 2025, Company Name
 * 功能描述: 电芯电压采集模块核心逻辑实现
 * 修改记录:
 *   修改人    修改日期    修改内容
 *   -----    ----------  ------------
 *   name     yyyy-mm-dd  初始版本，完成核心逻辑实现
 *   name     yyyy-mm-dd  优化xx算法效率
 */
/**************************************** 头文件引用
****************************************/
#include "cell_voltage.h"
/**************************************** 模块内宏定义
****************************************/
#define CELL_VOLTAGE_MIN    2800    // 最小电芯电压(mV)，低于此值触发欠压
#define CELL_VOLTAGE_MAX    3600    // 最大电芯电压(mV)，高于此值触发过压
/**************************************** 模块内类型定义
****************************************/
// 模块内部工作状态
typedef enum
{
    CELL_MODULE_STATE_UNINIT,    // 未初始化
    CELL_MODULE_STATE_INITED,    // 已初始化（未开始采集）
    CELL_MODULE_STATE_SAMPLING,  // 正在采集
    CELL_MODULE_STATE_ERROR      // 模块错误（如硬件故障）
} CELL_module_state_e;
/**************************************** 函数声明
****************************************/
static void CELL_voltage_adc_irq_handler(void);  // ADC中断服务函数（采集
完成回调）
/**************************************** 模块内静态变量定义
****************************************/
static CELL_module_state_e g_cell_module_state =
CELL_MODULE_STATE_UNINIT;

### 第9页

3. 命名规范
3.1 规则-通用规范
使用单词和下划线组合（snake_case）
示例
复制代码
名称应具有清晰描述性，避免数字编号（除非逻辑上的确需要编号），避免缩写（除非是
广泛认可的缩写）
复制代码
/**************************************** 函数定义
****************************************/
/**
 * 函数功能：初始化电芯电压采集模块
 * 参   数： init_param: 初始化参数（如采集通道、基准电压等，具体类型见.c实
现）
 * 返回值：  BMS_Error_e: 错误码（SUCCESS/ERR_HW_INIT/ERR_CHANNEL_INVALID
等）
 */
BMS_error_e CELL_voltage_init(void)
{
    CELL_module_state_e state = CELL_MODULE_STATE_UNINIT;

    //...实现细节
    return BMS_SUCCESS;
}
●
uint8_t cell_count;
static uint8_t CELL_temperature_detection(uint8_t cell_number);
●
//=========== 正面案例
// BIT位定义直接体现物理意义，与BMS功能关联
#define BMS_FLAG_CELL_OVERVOLT  (1 << 0)  // 电芯过压（单BIT含义）
#define BMS_FLAG_OVERCURRENT    (1 << 1)  // 过流（单BIT含义）
#define BMS_FLAG_CELL_UNDERVOLT (1 << 2)  // 电芯欠压（单BIT含义）
#define BMS_FLAG_UNDERCURRENT   (1 << 3)  // 欠流（单BIT含义）

### 第10页

示例
复制代码
禁止使用单个字符作为名称（循环变量除外）
复制代码
// 仅使用广泛认可的缩写（BMS/SOC/SOH/CAN/ADC），其余无缩写
void BMS_control(uint16_t charge_voltage, uint16_t charge_current,
uint8_t cell_temperature)
{
    uint8_t soc = get_battery_soc(); // SOC：行业广泛认可的剩余电量缩写
    uint8_t soh = get_battery_soh(); // SOH：行业广泛认可的健康状态缩写
    uint16_t adc_value = read_adc_channel(3); // ADC：技术领域广泛认可的缩
写
    send_can_message(0x123, adc_value); // CAN：车载通信广泛认可的缩写
}
//=========== 反面案例
// BIT位定义无明确意义，仅用数字标识
#define BMS_FLAG_0 (1 << 0)
#define BMS_FLAG_1 (1 << 1)
#define BMS_FLAG_2 (1 << 2)
#define BMS_FLAG_3 (1 << 3)
// 混合无意义缩写，可读性极差（bms已认可，但cv/cc/ct均为非通用缩写）
void BMS_ctrl(uint16_t cv, uint16_t cc, uint8_t ct)
{
    // cv=充电电压，cc=充电电流，ct=电芯温度（仅开发者自己能懂）
}
●
//=========== 正面案例
// 故障标记命名清晰（故障码，无歧义）
static uint8_t g_fault_code = 0;
// 函数名语义完整（电芯温度检测）
uint8_t BMS_cell_temperature_detection(uint8_t cell_number) // 函数参数命
名明确（电芯编号）
{
    // 局部业务变量命名精准（电芯温度）
    uint16_t cell_temperature = read_cell_temperature(cell_number);
    // 返回值变量命名清晰（检测结果）
    uint8_t detection_result = 0;

### 第11页

示例
复制代码
    if (cell_temperature > 60)
    {
        g_fault_code = 1; // 故障码赋值，语义明确
        detection_result = 1;
    }
    return detection_result;
}
// 允许场景：循环变量i/j为通用用法，合规
void BMS_scan_all_cells(void)
{
    // i为循环临时变量，允许
    for (uint8_t i = 0; i < CELL_MAX_NUM; i++)
    {
        // code
    }
}
//=========== 反面案例
// 故障标记用单个字符（f=故障码，无法区分是“故障”还是“标志”）
uint8_t f = 0;
// 函数名用单个字符（c=电芯检测，无上下文无法理解）
uint8_t c(uint8_t n)
{
    // 函数参数用单个字符（n=电芯编号，易混淆为“数量/次数”）
    // 局部业务变量用单个字符（t=电芯温度，易混淆为“时间/阈值”）
    uint16_t t = read_cell_temp(n);
    // 返回值变量用单个字符（r=检测结果，无语义）
    uint8_t r = 0;
    if (t > 60)
    {
        f = 1; // 故障标记赋值，单个字符变量溯源困难
        r = 1;
    }
    return r;
}

### 第12页

3.2 规则-具体命名
类型定义中，结构体使用 _t 后缀，枚举使用 _e 后缀， 联合体使用 _u 后缀；
示例：
复制代码
类型
命名规则
示例
变量
小写+下划线
buffer_size
常量
大写+下划线
MAX_BUFFER_SI
函数
对外接口函数：大写的模块名前缀+其他小
写+下划线；内部函数定义可以全小写也可
以加大写模块名前缀
LED_get_led_sta
get_led_state()
类型定义
大写的模块名前缀+其他小写+下划线+_t后
缀/_e后缀/_u后缀；内部类型定义可以全小
写也可以加大写模块名前缀
CELL_voltage_da
voltage_data_t
全局变量/静态全局变量
g_前缀+小写+下划线（g_前缀建议使用，
不做规则强制）
g_local_addr
局部静态变量
s_前缀+小写+下划线（s_前缀建议使用，
不做规则强制）
s_real_soc
宏定义
大写+下划线
MAX_BUFFER_SI
枚举定义
大写+下划线
LED_STATE_OFF
文件名
小写+下划线
uart_log.c
uart_log.h
●
// 宏定义
#define MAX_BUFFER_SIZE 128
// 电芯状态枚举
typedef enum
{
    CELL_STATE_NORMAL,       // 正常
    CELL_STATE_OVERVOLTAGE,  // 过压

### 第13页

CELL_STATE_UNDERVOLTAGE, // 欠压
    CELL_STATE_DISCONNECTED  // 断线（采集异常）
} CELL_state_e;
// 电芯数据结构体
typedef struct
{
    uint16_t voltage_mV[CELL_MAX_NUM];  // 各电芯电压(mV)
    CellState_E state[CELL_MAX_NUM];    // 各电芯状态
    uint8_t valid_cell_count;           // 有效电芯数量（实际接入数量）
    uint32_t last_sample_time_ms;       // 最后一次采集时间(ms)
} CELL_voltage_data_t;
// 静态全局变量定义, 代码中尽量减少全局变量的使用, 可以使用静态全局变量加上
get set函数替代
static uint8_t g_local_addr = 0;
// 静态常量定义
static const uint8_t MIN_BUFFER_SIZE = 10;
// 对外接口函数定义，加上模块前缀，以及前缀后的首字母大写
// 函数名，使用动词 + 名词构成
// 多个单词间使用下划线连接，函数名尽量取得通俗易懂，让人看到函数名就大概清楚函
数的功能
uint8_t CELL_get_local_addr(void)
{
    return g_local_addr;
}
void CELL_set_local_addr(uint8_t address)
{
    g_local_addr = address;
}
void CELL_get_voltage(void)
{
    // 局部变量定义
    uint8_t temp_voltage = 0;  // 临时变量
    // 静态局部变量
    static uint8_t s_voltage = 0;

    for (uint8_t i = 0; i < MAX_BUFFER_SIZE; i++)  // 循环变量 i
    {
        //...
    }

### 第14页

3.3 建议-常用缩写
}
// 内部函数，使用static修饰
static uint8_t CELL_set_state(void)
{
    //...
    return 0;
}
缩写
英文全称
中文释义
bms
Battery Management System
电池管理系统
cell
Cell（Battery Cell）
电芯
pack
Battery Pack
电池包
soc
State of Charge
剩余电量（荷电状态）
soh
State of Health
健康状态
cur
Current
电流
vol
Voltage
电压
chg
Charge
充电
dchg
Discharge
放电
com
Communication
通信
alm
Alarm
告警
bal
Balancing
均衡
fil
Filter
滤波
arg
argument
参数、实参
buff
buffer
缓冲区
clk
clock
时钟

### 第15页

4. 编码风格
4.1 规则-缩进与空格
使用4个空格缩进，设置IDE自动把TAB键转换成4个空格，下面以vscode设置举例
cmd
command
命令
cmp
compare
比较
cfg
configuration
配置
dev
device
设备
err
error
错误
hex
hexadecimal
十六进制
inc
increment
增加
init
initialize
初始化
max
maximum
最大
min
minimum
最小
msg
message
消息
para
parameter
参数、形参
prev
previous
前一个
reg
register
寄存器
sem
semaphore
信号量
stat
statistic
统计
sync
synchronize
同步
●

### 第16页

示例
复制代码
注：
预处理指令（#if / #ifdef / #else / #endif  等）缩进规则：
通常顶格写（不缩进）
少数场景（如多层嵌套预处理），缩进4格
复制代码
//=========== 正面示例：使用4个空格缩进
if (CELL_switch_mode(CHARGE_MODE))
{
    CELL_confirm_mode_transition();
}
else
{
    CELL_revert_mode(PREV_MODE);
}
//=========== 反面示例：使用2个空格缩进
if (CELL_switch_mode(CHARGE_MODE))
{
  CELL_confirm_mode_transition();
}
else
{
  CELL_revert_mode(PREV_MODE);
}
○
○
// 示例
#if xxxx
    #if xxxx
    // code...
    #endif
#endif

### 第17页

关键字与括号之间加空格
if / for / while / switch / return 等关键字后必须加空格
复制代码
逗号、分号后（for 循环）后面加空格
示例
复制代码
●
//=========== 正面实例
if (a > b)  // if后加空格
{
    return 0; // return后加空格
}
for (int i = 0; i < 10; i++)  // for后加空格
{
    while (flag) // while后加空格
    {}
}
//=========== 反面示例
if(a > b) {}  // if后无空格
return(0);    // return后无空格
for(int i=0;i<10;i++) {} // 紧凑无空格
●
//=========== 正面实例
// 正面示例，逗号、分号后加空格
memcpy(cfg_new.config_data, data, sizeof(cfg_new.config_data));
for (uint8_t i = 0; i < MAX_BUFFER_SIZE; i++)
{
    //...
}
//=========== 反面示例，逗号、分号后没有加空格
memcpy(cfg_new.config_data,data,sizeof(cfg_new.config_data));
for (uint8_t i = 0;i < MAX_BUFFER_SIZE;i++)
{
    //...
}

### 第18页

运算符前后加空格
示例
复制代码
注释符与注释内容之间间隔一个空格，这样注释内容更清晰
复制代码
4.2 规则-大括号风格
采用Allman 风格，左右括号都单独一行
示例
复制代码
●
// 运算符前后加空格
//=========== 正面示例：运算符前后加空格
int sum = a + b;
//=========== 反面示例：运算符前后没加空格
int sum=a+b;
●
// 注释符与注释内容之间间隔一个空格
//=========== 正面示例：//后有空格
int cell_voltage = 0; // 电压值(mV)
//=========== 反面示例：//后无空格
int cell_voltage = 0; //电压值(mV)
●
//=========== 正面示例
if (condition)
{
    // code
}
else
{
    // code
}
//=========== 正面示例
void CELL_get_voltage(void)
{
    // code
}

### 第19页

if、for、do、while等语句后，即使执行语句仅有1行代码也需要增加"{}"
复制代码
switch case语句，case后根据需要添加大括号
说明：当case的模块中没有变量定义时可以不加大括号，有变量定义时则必须加大括号，否
则编译报错
复制代码
//=========== 反面示例
if (condition) {
    // code
} else {
    // code
}
●
// if、for、do、while等语句后，即使执行语句只有一行代码也建议增加"{}"；
//=========== 正面示例
if (condition)
{
    sum++;
}
//=========== 反面示例
if (condition)
    sum++;
●
int num = 3;
switch (num) {
    case 1:
        printf("你选择了1\n");  // 单条语句，无需{}
        break;
    case 2:
        printf("你选择了2\n");  // 多条语句，也可不用{}
        printf("这是case 2的第二条语句\n");
        break;
    case 3: // 加{}，定义变量
    {
        int a = 30;
        printf("case 3的变量a：%d\n", a);
        break;

### 第20页

4.3 规则-行长度
每行不超过120个字符，如有超长，在逗号、分号或者低优先操作符处划分新行，换行后
缩进4个空格
示例
复制代码
VSCode 中设置 120 个字符的垂直标尺，具体步骤如下：
settings.json
复制代码
    }
    default:
        printf("无效选择\n");
        break;
}
●
// 在逗号、分号或者低优先操作符处划分新行
very_long_function_name(extremely_long_parameter1,
extremely_long_parameter2,
    extremely_long_parameter3);  // 换行后缩进4个空格
1. 图形界面快速设置
1. 打开 VSCode，点击顶部菜单栏的文件→首选项→设置；
2. 在设置面板的搜索框中输入Editor: Rulers ；
3. 找到对应设置项后，点击其下方的编辑 in settings.json，进入配置文件编辑界面。
2. 配置文件编写规则
1. 若只需显示 120 字符单条标志线，在settings.json 中添加如下配置：
{
    "editor.rulers": [
        {
            "column": 120,
            "color": "#ff9900"
        }
    ]
}

### 第21页

（本页未提取到可读文本；如该页含图片，请参见“图片内容文字化补充”。）

### 第22页

4.4 规则-嵌套深度
嵌套层次不超过4层，超过时应考虑使用卫语句减少嵌套或者提取为函数，若减少后嵌套
深度仍超过4层，需请示主管
示例
复制代码
●
//=========== 正面示例：最大深度=4
void BMS_safety_check(uint16_t volt, uint16_t temp, uint8_t soc)
{
    if (bms_ready)  // 1层
    {
        if (volt > 4000)  // 2层
        {
            for (int i=0; i<5; i++)  // 3层
            {
                if (temp > 50)  // 4层（合规）
                {
                    check_soc(soc);
                }
            }
        }
    }
}
//=========== 反面示例：最大深度=5
void BMS_safety_check(uint16_t volt, uint16_t temp, uint8_t soc)
{
    if (bms_ready)  // 1层
    {
        if (volt > 4000)  // 2层
        {
            for (int i=0; i<5; i++)  // 3层v
            {
                if (temp > 50)  // 4层（合规）
                {
                    if (soc < 90)
                    {
                        check_soc(soc);
                    }
                }
            }
        }
    }
}

### 第23页

嵌套深度相关解释：
1、嵌套深度定义
嵌套深度 = 「当前代码块被多少层控制结构直接 / 间接包裹」的数量，本质是逻辑层级的
“包裹层数” —— 每新增一层 “包裹” 当前代码的控制结构，深度 + 1。
2、嵌套深度通用计算规则
3、嵌套深度分步计算案例
以下结合 BMS 典型代码，拆解嵌套深度的计算过程：
案例 1：基础嵌套（if+for）
复制代码
void BMS_cell_check(uint16_t cell_volt[], uint8_t cell_count)
{
    // 深度0：函数根层级（无控制结构包裹）
    if (cell_count <= 96)  // 深度1：第1层控制结构（if）
    {
        // 深度1：if块内的代码
        for (uint8_t i = 0; i < cell_count; i++)  // 深度2：嵌套for循环
        {
            // 深度2：for块内的代码
            if (cell_volt[i] > 4200)  // 深度3：嵌套if
            {
                // 深度3：此代码的嵌套深度=3
                set_fault_code(BMS_FAULT_OVER_VOLT);
            }
        }
    }

### 第24页

计算过程：
函数根层级（无控制结构）：深度 0；
if(cell_count <=96)  包裹后续代码：深度 + 1 → 深度 1；
for(...)  被 if 包裹：深度 + 1 → 深度 2；
if(cell_volt[i]>4200)  被 for 包裹：深度 + 1 → 深度 3；
最终set_fault_code 所在行的嵌套深度 = 3。
案例 2：switch+if+for（易混淆场景）
复制代码
计算过程：
switch  → 深度 1；
case 1 内的if  → 深度 2；
if 内的for  → 深度 3；
关键：case 不单独加深度，仅switch 计 1 层。
案例 3：if-else if-else（同一层判定）
}
●
●
●
●
●
void BMS_mode_control(uint8_t work_mode)
{
    // 深度0
    switch (work_mode)  // 深度1：switch本身计1层
    {
        case 1: // 深度1：case属于switch块内，无新增深度
            if (bms_status == 1)  // 深度2：if嵌套在switch内
            {
                // 深度2
                for (uint8_t j = 0; j < 10; j++)  // 深度3：for嵌套在if内
                {
                    // 深度3
                    start_charge(); // 此代码深度=3
                }
            }
            break;
        default:
            break;
    }
}
●
●
●
●

### 第25页

复制代码
计算过程：
同一组if-else if-else 仅计 1 层；
else 内的嵌套if 才新增深度（深度 2）。
案例 4：函数调用不影响当前深度
复制代码
void BMS_temp_check(uint16_t temp)
{
    // 深度0
    if (temp > 60)  // 深度1：同一组if-else仅计1层
    {
        stop_charge_discharge(); // 深度1
    }
    else if (temp > 45)  // 深度1：else if不新增深度
    {
        limit_current(); // 深度1
    }
    else if (temp < -20)  // 深度1
    {
        alarm_low_temp(); // 深度1
    }
    else  // 深度1
    {
        // 嵌套if：深度+1
        if (temp > 30)  // 深度2
        {
            start_fan();  // 深度2
        }
    }
}
// 被调用函数（单独计算其内部深度）
static void BMS_handle_cell_abnormal(uint8_t idx, uint16_t volt)
{
    if (volt > 4200)  // 此函数内的深度1
    {
        set_fault(3);  // 深度1
    }
}
// 主函数

### 第26页

4.5 建议-行间隔
相对独立的程序块之间必须加空行，同时需要添加代码块的功能注释
复制代码
void BMS_scan_cells(uint16_t volt[], uint8_t count)
{
    if (count > 0)  // 深度1
    {
        for (uint8_t i = 0; i < count; i++)  // 深度2
        {
            // 函数调用：不计入主函数嵌套深度，仍为深度2
            BMS_handle_cell_abnormal(i, volt[i]);
        }
    }
}
●
//=========== 正面示例
#define BMS_OVER_VOLTAGE 4200
#define BMS_OVER_TEMPERATURE 60
/**
 * 功能： BMS核心安全检测：检测电池包过压、过温故障，触发对应保护动作
 * 注意事项：
 */
void BMS_safety_check(void)
{
    uint8_t bms_system_status = 0;
    // 功能注释：读取电池包核心参数（总压/温度），为后续故障检测提供数据
    uint16_t pack_voltage = read_adc_channel(0);
    uint16_t pack_temperature = read_adc_channel(1);
    // 空行：参数读取块 与 过压检测块 分隔
    // 功能注释：过压故障检测+紧急停机保护（超过4200mV立即停止充放电）
    if (pack_voltage > BMS_OVER_VOLTAGE)
    {
        bms_system_status = BMS_FAULT_OVER_VOLT;
        stop_charge_discharge(); // 切断充放电回路，防止过压损坏电芯
    }
    // 空行：过压检测块 与 过温检测块 分隔
    // 功能注释：过温故障检测+高温告警（超过60℃触发声光告警，不立即停机）
    if (pack_temperature > BMS_OVER_TEMPERATURE)

### 第27页

反面示例
复制代码
    {
        bms_system_status = BMS_FAULT_OVER_TEMP;
        alarm_high_temperature(); // 触发高温告警，提醒用户降载/冷却
    }
    // 空行：故障检测块 与 故障上报块 分隔
    // 功能注释：故障状态CAN上报（有故障时向整车控制器发送故障码）
    if (bms_system_status != 0)
    {
        send_fault_can_message(bms_system_status);
    }
    return;
}
//=========== 反面示例
#define BMS_OVER_VOLTAGE 4200
#define BMS_OVER_TEMPERATURE 60
// 变量定义、初始化、故障检测无空行分隔，代码块粘连；代码块没有功能注释
void BMS_safety_check(void)
{
    uint8_t bms_system_status = 0;
    // 读取电池包电压
    uint16_t pack_voltage = read_adc_channel(0);
    uint16_t pack_temperature = read_adc_channel(1);
    if (pack_voltage > BMS_OVER_VOLTAGE)
    {
        bms_system_status = BMS_FAULT_OVER_VOLT;
        stop_charge_discharge();
    }
    if (pack_temperature > BMS_OVER_TEMPERATURE)
    {
        bms_system_status = BMS_FAULT_OVER_TEMP;
        alarm_high_temperature();
    }
    if (bms_system_status != 0)
    {
        send_fault_can_message(bms_system_status);
    }
    return;
}

### 第28页

4.6 建议-一行只写一条语句
复制代码
5. 注释规范
5.1 建议-通用规范
不要注释掉废弃代码（直接删除，靠版本控制回溯）
优秀的代码可以自我解释，不通过注释即可轻易读懂（当前阶段都需要写上注释）
正面示例
复制代码
反面示例
复制代码
//=========== 正面示例
int a = 5;
int b = 6;
//=========== 反面示例
int a = 5; int b = 6;
●
●
//=========== 正面示例
// 不需要注释，命名规范，逻辑清晰，能直接看懂
static bool CELL_is_prime_number(int32_t num)
{
    int32_t sqrt_of_num = sqrt(num);
    for (int32_t i = 2; i <= sqrt_of_num; i++)
    {
        if (num % i == 0)
        {
            return false;
        }
    }
    return true;
}
//=========== 反面示例
// 判断m是否为素数，返回值：true:是素数，false:不是素数
bool p(int32_t m)
{
    int32_t k = sqrt(m);
    for (int32_t i = 2; i <= k; i++)

### 第29页

说明：反面案例中的注释并不能消除代码的坏味道：
注释的内容要清楚、明了，含义准确，防止注释二义性
示例
复制代码
在代码的功能、意图层次上进行注释，即注释解释代码难以直接表达的意图，而不是重复
描述代码
正面示例
复制代码
    {
        if (m % i == 0)
        {
            break; // 发现整除，表示m不为素数，结束遍历
        }
    }
    // 遍历中没有发现整除的情况，返回
    if (i > k)
    {
        return true;
    }
    else  // 遍历中发现整除的情况，返回
    {
        return false;
    }
}
●
//=========== 正面示例，注释含义准确
if (bms_status != BMS_STATUS_READY)
{
    // BMS非就绪状态（=BMS_STATUS_FAULT），禁止充放电（系统未完成自检）
    CELL_disable_charge();
}
//=========== 反面示例，注释含义模糊
if (bms_status != BMS_STATUS_READY)
{
    // 状态不对禁止充电
    CELL_disable_charge();
}
●

### 第30页

反面示例
复制代码
修改代码时，维护代码周边的所有注释，以保证注释与代码的一致性。不再有用的注释要
删除
//=========== 正面示例
void CELL_check_voltage(uint16_t cell_volt[], uint8_t cell_count)
{
    // 逐节检测电芯：过压是热失控核心诱因，需优先阻断充放电
    for (uint8_t i = 0; i < cell_count; i++)
    {
        uint16_t volt = cell_volt[i];

        // 过压保护触发：超阈值立即停机（避免电芯不可逆损坏）
        if (volt > CELL_OVER_VOLT_THRESH)
        {
            // 标记故障并上报：便于售后定位故障电芯位置
            CELL_set_fault(i, FAULT_OVER_VOLT);
            // 切断充放电回路：BMS一级安全保护动作
            CELL_stop_charge_discharge();
        }
    }
}
//=========== 反面示例
void CELL_check_voltage(uint16_t cell_volt[], uint8_t cell_count)
{
    // for循环遍历所有电芯
    for (uint8_t i = 0; i < cell_count; i++)
    {
        // 读取第i节电芯电压
        uint16_t volt = cell_volt[i];

        // 如果电压大于CELL_OVER_VOLT_THRESH
        if (volt > CELL_OVER_VOLT_THRESH)
        {
            // 设置故障码为FAULT_OVER_VOLT
            CELL_set_fault(i, FAULT_OVER_VOLT);
            // 调用停止充放电函数
            CELL_stop_charge_discharge();
        }
    }
}
●

### 第31页

示例
复制代码
5.2 建议-文件头注释
// 修改前代码
void CELL_check_volt(uint16_t cell_volt)
{
    // 过压保护：超4150mV停机
    if (cell_volt > CELL_OVER_VOLT_THRESH)
    {
        CELL_set_fault(FAULT_OVER_VOLT);
        CELL_stop_charge_discharge();
    }
    // 欠压预警：低于2800mV触发声光告警（未停机，仅提醒）
    if (cell_volt < CELL_UNDER_VOLT_THRESH)
    {
        CELL_alarm_under_volt();
    }
}
//=========== 正面示例，修改后代码，删除欠压预警逻辑，同步删除无用注释
void CELL_check_volt(uint16_t cell_volt)
{
    // 过压保护：超4150mV停机
    if (cell_volt > CELL_OVER_VOLT_THRESH)
    {
        CELL_set_fault(FAULT_OVER_VOLT);
        CELL_stop_charge_discharge();
    }
}
//=========== 反面示例，修改后代码，仅删代码，保留无用注释
void CELL_check_volt(uint16_t cell_volt)
{
    // 过压保护：超4150mV停机
    if (cell_volt > CELL_OVER_VOLT_THRESH)
    {
        CELL_set_fault(FAULT_OVER_VOLT);
        CELL_stop_charge_discharge();
    }
    // 欠压预警：低于2800mV触发声光告警（未停机，仅提醒）// 代码删了，注释还在
}

### 第32页

头文件注释必须按照以下格式，在版本发布后有重点变更时，需要同步维护修改记录
复制代码
5.3 建议-函数注释
一般注释函数功能是必要的，参数、返回值和注意事项根据需要添加
复制代码
文件头和函数注释可以使用vscode代码块生成功能快速生成注释，vscode代码块生成指
导：
1）点击vscode的代码片段
●
/*
 * Copyright (c) 2023, Company Name
 *
 * 文件名称: filename.c
 * 功能描述: 简要描述文件功能
 * 作者: 姓名
 * 创建日期: yyyy-mm-dd
 * 修改记录:
 *   修改人    修改日期    修改内容
 *   -----    ----------  ------------
 *   name     yyyy-mm-dd  创建文件
 */
●
/**
 * @brief  计算两个整数的和
 * @param  a: 第一个加数
 * @param  b: 第二个加数
 * @return 两个参数的和
 * @note   输入参数应在有效范围内
 */
int32_t add(int32_t a, int32_t b)
{
    return a + b;
}

### 第33页

2）点击新建全局代码片段文件
3）输入代码段文件名
4）输入代码段文件明后，会生成如下的一个文件

### 第34页

5）片段编写指导：
scope：支持语言，不写的话表示支持所有语言
prefix：触发关键词
body：片段内容，可以写多行
description：可选说明
6）示例如下：
复制代码
    "function comment": {
// "scope": "c",
"prefix": "fun",

### 第35页

7）使用：
"body": [
"/**",
"* @brief  ",
"* @param  ",
"* @param  ",
"* @return ",
"* @note   ",
"*/",
"$2"
],
"description": "函数头注释"
}
"file comment": {
// "scope": "c",
"prefix": "file",
"body": [
"/*",
"* Copyright (c) 20xx, Company Name",
"*" ,
"* 文件名称: ",
"* 功能描述: 简要描述文件功能",
"* 作者: 姓名",
"* 创建日期: yyyy-mm-dd",
"* 修改记录:",
"*   修改人    修改日期    修改内容",
"*   -----    ----------  ------------",
"*   name     yyyy-mm-dd  创建文件",
"*/",
"$2"
],
"description": "文件头注释"
}

### 第36页

5.4 建议-代码注释
在同一行使用 ‘//’ 进行注释时，与代码部分最少间隔两个空格，正式注释内容与 ‘//’ 间隔
一个空格
复制代码
单行注释使用// ，多行注释使用/* */
●
//：单行注释，从 // 到行尾均为注释；适合简短说明、行内备注、临时调试注释
/* */：多行注释，/* 开头、*/ 结尾，可跨多行；适合函数 / 文件头注释、大段业务说
明、兼容老编译器、注释代码块
○
○
注释应放在代码上方或右侧
●
放上方主要解释 “为什么这么写”（设计意图）、“整体做什么”（代码块功能），适合
长注释、结构化注释；建议注释在上方的情况如下（不限于）：
○
代码块注释
单行代码注释
■
■
放右侧主要解释 “这行代码的细节”（特殊值、临时备注），适合短注释、补充说
明；建议注释在右侧的情况如下（不限于）：
○
单行代码的细节、特殊值
注释简短，需要保障代码 + 注释的总长度不超过120
枚举、位操作说明等
■
■
■
●
// 检查输入是否有效
if (input > MAX_INPUT)
{
    return ERROR;  // 输入超出范围，返回错误

### 第37页

6. 函数规范
6.1 建议-函数应单一职责，只做一件事
说明：函数单一职责的优势：逻辑清晰、可复用性强、可测试性强和易拓展等优势
正面案例
复制代码
}
/**
 * @brief  计算两个整数的和
 * @param  a: 第一个加数
 * @param  b: 第二个加数
 * @return 两个参数的和
 * @note   输入参数应在有效范围内
 */
int32_t add(int32_t a, int32_t b)
{
    return a + b;
}
//=========== 正面案例，每个函数只做一件事
// 1. 仅负责采集ADC原始值（硬件操作）
static BMS_error_e CELL_voltage_read_raw_adc(uint16_t *raw_adc)
{
    if (ADC_Read(raw_adc) != ADC_OK)
    {
        return BMS_ERR_ADC_READ;
    }
    return BMS_SUCCESS;
}
// 2. 仅负责将原始值转换并滤波（数据处理）
static void CELL_voltage_filter_data(uint16_t *raw_adc, uint16_t
*filtered_voltage)
{
    for (uint8_t i = 0; i < CELL_MAX_NUM; i++)
    {
        // 独立的滤波逻辑，便于单独优化（如替换为滑动平均）
        filtered_voltage[i] = (raw_adc[i] * 3300 * 10) / 4095;
    }
}
// 3. 仅负责判断电芯状态（状态判断）

### 第38页

static BMS_error_e CELL_voltage_check_state(uint16_t *filtered_voltage)
{
    BMS_error_e ret = BMS_SUCCESS;
    for (uint8_t i = 0; i < CELL_MAX_NUM; i++) {
        if (filtered_voltage[i] > 4200)
        {
            s_cell_state[i] = CELL_STATE_OVERVOLTAGE;
            ret = BMS_ERR_OVERVOLTAGE;
        }
        else if (filtered_voltage[i] < 2500)
        {
            s_cell_state[i] = CELL_STATE_UNDERVOLTAGE;
            ret = BMS_ERR_UNDERVOLTAGE;
        }
        else
        {
            s_cell_state[i] = CELL_STATE_NORMAL;
        }
    }
    return ret;
}
// 4. 仅负责上报故障（通信交互）
static void CELL_voltage_report_fault(BMS_Error_e err)
{
    if (err != BMS_SUCCESS) {
        Can_SendFaultMsg(err);
    }
}
// 对外接口：组合单一职责函数（协调者角色，不做具体任务）
BMS_error_e CELL_voltage_process(void)
{
    uint16_t raw_adc[CELL_MAX_NUM] = {0};
    uint16_t filtered_voltage[CELL_MAX_NUM] = {0};
    // 依次调用单一职责函数，逻辑清晰
    BMS_error_e ret = Cell_voltage_read_raw_adc(raw_adc);
    if (ret != BMS_SUCCESS)
    {
        return ret;
    }
    Cell_voltage_filter_data(raw_adc, filtered_voltage);
    ret = Cell_voltage_check_state(filtered_voltage);

### 第39页

正面案例优势分析：
逻辑清晰：每个函数的作用一目了然（如Cell_voltage_filter_data 仅负责滤波），便于
阅读和维护。
可复用性高：例如Cell_voltage_check_state 可在 “实时监测” 和 “定期巡检” 场景中复
用，无需重复编写。
可测试性强：可单独对Cell_voltage_filter_data 进行单元测试（输入已知原始值，验证
滤波结果），确保每个环节可靠。
易扩展：如需更换滤波算法，只需修改Cell_voltage_filter_data ，不影响采集、判断等
其他模块。
反面案例
复制代码
    Cell_voltage_report_fault(ret);
    return ret;
●
●
●
●
//=========== 反面案例：一个函数做多个事情
BMS_error_e CELL_voltage_process(void)
{
    uint16_t raw_adc[CELL_MAX_NUM] = {0};
    uint16_t filtered_voltage[CELL_MAX_NUM] = {0};

    // 1. 采集ADC原始值（任务1：硬件采集）
    if (ADC_Read(raw_adc) != ADC_OK)
    {
        return BMS_ERR_ADC_READ;
    }
    // 2. 对原始值进行滤波（任务2：数据处理）
    for (uint8_t i = 0; i < CELL_MAX_NUM; i++)
    {
        filtered_voltage[i] = (raw_adc[i] * 3300 * 10) / 4095; // 转换+简
单滤波
    }
    BMS_error_e ret = BMS_SUCCESS;
    // 3. 判断过压/欠压状态（任务3：状态判断）
    for (uint8_t i = 0; i < CELL_MAX_NUM; i++)
    {
        if (filtered_voltage[i] > 4200)
        {
            s_cell_state[i] = CELL_STATE_OVERVOLTAGE;

### 第40页

反面案例问题分析：
逻辑耦合：采集、滤波、判断、上报强耦合，修改其中一个步骤（如换滤波算法）需改动
整个函数，易引发连锁错误。
可测试性差：无法单独测试 “滤波逻辑” 或 “状态判断”，必须完整执行所有步骤。
可读性低：阅读者需逐行梳理多个任务的逻辑，难以快速理解函数核心作用。
6.2 规则-函数长度不超过50行（非空非注释行）
说明：函数长度超长会导致可读性差、维护困难、复用性差和难测试等。
正面案例
复制代码
            ret = BMS_ERR_OVERVOLTAGE;
        }
        else if (filtered_voltage[i] < 2500)
        {
            s_cell_state[i] = CELL_STATE_UNDERVOLTAGE;
            ret = BMS_ERR_UNDERVOLTAGE;
        }
    }
    // 4. 上报故障到上位机（任务4：通信交互）
    if (ret != BMS_SUCCESS)
    {
        Can_SendFaultMsg(ret);
    }
    return ret;
}
●
●
●
//=========== 正面案例
// 1. 初始化GPIO
static BMS_error_e BMS_init_gpio(void)
{
    GPIO_InitTypeDef gpio_init;
    // 输出引脚配置（均衡控制、电源使能）
    gpio_init.Pin = CELL_BALANCE_PIN | POWER_ENABLE_PIN;
    gpio_init.Mode = GPIO_MODE_OUTPUT_PP;
    gpio_init.Pull = GPIO_NOPULL;
    gpio_init.Speed = GPIO_SPEED_FREQ_HIGH;
    if (HAL_GPIO_Init(GPIOA, &gpio_init) != HAL_OK)
    {
        return BMS_ERR_GPIO_INIT;

### 第41页

}
    // 输入引脚配置（告警信号）
    gpio_init.Pin = CELL_ALARM_PIN | TEMP_ALARM_PIN;
    gpio_init.Mode = GPIO_MODE_INPUT;
    gpio_init.Pull = GPIO_PULLUP;
    if (HAL_GPIO_Init(GPIOB, &gpio_init) != HAL_OK)
    {
        return BMS_ERR_GPIO_INIT;
    }
    return BMS_SUCCESS;
}
// 2. 初始化ADC
static BMS_error_e BMS_init_adc(void)
{
    ADC_HandleTypeDef adc_handle;
    adc_handle.Instance = ADC1;
    adc_handle.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
    adc_handle.Init.Resolution = ADC_RESOLUTION_12B;
    adc_handle.Init.ScanConvMode = ENABLE;
    adc_handle.Init.ContinuousConvMode = DISABLE;
    adc_handle.Init.DiscontinuousConvMode = DISABLE;
    adc_handle.Init.ExternalTrigConvEdge =
ADC_EXTERNALTRIGCONVEDGE_NONE;
    adc_handle.Init.ExternalTrigConv = ADC_SOFTWARE_START;
    if (HAL_ADC_Init(&adc_handle) != HAL_OK)
    {
        return BMS_ERR_ADC_INIT;
    }
    // 配置ADC通道0
    ADC_ChannelConfTypeDef adc_channel;
    adc_channel.Channel = ADC_CHANNEL_0;
    adc_channel.Rank = 1;
    adc_channel.SamplingTime = ADC_SAMPLETIME_3CYCLES;
    if (HAL_ADC_ConfigChannel(&adc_handle, &adc_channel) != HAL_OK)
    {
        return BMS_ERR_ADC_CHANNEL;
    }
    return BMS_SUCCESS;
}

### 第42页

// 3. 初始化CAN通信
static BMS_error_e BMS_init_can(void)
{
    CAN_HandleTypeDef can_handle;
    can_handle.Instance = CAN1;
    can_handle.Init.Mode = CAN_MODE_NORMAL;
    can_handle.Init.AutoBusOff = ENABLE;
    can_handle.Init.AutoRetransmission = ENABLE;
    can_handle.Init.Prescaler = 6;
    can_handle.Init.SyncJumpWidth = CAN_SJW_1TQ;
    can_handle.Init.TimeSeg1 = CAN_BS1_11TQ;
    can_handle.Init.TimeSeg2 = CAN_BS2_4TQ;
    if (HAL_CAN_Init(&can_handle) != HAL_OK)
    {
        return BMS_ERR_CAN_INIT;
    }
    // 配置CAN滤波器
    CAN_FilterTypeDef can_filter;
    can_filter.FilterBank = 0;
    can_filter.FilterMode = CAN_FILTERMODE_IDMASK;
    can_filter.FilterScale = CAN_FILTERSCALE_32BIT;
    can_filter.FilterIdHigh = 0;
    can_filter.FilterIdLow = 0;
    can_filter.FilterMaskIdHigh = 0;
    can_filter.FilterMaskIdLow = 0;
    can_filter.FilterFIFOAssignment = CAN_RX_FIFO0;
    can_filter.FilterActivation = ENABLE;
    if (HAL_CAN_ConfigFilter(&can_handle, &can_filter) != HAL_OK)
    {
        return BMS_ERR_CAN_FILTER;
    }
    return BMS_SUCCESS;
}
// 4. 初始化电芯参数
static void BMS_init_cell_params(BMS_Init_param_t *param)
{
    uint8_t count = param->cell_count;
    for (uint8_t i = 0; i < count; i++)
    {
        s_cell_params[i].ov_threshold = param->ov_threshold;
        s_cell_params[i].uv_threshold = param->uv_threshold;
        s_cell_params[i].balance_threshold = param->balance_threshold;

### 第43页

}
}
// 5. 检查硬件状态
static BMS_error_e BMS_check_hardware_state(void)
{
    if (HAL_GPIO_ReadPin(GPIOB, CELL_ALARM_PIN) == GPIO_PIN_RESET)
    {
        return BMS_ERR_CELL_ALARM;
    }
    if (HAL_GPIO_ReadPin(GPIOB, TEMP_ALARM_PIN) == GPIO_PIN_RESET)
    {
        return BMS_ERR_TEMP_ALARM;
    }
    return BMS_SUCCESS;
}
// 主初始化函数
BMS_error_e BMS_Init(BMS_Init_param_t *param)
{
    if (param == NULL)
    {
        return BMS_ERR_PARAM_INVALID;
    }
    // 依次调用各初始化函数，逻辑清晰
    BMS_error_e ret = BMS_init_gpio();
    if (ret != BMS_SUCCESS)
    {
        return ret;
    }
    ret = BMS_init_adc();
    if (ret != BMS_SUCCESS)
    {
        return ret;
    }
    ret = BMS_init_can();
    if (ret != BMS_SUCCESS)
    {
        return ret;
    }

### 第44页

正面案例优势分析：
可读性强：每个函数长度控制在 20 行左右，一屏内可完整显示，逻辑一目了然（如Bms_
init_can 仅处理 CAN 初始化）。
维护便捷：修改某硬件初始化（如 ADC 通道）时，直接定位到Bms_init_adc 即可，无
需浏览无关代码。
复用性高：Bms_init_gpioGPIO 可在 “硬件复位” 功能中直接复用，避免代码冗余。
测试高效：可单独对Bms_init_can 进行单元测试（验证 CAN 滤波器配置是否正确），
缩短测试周期。
反面案例
复制代码
    BMS_init_cell_params(param);
    ret = BMS_check_hardware_state();
    if (ret != BMS_SUCCESS)
    {
        return ret;
    }
    g_bms_state = BMS_STATE_INITED;
●
●
●
●
//=========== 反面案例
// 函数过长，包含过多初始化逻辑（约70行）
BMS_error_e BMS_init(BMS_Init_param_t *param)
{
    if (param == NULL)
    {
        return BMS_ERR_PARAM_INVALID;
    }
    // 1. 初始化GPIO
    GPIO_InitTypeDef gpio_init;
    gpio_init.Pin = CELL_BALANCE_PIN | POWER_ENABLE_PIN;
    gpio_init.Mode = GPIO_MODE_OUTPUT_PP;
    gpio_init.Pull = GPIO_NOPULL;
    gpio_init.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA, &gpio_init);
    gpio_init.Pin = CELL_ALARM_PIN | TEMP_ALARM_PIN;
    gpio_init.Mode = GPIO_MODE_INPUT;
    gpio_init.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(GPIOB, &gpio_init);

### 第45页

// 2. 初始化ADC
    ADC_HandleTypeDef adc_handle;
    adc_handle.Instance = ADC1;
    adc_handle.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
    adc_handle.Init.Resolution = ADC_RESOLUTION_12B;
    adc_handle.Init.ScanConvMode = ENABLE;
    adc_handle.Init.ContinuousConvMode = DISABLE;
    adc_handle.Init.DiscontinuousConvMode = DISABLE;
    adc_handle.Init.ExternalTrigConvEdge =
ADC_EXTERNALTRIGCONVEDGE_NONE;
    adc_handle.Init.ExternalTrigConv = ADC_SOFTWARE_START;
    if (HAL_ADC_Init(&adc_handle) != HAL_OK)
    {
        return BMS_ERR_ADC_INIT;
    }
    // 3. 配置ADC通道
    ADC_ChannelConfTypeDef adc_channel;
    adc_channel.Channel = ADC_CHANNEL_0;
    adc_channel.Rank = 1;
    adc_channel.SamplingTime = ADC_SAMPLETIME_3CYCLES;
    if (HAL_ADC_ConfigChannel(&adc_handle, &adc_channel) != HAL_OK)
    {
        return BMS_ERR_ADC_CHANNEL;
    }
    // 4. 初始化CAN通信
    CAN_HandleTypeDef can_handle;
    can_handle.Instance = CAN1;
    can_handle.Init.Mode = CAN_MODE_NORMAL;
    can_handle.Init.AutoBusOff = ENABLE;
    can_handle.Init.AutoRetransmission = ENABLE;
    can_handle.Init.Prescaler = 6;
    can_handle.Init.SyncJumpWidth = CAN_SJW_1TQ;
    can_handle.Init.TimeSeg1 = CAN_BS1_11TQ;
    can_handle.Init.TimeSeg2 = CAN_BS2_4TQ;
    if (HAL_CAN_Init(&can_handle) != HAL_OK)
    {
        return BMS_ERR_CAN_INIT;
    }
    CAN_FilterTypeDef can_filter;
    can_filter.FilterBank = 0;
    can_filter.FilterMode = CAN_FILTERMODE_IDMASK;

### 第46页

反面案例问题分析：
可读性差：开发者需滚动屏幕才能浏览完整逻辑，难以快速定位某部分初始化代码（如
CAN 配置）。
维护困难：修改某一硬件的初始化（如更换 ADC 通道）需在长函数中搜索，易误改其他
逻辑。
复用性低：GPIO 初始化逻辑无法在 “硬件复位” 场景中复用，需重复编写。
测试成本高：单元测试需覆盖所有初始化步骤，难以单独验证某一模块（如 CAN）的初
始化是否正确。
    can_filter.FilterScale = CAN_FILTERSCALE_32BIT;
    can_filter.FilterIdHigh = 0;
    can_filter.FilterIdLow = 0;
    can_filter.FilterMaskIdHigh = 0;
    can_filter.FilterMaskIdLow = 0;
    can_filter.FilterFIFOAssignment = CAN_RX_FIFO0;
    can_filter.FilterActivation = ENABLE;
    if (HAL_CAN_ConfigFilter(&can_handle, &can_filter) != HAL_OK)
    {
        return BMS_ERR_CAN_FILTER;
    }
    // 5. 初始化电芯参数
    uint8_t count = param->cell_count;
    for (uint8_t i = 0; i < count; i++)
    {
        s_cell_params[i].ov_threshold = param->ov_threshold;
        s_cell_params[i].uv_threshold = param->uv_threshold;
        s_cell_params[i].balance_threshold = param->balance_threshold;
    }
    // 6. 检查硬件状态
    if (HAL_GPIO_ReadPin(GPIOB, CELL_ALARM_PIN) == GPIO_PIN_RESET)
    {
        return BMS_ERR_CELL_ALARM;
    }
    if (HAL_GPIO_ReadPin(GPIOB, TEMP_ALARM_PIN) == GPIO_PIN_RESET)
    {
        return BMS_ERR_TEMP_ALARM;
    }
    g_bms_state = BMS_STATE_INITED;

return BMS SUCCESS;
●
●
●
●

### 第47页

6.3 建议-参数个数不超过5个
说明：函数参数过多，会让函数调用复杂度高，可读性差；应该进行函数拆分，或者把相关
联的参数整理到一个结构体里，使函数调用清晰简单
正面案例
复制代码
//=========== 正面案例
// 1. 定义参数结构体，封装均衡控制相关配置
typedef struct {
    uint16_t target_voltage;  // 目标均衡电压(mV)
    uint32_t max_duration_ms; // 最大均衡时长(ms)
    uint16_t trigger_diff;    // 触发均衡的电压差(mV)
    uint8_t retry_count;      // 均衡失败重试次数
    BalanceMode_E mode;       // 均衡模式（快速/普通）
} CELL_balance_params_t;
// 2. 函数参数精简为2个（电芯索引+参数结构体）
bool CELL_balance_control(
    uint8_t cell_idx,             // 电芯索引（核心独立参数）
    const CELL_balance_params_t *params // 均衡配置参数（结构体封装）
)
{
    // 参数合法性检查（结构体指针非空）
    if ((cell_idx >= CELL_MAX_NUM) || (params == NULL))
    {
        return false;
    }
    // 检查电压差是否达到触发条件
    uint16_t current_voltage = CELL_voltage_get(cell_idx);
    if ((current_voltage - params->target_voltage) < params-
>trigger_diff)
    {
        return false; // 无需均衡
    }
    // 执行均衡（根据模式选择策略）
    bool ret = false;
    for (uint8_t i = 0; i < params->retry_count; i++)
    {
        if (params->mode == BALANCE_MODE_FAST)
        {
            ret = Balance_fast(cell_idx, params->max_duration_ms);
        }
        else

### 第48页

正面案例优势分析：
调用简洁：参数缩减至 2 个，通过结构体成员名显式指定参数值（如.trigger_diff = 5
0 ），无需记忆顺序，大幅降低传错风险。
可读性高：结构体Balance_Params_T 集中体现均衡控制的所有配置项，函数定义更简
洁，一眼可理解核心输入。
扩展性强：新增参数（如current_limit_ma 均衡电流限制）只需修改结构体，无需调整
函数签名，所有调用处兼容（未使用新参数时可默认初始化）。
可维护性好：参数的合法性检查（如max_duration_ms 范围校验）可集中在结构体初始化
或单独的Balance_params_check() 函数中，避免在函数内重复校验。
反面案例
复制代码
        {
            ret = Balance_normal(cell_idx, params->max_duration_ms);
        }
        if (ret)
        {
            break;
        }
    }
    return ret;
}
// 3. 调用示例：通过结构体初始化参数，可读性强，顺序无关
CELL_balance_params_t params =
{
    .target_voltage = target_voltage,
    .max_duration_ms = max_duration_ms,
    .trigger_diff = trigger_diff,
    .retry_count = retry_count,
    .mode = BALANCE_MODE_NORMAL
};
CELL_balance_control(cell_idx, &params); // 参数清晰，不易出错
●
●
●
●
//=========== 反面案例：函数参数过多（6个），调用时易出错
bool CELL_balance_control(
    uint8_t cell_idx,        // 电芯索引
    uint16_t target_voltage, // 目标均衡电压(mV)
    uint32_t max_duration_ms,// 最大均衡时长(ms)
    uint16_t trigger_diff,   // 触发均衡的电压差(mV)
    uint8_t retry_count,     // 均衡失败重试次数
    CELL_balance_mode_e mode       // 均衡模式（快速/普通）

### 第49页

反面案例问题分析：
调用复杂度高：参数达 6 个，开发者需频繁核对确认参数顺序，易因疏忽传错值。
可读性差：函数定义中参数列表过长，难以快速理解每个参数的作用，维护时需逐行解
析。
)
{
    if (cell_idx >= CELL_MAX_NUM)
    {
        return false;
    }
    // 检查电压差是否达到触发条件
    uint16_t current_voltage = CELL_voltage_get(cell_idx);
    if (current_voltage - target_voltage < trigger_diff)
    {
        return false; // 无需均衡
    }
    // 执行均衡（根据模式选择策略）
    bool ret = false;
    for (uint8_t i = 0; i < retry_count; i++)
    {
        if (mode == BALANCE_MODE_FAST)
        {
            ret = CELL_balance_fast(cell_idx, max_duration_ms);
        }
        else
        {
            ret = CELL_balance_normal(cell_idx, max_duration_ms);
        }

        if (ret)
        {
            break;
        }
    }
    return ret;
}
// 调用示例：参数顺序易混淆，漏传或错传风险高
CELL_balance_control(cell_idx, target_voltage, max_duration_ms,
trigger diff
retry count
BALANCE MODE NORMAL);
●
●

### 第50页

扩展性差：若需新增参数（如均衡电流限制），会进一步加剧混乱，且所有调用处都需修
改。
6.4 规则-单个函数圈复杂度不超过9，整体文件的平均每个函
数圈复杂度不超过5
说明：圈复杂度（Cyclomatic Complexity）是衡量代码逻辑复杂度的指标，反映函数中独
立执行路径的数量（计算公式：分支数 + 1，分支包括if、else、switch、case、for、
while、&&、||、?:等）。圈复杂度越高，代码越难理解、测试和维护。
正面案例
复制代码
●
//=========== 正面案例
// 1. 拆分：独立检查电芯电压故障（圈复杂度3）
static BMS_fault_e CELL_check_voltage_fault(void)
{
    if (CELL_voltage_check_over())
    {
        return BMS_FAULT_CELL_OV;
    }
    else if (CELL_voltage_check_under())
    {
        return BMS_FAULT_CELL_UV;
    }
    return BMS_FAULT_NONE;
}
// 2. 拆分：独立检查温度故障（圈复杂度4）
static BMS_fault_e CELL_check_temperature_fault(void)
{
    if (CELL_temperature_check_over_heat())
    {
        // 用单独函数消除逻辑与（&&）带来的分支
        if (CELL_is_valid_over_heat())
        {
            return BMS_FAULT_TEMP_OVER;
        }
    }
    else if (CELL_temperature_check_under_heat())
    {
        return BMS_FAULT_TEMP_UNDER;
    }
    return BMS_FAULT_NONE;
}

### 第51页

// 2.1 辅助函数：消除逻辑与（&&）分支（圈复杂度2）
static bool CELL_is_valid_over_heat(void)
{
    return (CELL_temperature_get() > 80) &&
(!CELL_temp_sensor_is_faulty());
}
// 3. 拆分：独立检查通信故障（圈复杂度3）
static BMS_fault_e CELL_check_comm_fault(void)
{
    if (CAN_check_comm_fault())
    {
        if (CAN_get_last_comm_time() > 1000)
        {
            return BMS_FAULT_CAN_TIMEOUT;
        }
        else
        {
            return BMS_FAULT_CAN_ERROR;
        }
    }
    return BMS_FAULT_NONE;
}
// 主函数：汇总检查结果（圈复杂度4 = 3个分支 + 1）
BMS_fault_e CELL_fheck_fault(void)
{
    // 检查电芯电压故障
    BMS_fault_e fault = CELL_check_voltage_fault();
    if (fault != BMS_FAULT_NONE)
    {
        return fault;
    }
    // 检查温度故障
    fault = CELL_check_temperature_fault();
    if (fault != BMS_FAULT_NONE)
    {
        return fault;
    }
    // 检查均衡故障（无分支，直接返回）
    if (CELL_balance_check_fault())
    {

### 第52页

正面案例优势分析：
复杂度降低：主函数圈复杂度 3，各子函数复杂度≤4，均远低于 9，逻辑清晰。
测试简单：每个子函数可单独测试，测试用例设计更直观。
维护便捷：修改某类故障逻辑（如温度故障）时，只需调整Check_temperature_fault ，
不影响其他模块。
扩展性强：新增故障类型（如 “电流异常”）时，只需新增Check_current_fault 子函数，
主函数中添加一行调用即可。
反面案例
复制代码
        return BMS_FAULT_BALANCE;
    }
    // 检查通信故障
    return CELL_check_comm_fault();
}
●
●
●
●
●
//=========== 反面案例：圈复杂度10（超过9），逻辑分支混乱
BMS_fault_e BMS_check_fault(void)
{
    // 1. 检查电芯过压（分支1）
    if (CELL_voltage_check_over_voltage())
    {
        return BMS_FAULT_CELL_OV;
    }
    else if (CELL_voltage_check_under_voltage())  // 2. 检查电芯欠压（分支
2）
    {
        return BMS_FAULT_CELL_UV;
    }
    else if (CELL_temperature_check_over_heat())  // 3. 检查温度过高（分支
3）
    {
        if (CELL_temperature_get() > 80 &&
!CELL_tempSensor_is_faulty())   // 3.1 逻辑与（&&）等价于分支4
        {
            return BMS_FAULT_TEMP_OVER;
        }
    }
    else if (CELL_temperature_check_under_heat()) // 4. 检查温度过低（分支
5）
    {
        return BMS_FAULT_TEMP_UNDER;
    }

### 第53页

反面案例问题分析：
逻辑嵌套深：Temperature_CheckOverHeat() 内部又嵌套if ，且包含&& 逻辑，增加理
解难度。
测试覆盖难：需设计至少 10 种测试用例才能覆盖所有分支，易遗漏边缘场景（如 “温度
过高且传感器故障” 的处理）。
维护风险高：修改某一故障判断逻辑（如调整过压阈值）时，可能误影响其他分支，尤其
在复杂嵌套中。
6.5 建议-重复代码应该尽可能提炼成函数
说明：重复代码会导致代码冗余，可读性差，且每次修改都要更改多个地方，会严重增加维
护难度，所以把重复代码提炼成函数可以大大降低维护成本。
反面案例
以电池单体电压故障检测为例，假设 BMS 管理 16 串电池，需对每串电池检测过压
（>4.2V）、欠压（<2.5V），未提炼函数的代码如下：
反面案例
复制代码
    else if (CELL_balance_check_fault())  // 5. 检查均衡故障（分支6）
    {
        return BMS_FAULT_BALANCE;
    }
    else if (CAN_check_comm_fault())  // 6. 检查CAN通信故障（分支7）
    {
        if (CAN_get_last_comm_time() > 1000)  // 6.1 通信超时子分支（分支
8）
        {
            return BMS_FAULT_CAN_TIMEOUT;
        }
        else
        {
            return BMS_FAULT_CAN_ERROR; // 分支9
        }
    }
    // 无故障
    return BMS_FAULT_NONE;
}
●
●
●
●
//=========== 反面案例
#include <stdint.h>
#include <stdbool.h>

### 第54页

#define CELL_NUM                16U      // 电池串数
#define CELL_OVER_VOLT_THRESH   4200U    // 过压阈值(mV)
#define CELL_UNDER_VOLT_THRESH  2500U    // 欠压阈值(mV)
// 电池电压，mV
uint16_t g_cell_voltage[CELL_NUM] = {4250, 3800, 2450, 4100, 3900,
2600, 4200, 3700,
                                   4300, 3850, 2550, 4000, 3950, 2700,
4150, 3600};
bool g_cell_overvoltage[CELL_NUM] = {false}; // 过压故障标志
bool g_cell_undervoltage[CELL_NUM] = {false};// 欠压故障标志
/**
 * @brief  未提炼函数的电池故障检测
 * @note   None
 * @retval None
 */
void BMS_cell_fault_check(void)
{
    // 第1串电池故障检测
    if (g_cell_voltage[0] > CELL_OVER_VOLT_THRESH)
    {
        g_cell_overvoltage[0] = true;
    }
    else
    {
        g_cell_overvoltage[0] = false;
    }
    if (g_cell_voltage[0] < CELL_UNDER_VOLT_THRESH)
    {
        g_cell_undervoltage[0] = true;
    }
    else
    {
        g_cell_undervoltage[0] = false;
    }
    // 第2串电池故障检测（重复第1串逻辑）
    if (g_cell_voltage[1] > CELL_OVER_VOLT_THRESH)
    {
        g_cell_overvoltage[1] = true;
    }
    else
    {
        g_cell_overvoltage[1] = false;

### 第55页

}
    if (g_cell_voltage[1] < CELL_UNDER_VOLT_THRESH)
    {
        g_cell_undervoltage[1] = true;
    }
    else
    {
        g_cell_undervoltage[1] = false;
    }
    // 第3串电池故障检测（仅示例，省略4~15串）
    if (g_cell_voltage[2] > CELL_OVER_VOLT_THRESH)
    {
        g_cell_overvoltage[2] = true;
    }
    else
    {
        g_cell_overvoltage[2] = false;
    }
    if (g_cell_voltage[2] < CELL_UNDER_VOLT_THRESH)
    {
        g_cell_undervoltage[2] = true;
    }
    else
    {
        g_cell_undervoltage[2] = false;
    }
    // ... 中间省略第4~15串的重复代码 ...
    // 第16串电池故障检测（继续重复）
    if (g_cell_voltage[CELL_NUM - 1] > CELL_OVER_VOLT_THRESH)
    {
        g_cell_overvoltage[CELL_NUM - 1] = true;
    }
    else
    {
        g_cell_overvoltage[CELL_NUM - 1] = false;
    }
    if (g_cell_voltage[CELL_NUM - 1] < CELL_UNDER_VOLT_THRESH)
    {
        g_cell_undervoltage[CELL_NUM - 1] = true;
    }
    else
    {

### 第56页

反面案例的弊端
1. 代码冗余：16 串电池需写 16 次几乎相同的逻辑，代码量暴增；
2. 维护困难：若需修改判断逻辑，需修改 16 处；
3. 易出错：手动复制粘贴时，易出现数组下标写错（如把[5] 写成[6] ）；
4. 可读性差：重复代码掩盖核心逻辑，排查故障时需翻找大量冗余代码。
正面案例
针对上述场景，提炼单串电池故障检测函数和批量检测函数，代码量大幅减少且可维护性提
升
正面案例
复制代码
        g cell undervoltage[CELL NUM - 1] = false;
●
//=========== 正面案例
#include <stdint.h>
#include <stdbool.h>
#define CELL_NUM                16U      // 电池串数
#define CELL_OVER_VOLT_THRESH   4200U    // 过压阈值(mV)
#define CELL_UNDER_VOLT_THRESH  2500U    // 欠压阈值(mV)
// 电池电压，mV
uint16_t g_cell_voltage[CELL_NUM] = {4250, 3800, 2450, 4100, 3900,
2600, 4200, 3700,
                                   4300, 3850, 2550, 4000, 3950, 2700,
4150, 3600};
bool g_cell_overvoltage[CELL_NUM] = {false}; // 过压故障标志
bool g_cell_undervoltage[CELL_NUM] = {false};// 欠压故障标志
/**
 * @brief  单串电池过压/欠压故障检测通用函数
 * @param  cell_volt: 单体电压（mV）
 * @param  p_over: 过压故障标志指针
 * @param  p_under: 欠压故障标志指针
 * @param  over_thresh: 过压阈值（mV）
 * @param  under_thresh: 欠压阈值（mV）
 * @retval None
 */
void BMS_check_single_cell_fault(uint16_t cell_volt, bool* p_over,
bool* p_under,
                              uint16_t over_thresh, uint16_t
under_thresh)
{

### 第57页

正面案例的优势
1. 代码简洁：通过循环 + 函数，16 串电池的检测逻辑仅需几行代码；
2. 易维护：修改检测逻辑时，只需改BMS_check_single_cell_fault，无需改 16 处；
3. 可复用：BMS_check_single_cell_fault可直接用于其他 BMS 模组（如从机检测单体故
障）；
4. 鲁棒性高：添加了空指针检查，避免嵌入式中常见的崩溃问题；
5. 可读性强：函数名清晰表达功能，核心逻辑一目了然。
6.6 规则-外部函数（未使用static修饰），需要对函数入参的
合法性进行校验
说明：外部调用的函数，其传入的参数是不可靠的，不进行校验，可能导致函数访问空指针
或者数组操作越界等情况
复制代码
    // 边界检查
    if (p_over == NULL || p_under == NULL)
    {
        return;
    }
    // 过压检测
    *p_over = (cell_volt > over_thresh) ? true : false;
    // 欠压检测
    *p_under = (cell_volt < under_thresh) ? true : false;
}
/**
 * @brief  批量电池故障检测函数（提炼后）
 * @note   循环调用通用函数，无重复代码
 * @retval None
 */
void BMS_batch_cell_fault_check(void)
{
    // 循环处理所有电池串，避免重复代码
    for (uint8_t i = 0; i < CELL_NUM; i++)
    {
        BMS_check_single_cell_fault(g_cell_voltage[i],
&g_cell_overvoltage[i], &g_cell_undervoltage[i],
            CELL_OVER_VOLT_THRESH, CELL_UNDER_VOLT_THRESH);
    }
}

### 第58页

6.7 规则-对函数的错误返回码要全面处理
说明：函数错误码需要全面处理，如果有没处理的错误码，需要进行注释，标明考虑到了每
一个异常分支
下面的电芯电压采集接口，正常情况有两种失败可能，正常案例中全面处理所有的错误分
支；反面案例中没有处理错误码，导致未对异常情况进行处理
正面案例
复制代码
bool CELL_balance_control(uint8_t cell_idx, const CELL_balance_params_t
*params)
{
    // 参数合法性检查（如果没有校验，可能出现访问空指针，或者使用idx时出现越界
的情况）
    if ((cell_idx >= CELL_MAX_NUM) || (params == NULL))
    {
        return false;
    }
    // code
    return true;
}
●
//=========== 正面案例
// 1. 电芯电压采集
static BMS_error_e CELL_voltage_read(uint8_t cell_idx, uint16_t*
voltage)
{
    // 模拟ADC采集失败
    if (!ADC_Is_ready())
    {
        return BMS_ERR_ADC_READ;
    }

    // 模拟电芯断线
    if (ADC_Read_raw(cell_idx) > MAX_RAW)
    {
        return BMS_ERR_CELL_DISCONNECT;
    }

    *voltage = ADC_Convert_to_mv();

### 第59页

return BMS_SUCCESS;
}
// 2. 主处理函数（全面处理所有错误码）
void CELL_main_process(void)
{
    uint16_t voltage = 0;
    // 处理电芯0电压采集
    BMS_error_e err = CELL_voltage_read(0, &voltage);
    switch (err)
    {
        case BMS_SUCCESS:
        {
            // 正常逻辑：更新电压数据
            s_cell_voltage[0] = voltage;
            break;
        }
        case BMS_ERR_ADC_READ:
        {
            // 处理ADC失败：重试2次，切换备用通道
            uint8_t retry;
            for (retry = 0; retry < 2; retry++)
            {
                if (CELL_voltage_read(0, &voltage) == BMS_SUCCESS)
                {
                    s_cell_voltage[0] = voltage;
                    break;
                }
            }
            if (retry == 2)
            {
                CELL_fault_record(BMS_ERR_ADC_READ, 0);
                BMS_enter_safe_mode(); // 多次失败，进入安全模式
            }
            break;
        }
        case BMS_ERR_CELL_DISCONNECT:
        {
            // 处理电芯断线：标记故障，禁止充放电
            g_cell_state[0] = CELL_STATE_DISCONNECTED;
            CELL_charge_disable();
            CELL_discharge_disable();
            CELL_fault_record(BMS_ERR_CELL_DISCONNECT, 0);
            break;

### 第60页

反面案例
复制代码
        }
        default:
        {
            // 处理未知错误（防御性编程）
            CELL_fault_record(err, 0);
            break;
        }
    }
    // code
//=========== 反面案例
// 电芯电压采集函数（返回错误码）
static BMS_error_e CELL_voltage_read(uint8_t cell_idx, uint16_t*
voltage)
{
    // 模拟ADC采集失败
    if (!ADC_Is_ready())
    {
        return BMS_ERR_ADC_READ;
    }

    // 模拟电芯断线
    if (ADC_Read_raw(cell_idx) > MAX_RAW)
    {
        return BMS_ERR_CELL_DISCONNECT;
    }

    *voltage = ADC_Convert_to_mv();

    return BMS_SUCCESS;
}
// 2. 主处理函数
void CELL_main_process(void)
{
    uint16_t voltage;
    // 问题：忽略CellVoltage_Read的返回码，无法感知采集失败
    CELL_voltage_read(0, &voltage);
    // code
}

### 第61页

6.8 规则-内容不会被修改的指针形参使用const修饰
说明：BMS 开发中const 修饰不变参数的关键场景
正面案例
复制代码
反面案例
复制代码
●
//=========== 正面案例
/**
 * @brief  检查电池电压是否触发保护
 * @param  cell_volt: 输入-当前单体电压
 * @param  config: 输入-保护配置（只读），加const保护
 * @retval 0=正常，1=过充，2=过放
 */
uint8_t bms_check_volt_protect(uint16_t cell_volt, const
BMS_ProtectConfig* config) {
    if (config == NULL) return 0;
    config->over_charge_volt = 4200; // 编译器报错：只读内容不能修改
    if (cell_volt > config->over_charge_volt) {
        return 1; // 过充保护
    } else if (cell_volt < config->over_discharge_volt) {
        return 2; // 过放保护
    }
    return 0;
}
//=========== 反面案例
/**
 * @brief  检查电池电压是否触发保护
 * @param  cell_volt: 输入-当前单体电压
 * @param  config: 输入-保护配置
 * @retval 0=正常，1=过充，2=过放
 */
uint8_t bms_check_volt_protect(uint16_t cell_volt, BMS_ProtectConfig*
config) {
    if (config == NULL) return 0;
    config->over_charge_volt = 4200; // 过压阈值被修改，导致判断出错
    if (cell_volt > config->over_charge_volt) {
        return 1; // 过充保护

### 第62页

6.9 规则-检查函数所有非参数输入的有效性，如数据文件、公
共变量等
说明：数据文件，公共变量等非函数输入参数，也是不可靠的，需要进行有效性校验，确保
程序的可靠
正面案例
复制代码
    } else if (cell_volt < config->over_discharge_volt) {
        return 2; // 过放保护
    }
    return 0;
}
//=========== 正面案例：严格检查全局变量、存储数据等非参数输入的有效性
#define CELL_COUNT_MIN 3
#define CELL_COUNT_MAX 16
#define CELL_OV_TERESHOLDS_MIN 4100
#define CELL_OV_TERESHOLDS_MAX 4200
// 1. Flash配置数据及校验（增加校验和）
typedef struct
{
    uint32_t balance_max_time; // 最大均衡时长(ms)，范围[1000, 10000]
    uint16_t balance_diff;     // 均衡电压差(mV)，范围[50, 200]
    uint16_t checksum;         // 校验和（检测数据是否损坏）
} Balance_config_t;
Balance_config_t g_flash_balance_cfg;
// 2. 全局变量及约束（定义合理范围）
uint8_t g_cell_count; // 电芯数量（需在[3,16]范围内）
uint16_t g_ov_thresholds[CELL_MAX_NUM]; // 过压阈值（需在[4100,4200]mV）
// 3. 电芯电压采集函数（运行时检查全局变量有效性）
void CELL_voltage_collect(void)
{
    // 检查g_cell_count
    if ((g_cell_count < CELL_COUNT_MIN) || (g_cell_count >
CELL_COUNT_MAX))
    {
        CELL_fault_record(FAULT_CELL_COUNT_CORRUPTED, 0);
        BMS_enter_safe_mode(); // 进入安全模式，停止采集
        return;
    }

### 第63页

// 正常采集（范围已保证，不会越界）
    for (uint8_t i = 0; i < g_cell_count; i++)
    {
        g_cell_voltages[i] = ADC_Read(i);
    }
}
// 4. 过压判断函数（检查阈值有效性）
bool CELL_voltage_check_over_voltage(uint8_t cell_idx)
{
    // 检查索引和阈值有效性
    if ((cell_idx >= g_cell_count) || (g_ov_thresholds[cell_idx] <
CELL_OV_TERESHOLDS_MIN) ||
        (g_ov_thresholds[cell_idx] > CELL_OV_TERESHOLDS_MAX))
    {
        CELL_fault_record(FAULT_OV_CHECK_INVALID, cell_idx);
        return false; // 阈值无效时，返回安全状态（避免误判）
    }
    return g_cell_voltages[cell_idx] > g_ov_thresholds[cell_idx];
}
// 3. 辅助函数：计算校验和（验证数据完整性）
static uint16_t CELL_calc_check_sum(const void* data, uint32_t len)
{
    uint16_t checksum = 0;
    const uint8_t* bytes = (const uint8_t*)data;
    for (uint32_t i = 0; i < len; i++)
    {
        checksum ^= bytes[i];
    }
    return checksum;
}
// 5. 均衡控制函数（检查Flash配置有效性）
void CELL_balance_Control(uint8_t cell_idx)
{
    // 校验Flash均衡配置（检查校验和及范围）
    Balance_config_t temp_cfg;
    if (FLASH_read(BALANCE_CFG_ADDR, &temp_cfg, sizeof(temp_cfg)) !=
FLASH_OK)
    {
        CELL_fault_record(FAULT_FLASH_READ_FAIL, 0);
        return;

### 第64页

反面案例
复制代码
    }
    // 先验证校验和（确保数据未损坏）
    uint16_t calc_checksum =
CELL_calc_check_sum(&temp_cfg.balance_max_time, (sizeof(temp_cfg) -
sizeof(temp_cfg.checksum)));
    if (calc_checksum != temp_cfg.checksum)
    {
        CELL_fault_Record(FAULT_FLASH_CHECKSUM_ERR, 0);
        return;
    }
    // 检查配置数据
    if ((g_flash_balance_cfg.balance_max_time < 1000) ||
(g_flash_balance_cfg.balance_max_time > 10000) ||
        (g_flash_balance_cfg.balance_diff < 50) ||
(g_flash_balance_cfg.balance_diff > 200))
    {
        CELL_fault_Record(FAULT_BALANCE_CFG_CORRUPTED, 0);
        CELL_balance_stop_all(); // 配置无效时，停止所有均衡
        return;
    }
    g_flash_balance_cfg = temp_cfg;
    // 正常均衡逻辑
    if (g_cell_voltages[cell_idx] - g_avg_voltage >
g_flash_balance_cfg.balance_diff)
    {
        Balance_start(cell_idx, g_flash_balance_cfg.balance_max_time);
    }
//=========== 反面案例：未检查全局变量、Flash数据等非参数输入的有效性
// 1. Flash存储的配置数据（非参数输入）
typedef struct
{
    uint32_t balance_max_time; // 最大均衡时长(ms)
    uint16_t balance_diff;     // 均衡启动电压差(mV)
} Balance_config_t;
Balance_config_t g_flash_balance_cfg; // 从Flash读取的配置（可能损坏）
// 2. 全局公共变量（非参数输入）
uint8_t g_cell_count; // 电芯数量（由外部初始化，可能异常）
uint16_t g_ov_thresholds[CELL_MAX_NUM]; // 过压阈值（可能未初始化）

### 第65页

6.10 规则-仅文件内部使用的函数，增加static修饰
// 3. 电芯电压采集函数（依赖全局变量g_cell_count，未检查）
void CELL_voltage_collect(void)
{
    // 问题1：未检查g_cell_count的有效性（可能为0或超过硬件支持的最大数量）
    for (uint8_t i = 0; i < g_cell_count; i++)
    {
        g_cell_voltages[i] = ADC_Read(i); // 若g_cell_count=20（硬件仅支持
16），越界访问
    }
}
// 4. 过压判断函数（依赖全局阈值数组，未检查）
bool CELL_voltage_check_over_voltage(uint8_t cell_idx)
{
    // 问题2：未检查g_ov_thresholds是否初始化（可能为0或异常值）
    if (g_cell_voltages[cell_idx] > g_ov_thresholds[cell_idx])
    {
        return true;
    }
    return false; // 若g_ov_thresholds为0，所有电芯都会被误判为过压
}
// 5. 均衡控制函数（依赖Flash配置数据，未检查）
void CELL_balance_Control(uint8_t cell_idx)
{
    // 问题3：读取Flash配置后未校验（可能因Flash损坏导致数据异常）
    FLASH_read(BALANCE_CFG_ADDR, &g_flash_balance_cfg,
sizeof(g_flash_balance_cfg));

    // 问题4：未检查Flash配置数据的合理性（如balance_max_time为0或过大）
    if (g_cell_voltages[cell_idx] - g_avg_voltage >
g_flash_balance_cfg.balance_diff)
    {
        CELL_balance_start(cell_idx,
g_flash_balance_cfg.balance_max_time);
        // 若balance_max_time=0，均衡立即结束；若=1e9，可能导致电芯过放
    }
}

### 第66页

说明：所有非对外的函数接口，都要增加static关键字，否则外部调用时，可能导致异常情况
发生（如外部传参不合理，但函数中未进行参数有效性校验等）
示例
复制代码
7. 安全性
7.1 规则-局部变量大小不能超过256字节
说明：
局部变量默认存储在栈中，而栈大小是有限的，栈空间被所有嵌套调用的函数共享
（函数 A 调用函数 B，A 和 B 的局部变量都占栈），且栈还需存储函数返回地址、
寄存器值等，所以局部变量不宜过大；
当有大空间需求时（超过256字节），可以定义全局变量
7.2 规则-编程时，要防止差1错误
说明：边界/范围的起始终止条件判断常见失误（多算1个或者漏算1个），常出现在循环、数
组操作等场景；编码过程中，要特别注意防止差1错误
反面案例
复制代码
static bool BMS_check_total_voltage(uint16_t total_voltage, const
uint16_t threshold)
{
    // code
}
○
○
//=========== 反面案例
#define BMS_MAX_CELL_NUM 16  // 最大支持电芯数量（数组容量为16）
typedef struct
{
    uint16_t cell_voltages[BMS_MAX_CELL_NUM];  // 电芯电压数组（索引0-15）
    uint8_t curr_cell_num;                     // 当前电芯数量（1-16）
} BMS_cell_voltage_t;
static BMS_cell_voltage_t g_cell_voltage = {0};
// 初始化当前电芯数量
void BMS_init_curr_cell_num(uint8_t cell_num)
{

### 第67页

正面案例
复制代码
    if ((cell_num == 0) || (cell_num > BMS_MAX_CELL_NUM))
    {
        return;
    }
    g_cell_voltage.curr_cell_num = cell_num;
}
// 读取指定索引的电芯电压
uint16_t BMS_read_cell_voltage(uint8_t cell_idx, bool* is_valid)
{
    if ((is_valid != NULL))
    {
        *is_valid = false;
    }
    // 问题1：判断条件使用 "<="，允许访问索引等于curr_cell_num（实际有效索引
为0~curr_cell_num-1）
    if ((cell_idx <= g_cell_voltage.curr_cell_num) && (cell_idx <
BMS_MAX_CELL_NUM))
    {
        *is_valid = true;
        return g_cell_voltage.cell_voltages[cell_idx];  // 可能访问无效索
引
    }
    return 0;
}
// 遍历所有电芯电压（累加求和）
uint32_t BMS_calc_voltage_sum()
{
    uint32_t sum = 0;
    // 问题2：循环次数多1次，当curr_cell_num=16时，i会达到16（超出数组范围）
    for (uint8_t i = 0; i < g_cell_voltage.curr_cell_num + 1; i++)
    {
        sum += g_cell_voltage.cell_voltages[i];
    }
    return sum;
}
//=========== 正面案例
#define BMS_MAX_CELL_NUM 16  // 最大支持电芯数量（数组容量为16，索引0-15）
typedef struct
{

### 第68页

uint16_t cell_voltages[BMS_MAX_CELL_NUM];  // 电芯电压数组
    uint8_t curr_cell_num;                     // 当前电芯数量（1-16，有效
索引0~curr_cell_num-1）
} BMS_cell_voltage_t;
static BMS_cell_voltage_t g_cell_voltage = {0};
// 初始化当前电芯数量
void BMS_init_curr_cell_num(uint8_t cell_num)
{
    if ((cell_num == 0) || (cell_num > BMS_MAX_CELL_NUM))
    {
        return;
    }
    g_cell_voltage.curr_cell_num = cell_num;
}
// 读取指定索引的电芯电压
uint16_t BMS_read_cell_voltage(uint8_t cell_idx, bool* is_valid)
{
    if ((is_valid != NULL))
    {
        *is_valid = false;
    }
    // 修改1：判断条件使用 "<"，明确有效索引范围为0~curr_cell_num-1
    if ((cell_idx < g_cell_voltage.curr_cell_num) && (cell_idx <
BMS_MAX_CELL_NUM))
    {
        *is_valid = true;
        return g_cell_voltage.cell_voltages[cell_idx];
    }
    return 0;
}
// 遍历所有电芯电压（累加求和）
uint32_t BMS_calc_voltage_sum()
{
    uint32_t sum = 0;
    // 修改2：循环次数严格匹配当前电芯数量，索引范围0~curr_cell_num-1
    for (uint8_t i = 0; i < g_cell_voltage.curr_cell_num; i++)
    {
        sum += g_cell_voltage.cell_voltages[i];
    }
    return sum;

### 第69页

7.3 规则-整数安全
说明：整数安全，主要需要考虑整数的有效性范围，以及进行整数运算时，需要考虑加减法
是否会溢出，除法不能除以0等情况
反面案例
复制代码
}
//=========== 反面案例
#define BMS_MAX_CURRENT 5000  // 最大允许电流（mA）
#define BMS_MIN_CURRENT -2000 // 最小允许电流（mA，负值表示放电）
typedef struct
{
    int32_t current;          // 电流值（mA，支持正负）
    uint16_t overcurrent_cnt; // 过流计数（无符号）
} BMS_current_data_t;
static BMS_current_data_t g_current_data = {0};
// 更新电流值（未检查范围）
void BMS_update_current(int32_t new_current)
{
    // 问题1：未限制输入电流范围，可能超出硬件允许值
    g_current_data.current = new_current;
}
// 过流计数（存在溢出风险）
void BMS_inc_overcurrent_cnt()
{
    // 问题2：无符号整数自增未检查溢出，达到最大值后会回卷为0
    g_current_data.overcurrent_cnt++;
}
// 计算电流差值（未处理溢出）
int32_t BMS_calc_current_diff(int32_t curr, int32_t prev)
{
    // 问题3：直接相减，当curr远小于prev时可能溢出
    return curr - prev;
}
// 判断是否过流（符号判断错误）
bool BMS_is_overcurrent()
{

### 第70页

正面案例
复制代码
    // 问题4：未区分充电/放电方向，仅比较绝对值，可能误判
    if ((abs(g_current_data.current) > BMS_MAX_CURRENT))
    {
        return true;
    }
    return false;
}
//=========== 正面案例
#define BMS_MAX_CURRENT 5000  // 最大充电电流（mA）
#define BMS_MIN_CURRENT -2000 // 最大放电电流（mA，负值）
#define BMS_OVERCURRENT_MAX_CNT 100 // 过流计数最大值
typedef struct
{
    int32_t current;          // 电流值（mA）
    uint16_t overcurrent_cnt; // 过流计数
} BMS_current_data_t;
static BMS_current_data_t g_current_data = {0};
// 更新电流值（限制范围）
void BMS_update_current(int32_t new_current)
{
    // 修改1：限制电流在硬件允许范围内，超出则钳位
    if ((new_current > BMS_MAX_CURRENT))
    {
        g_current_data.current = BMS_MAX_CURRENT;
    }
    else if ((new_current < BMS_MIN_CURRENT))
    {
        g_current_data.current = BMS_MIN_CURRENT;
    }
    else
    {
        g_current_data.current = new_current;
    }
}
// 过流计数（防止溢出）
void BMS_inc_overcurrent_cnt()
{
    // 修改2：检查是否达到最大值，避免无符号整数回卷
    if ((g_current_data.overcurrent_cnt < BMS_OVERCURRENT_MAX_CNT))

### 第71页

7.4 规则-字符串操作安全
说明：字符串操作时，需要注意字符串长度、字符串结束符等
反面案例
复制代码
    {
        g_current_data.overcurrent_cnt++;
    }
}
// 计算电流差值（处理溢出）
int32_t BMS_calc_current_diff(int32_t curr, int32_t prev, bool*
is_valid)
{
    if ((is_valid != NULL))
    {
        *is_valid = false;
    }
    // 修改3：通过范围判断避免减法溢出
    if (((curr > 0) && (prev < INT32_MIN + curr)) || ((curr < 0) &&
(prev > INT32_MAX + curr)))
    {
        return 0; // 溢出时返回无效值
    }
    if ((is_valid != NULL))
    {
        *is_valid = true;
    }
    return curr - prev;
}
// 判断是否过流（区分方向）
bool BMS_is_overcurrent()
{
    // 修改4：区分充电（正）和放电（负）方向，分别判断阈值
    if ((g_current_data.current > BMS_MAX_CURRENT) ||
(g_current_data.current < BMS_MIN_CURRENT))
    {
        return true;
    }
    return false;
}

### 第72页

//=========== 反面案例
#define BMS_ERR_MSG_MAX_LEN 32  // 错误信息最大长度（含结束符）
typedef struct
{
    char err_msg[BMS_ERR_MSG_MAX_LEN];  // 错误信息字符串
} BMS_error_info_t;
static BMS_error_info_t g_error_info = {0};
// 设置错误信息（未检查长度）
void BMS_set_error_msg(const char* msg)
{
    if ((msg == NULL))
    {
        return;
    }
    // 问题1：strcpy不检查目标缓冲区大小，若msg过长会导致缓冲区溢出
    strcpy(g_error_info.err_msg, msg);
}
// 拼接错误信息（未控制总长度）
void BMS_append_error_msg(const char* suffix)
{
    if ((suffix == NULL) || (g_error_info.err_msg[0] == '\0'))
    {
        return;
    }
    // 问题2：strcat可能导致拼接后总长度超过缓冲区容量，引发溢出
    strcat(g_error_info.err_msg, suffix);
}
// 读取错误信息（未验证结束符）
const char* BMS_get_error_msg()
{
    // 问题3：直接返回字符串，若缓冲区未正常终止（如溢出覆盖了'\0'），会导致读
取越界
    return g_error_info.err_msg;
}
// 初始化错误信息（未清空缓冲区）
void BMS_init_error_msg()
{
    // 问题4：仅设置首字符为结束符，未清空整个缓冲区，残留旧数据可能干扰判断
    g_error_info.err_msg[0] = '\0';

### 第73页

正面案例
复制代码
}
//=========== 正面案例
#define BMS_ERR_MSG_MAX_LEN 32  // 错误信息最大长度（含结束符，有效字符最多
31个）
typedef struct
{
    char err_msg[BMS_ERR_MSG_MAX_LEN];  // 错误信息字符串
} BMS_error_info_t;
static BMS_error_info_t g_error_info = {0};
// 设置错误信息（限制长度，防止溢出）
void BMS_set_error_msg(const char* msg)
{
    if ((msg == NULL))
    {
        return;
    }
    // 修改1：使用strncpy限制拷贝长度，确保不超过缓冲区容量
    strncpy(g_error_info.err_msg, msg, BMS_ERR_MSG_MAX_LEN - 1);
    // 强制添加结束符，避免字符串未终止
    g_error_info.err_msg[BMS_ERR_MSG_MAX_LEN - 1] = '\0';
}
// 拼接错误信息（控制总长度）
void BMS_append_error_msg(const char* suffix)
{
    if ((suffix == NULL))
    {
        return;
    }
    // 获取当前字符串长度
    uint16_t curr_len = strlen(g_error_info.err_msg);
    // 计算剩余可拼接空间（预留1字节给结束符）
    uint16_t remaining = BMS_ERR_MSG_MAX_LEN - curr_len - 1;
    if ((remaining == 0))
    {
        return;  // 空间不足时终止拼接
    }
    // 修改2：使用strncat限制拼接长度，确保总长度不溢出
    strncat(g_error_info.err_msg, suffix, remaining);
}

### 第74页

7.5 规则-if语句必须加上else分支（卫语句例外，其他场景均
需要）；switch语句必须有default分支。
说明：如果确实没有else的相关操作，写上一个空的else，表明考虑了else的情况；
反面案例
复制代码
// 读取错误信息（验证有效性）
const char* BMS_get_error_msg(bool* is_valid)
{
    if ((is_valid != NULL))
    {
        *is_valid = false;
    }
    // 修改3：检查字符串是否正常终止且长度合法
    if ((strlen(g_error_info.err_msg) < BMS_ERR_MSG_MAX_LEN))
    {
        if ((is_valid != NULL))
        {
            *is_valid = true;
        }
        return g_error_info.err_msg;
    }
    return "Invalid error message";  // 异常时返回默认安全字符串
}
// 初始化错误信息（彻底清空缓冲区）
void BMS_init_error_msg()
{
    // 修:4：用memset清空整个缓冲区，避免残留数据干扰
    memset(g_error_info.err_msg, 0, BMS_ERR_MSG_MAX_LEN);
}
//=========== if反面案例
// 设置电芯均衡使能状态
// 风险：if仅处理压差超标场景，缺失else分支，压差正常时均衡使能状态未重置
// 未遵循“if语句尽量加else分支”规范，易导致均衡电路持续工作引发电芯过放
void BMS_set_balance_enable(uint16_t cell_diff)
{
    if ((cell_diff > BMS_CELL_BALANCE_DIFF_THRESHOLD))
    {
        g_balance_enable = true;
        g_balance_fault_code = BMS_FAULT_NONE;

### 第75页

}
}
//=========== switch反面案例
// BMS故障等级宏定义
#define BMS_FAULT_LEVEL_NONE      0   // 无故障
#define BMS_FAULT_LEVEL_WARNING   1   // 警告级故障
#define BMS_FAULT_LEVEL_ERROR     2   // 错误级故障
#define BMS_FAULT_LEVEL_CRITICAL  3   // 严重级故障
// 故障应对动作宏定义
#define BMS_ACTION_NONE           0   // 无操作
#define BMS_ACTION_ALARM          1   // 仅告警
#define BMS_ACTION_LIMIT_POWER    2   // 限功率
#define BMS_ACTION_SHUTDOWN       3   // 紧急停机
static uint8_t g_fault_action = BMS_ACTION_NONE; // 故障应对动作
// 执行BMS故障应对逻辑
// 风险：switch无default分支，非法故障等级时无兜底处理，动作状态悬空
void BMS_handle_fault(uint8_t fault_level)
{
    switch (fault_level)
    {
        case BMS_FAULT_LEVEL_NONE:
        {
            g_fault_action = BMS_ACTION_NONE;
            break;
        }
        case BMS_FAULT_LEVEL_WARNING:
        {
            g_fault_action = BMS_ACTION_ALARM;
            break;
        }
        case BMS_FAULT_LEVEL_ERROR:
        {
            g_fault_action = BMS_ACTION_LIMIT_POWER;
            break;
        }
        case BMS_FAULT_LEVEL_CRITICAL:
        {
            g_fault_action = BMS_ACTION_SHUTDOWN;
            break;
        }
        // 缺失default分支：传入4/5等非法值时，g_fault_action保持原值

### 第76页

正面案例
复制代码
    }
//=========== if正面案例
// 设置电芯均衡使能状态
// 遵循“if语句尽量加else分支”规范，覆盖压差超标/正常全场景，状态闭环无悬空
void BMS_set_balance_enable(uint16_t cell_diff)
{
    if ((cell_diff > BMS_CELL_BALANCE_DIFF_THRESHOLD))
    {
        g_balance_enable = true;
        g_balance_fault_code = BMS_FAULT_NONE;
    }
    else
    {
        g_balance_enable = false;
        g_balance_fault_code = BMS_FAULT_NONE;
    }
    // 或者确实没有else的相关操作，写上一个空的else，表明考虑了else的情况
    if ((cell_diff > BMS_CELL_BALANCE_DIFF_THRESHOLD))
    {
        g_balance_enable = true;
        g_balance_fault_code = BMS_FAULT_NONE;
    }
    else
    {
    }
}
//=========== switch正面案例
// BMS故障等级宏定义
#define BMS_FAULT_LEVEL_NONE      0   // 无故障
#define BMS_FAULT_LEVEL_WARNING   1   // 警告级故障
#define BMS_FAULT_LEVEL_ERROR     2   // 错误级故障
#define BMS_FAULT_LEVEL_CRITICAL  3   // 严重级故障
// 故障应对动作宏定义
#define BMS_ACTION_NONE           0   // 无操作
#define BMS_ACTION_ALARM          1   // 仅告警
#define BMS_ACTION_LIMIT_POWER    2   // 限功率
#define BMS_ACTION_SHUTDOWN       3   // 紧急停机
#define BMS_ACTION_INVALID        4   // 非法等级：告警+限功率（兜底动作）
static uint8_t g_fault_action = BMS_ACTION_NONE; // 故障应对动作

### 第77页

例外：卫语句场景
先搞懂：卫语句是什么？
卫语句的核心思想是：把 “不满足核心逻辑的条件” 提前判断，一旦满足就直接退出
（return/break/continue），剩下的代码只处理 “满足核心逻辑” 的情况。
可以把它理解成：
static bool g_invalid_fault_flag = false;        // 非法故障等级标记
// 执行BMS故障应对逻辑
// 遵循“switch必须有default分支”规范，兜底处理非法故障等级，逻辑闭环
void BMS_handle_fault(uint8_t fault_level)
{
    g_invalid_fault_flag = false; // 重置非法标记
    switch (fault_level)
    {
        case BMS_FAULT_LEVEL_NONE:
        {
            g_fault_action = BMS_ACTION_NONE;
            break;
        }
        case BMS_FAULT_LEVEL_WARNING:
        {
            g_fault_action = BMS_ACTION_ALARM;
            break;
        }
        case BMS_FAULT_LEVEL_ERROR:
        {
            g_fault_action = BMS_ACTION_LIMIT_POWER;
            break;
        }
        case BMS_FAULT_LEVEL_CRITICAL:
        {
            g_fault_action = BMS_ACTION_SHUTDOWN;
            break;
        }
        default:
        {
            // 兜底处理非法故障等级：告警+限功率，同时标记异常便于调试
            g_fault_action = BMS_ACTION_INVALID;
            g_invalid_fault_flag = true;
            break;
        }
    }
}

### 第78页

函数 / 代码块的 “门卫”—— 先检查所有 “不符合进门条件” 的情况，直接拒之门外；符合条
件的，才能走到核心逻辑部分。
复制代码
复制代码
//=========== 反面案例
// 解析485接收的数据
int RS485_parse_rs485_data(uint8_t* data, uint16_t len)
{
    int ret = -1;
    if (data != NULL) {          // 条件1：数据非空
        if (len > 0 && len <= 128) { // 条件2：长度合法
            if (data[0] == 0x01) {   // 条件3：指令头正确
                // 核心逻辑：解析数据
                ret = 0;
            }
        }
    }
    return ret;
}
//=========== 正面案例
// 解析485接收的数据（卫语句版）
int parse_rs485_data(uint8_t* data, uint16_t len) {
    // 卫语句1：数据为空，直接返回错误
    if (data == NULL) {
        return -1;
    }
    // 卫语句2：长度不合法，直接返回错误
    if (len <= 0 || len > 128) {
        return -1;
    }
    // 卫语句3：指令头错误，直接返回错误
    if (data[0] != 0x01) {
        return -1;
    }
    // 核心逻辑：所有前置条件都满足，才执行
    // ... 解析数据的代码
    return 0;
}

### 第79页

7.6 规则-禁止使用goto语句
说明：goto语句会破坏程序的结构性，禁止使用goto语句。
7.7 规则-内存申请后必须有对应释放操作
说明：函数中分配的内存，尽量在函数退出之前释放，特殊场景需要在函数外进行释放的或
者不释放的，需要进行注释说明
反面案例
复制代码
//=========== 反面案例
typedef struct
{
    uint16_t* cell_voltages;
    uint8_t cell_count;
} BMS_voltage_buf_t;
static BMS_voltage_buf_t* g_voltage_buf = NULL;
// 问题1：临时分配的内存未在函数退出前释放
void BMS_calc_voltage_avg(uint8_t count, const uint16_t* voltages)
{
    if (count == 0 || voltages == NULL)
    {
        return;
    }
    // 动态分配临时数组
    uint16_t* sorted_voltages = (uint16_t*)malloc(count *
sizeof(uint16_t));
    if (sorted_voltages == NULL)
    {
        return; // 未分配成功，无泄漏
    }
    memcpy(sorted_voltages, voltages, count * sizeof(uint16_t));
    // 模拟排序逻辑（省略具体实现）
    // 提前退出场景：未释放sorted_voltages
    if (g_voltage_buf == NULL)

### 第80页

正面案例
复制代码
    {
        return; // 此处泄漏sorted_voltages
    }
    // 正常逻辑：计算平均值（省略）
    // ...
    // 正常退出时仍未释放sorted_voltages，导致泄漏
}
// 问题2：初始化失败时，已分配的内存未在退出前释放
bool BMS_init_voltage_buf(uint8_t count)
{
    g_voltage_buf =
(BMS_voltage_buf_t*)malloc(sizeof(BMS_voltage_buf_t));
    if (g_voltage_buf == NULL)
    {
        return false; // 未分配成功，无泄漏
    }
    g_voltage_buf->cell_count = count;
    // 分配内部数组
    g_voltage_buf->cell_voltages = (uint16_t*)malloc(count *
sizeof(uint16_t));
    if (g_voltage_buf->cell_voltages == NULL)
    {
        // 未释放已分配的g_voltage_buf，函数退出时泄漏
        return false;
    }
    return true;
}
//=========== 正面案例
typedef struct
{
    uint16_t* cell_voltages;
    uint8_t cell_count;
} BMS_voltage_buf_t;
static BMS_voltage_buf_t* g_voltage_buf = NULL;
// 修改1：函数内分配的临时内存，在所有退出路径前释放

### 第81页

void BMS_calc_voltage_avg(uint8_t count, const uint16_t* voltages)
{
    if (count == 0 || voltages == NULL)
    {
        return;
    }
    // 动态分配临时数组
    uint16_t* sorted_voltages = (uint16_t*)malloc(count *
sizeof(uint16_t));
    if (sorted_voltages == NULL)
    {
        return; // 未分配成功，无泄漏
    }
    memcpy(sorted_voltages, voltages, count * sizeof(uint16_t));
    // 模拟排序逻辑（省略具体实现）
    // 提前退出场景：退出前释放临时内存
    if (g_voltage_buf == NULL)
    {
        free(sorted_voltages); // 释放后再退出，无泄漏
        return;
    }
    // 正常逻辑：计算平均值（省略）
    // ...
    // 正常退出前释放临时内存
    free(sorted_voltages);
}
// 修改2：初始化失败时，已分配内存均在退出前释放
bool BMS_init_voltage_buf(uint8_t count)
{
    // 先释放旧内存（若存在）
    if (g_voltage_buf != NULL)
    {
        Bms_free_voltage_buf(g_voltage_buf);
        g_voltage_buf = NULL;
    }
    // 分配外层结构体
    BMS_voltage_buf_t* new_buf =
(BMS_voltage_buf_t*)malloc(sizeof(BMS_voltage_buf_t));

### 第82页

7.8 规则-指针或内存操作必须检查索引的有效性
说明：编码时，需遵守以下规则：
1）数字下标使用前需要确保不越界；
2）下标的减法操作时，需要确保不会溢出，且要对结果进行检查；
3）操作缓存空间时，确保不超过缓存长度
反面案例
复制代码
    if (new_buf == NULL)
    {
        return false; // 未分配成功，无泄漏
    }
    new_buf->cell_count = count;
    // 分配内部数组
    new_buf->cell_voltages = (uint16_t*)malloc(count *
sizeof(uint16_t));
    if (new_buf->cell_voltages == NULL)
    {
        free(new_buf); // 退出前释放已分配的外层内存，无泄漏
        return false;
    }
    g_voltage_buf = new_buf;
    return true;
}
// 显式释放全局内存
void BMS_destroy_voltage_buf()
{
    if (g_voltage_buf != NULL)
    {
        // 由里到外逐步释放
        free(g_voltage_buf->cell_voltages);
        g_voltage_buf->cell_voltages = NULL;
        free(g_voltage_buf);
        g_voltage_buf = NULL;
    }
//=========== 反面案例
typedef struct {
    uint16_t* cell_voltages;  // 电芯电压数组

### 第83页

uint8_t max_cell_num;     // 最大电芯数量（数组容量）
    uint8_t curr_cell_num;    // 当前电芯数量（实际使用数量）
} BMS_cell_data_t;
static BMS_cell_data_t* g_cell_data = NULL;
// 初始化函数：未限制数组容量，存在越界隐患
void BMS_init_cell_data(uint8_t cell_num)
{
    g_cell_data = (BMS_cell_data_t*)malloc(sizeof(BMS_cell_data_t));
    if (g_cell_data == NULL)
    {
        return;
    }
    // 问题1：未检查cell_num合理性（如超过硬件支持的最大数量）
    g_cell_data->max_cell_num = cell_num;
    g_cell_data->curr_cell_num = cell_num;
    g_cell_data->cell_voltages = (uint16_t*)malloc(cell_num *
sizeof(uint16_t));
}
// 写入函数：未检查索引范围，直接操作内存
void BMS_write_cell_voltage(uint8_t cell_idx, uint16_t voltage)
{
    if (g_cell_data == NULL)
    {
        return;
    }
    // 问题2：未检查cell_idx是否小于max_cell_num，可能越界写入
    g_cell_data->cell_voltages[cell_idx] = voltage;
}
// 拷贝函数：未限制拷贝长度，导致缓冲区溢出
void BMS_copy_cell_voltages(const uint16_t* src, uint8_t src_len)
{
    if (g_cell_data == NULL || src == NULL)
    {
        return;
    }
    // 问题3：未比较src_len与数组容量，直接 memcpy 导致越界
    memcpy(g_cell_data->cell_voltages, src, src_len * sizeof(uint16_t));
}
// 读取函数：返回超出实际数据范围的内存
uint16_t BMS_read_cell_voltage(uint8_t cell_idx)

### 第84页

正面案例
复制代码
{
    if (g_cell_data == NULL)
    {
        return 0;
    }
    // 问题4：未检查cell_idx是否小于curr_cell_num，可能读取无效内存
    return g_cell_data->cell_voltages[cell_idx];
}
//=========== 正面案例
// 定义硬件支持的最大电芯数量（上限约束）
#define BMS_MAX_SUPPORTED_CELLS 16
typedef struct {
    uint16_t* cell_voltages;  // 电芯电压数组
    uint8_t max_cell_num;     // 最大电芯数量（数组容量）
    uint8_t curr_cell_num;    // 当前电芯数量（实际使用数量）
} BMS_cell_data_t;
static BMS_cell_data_t* g_cell_data = NULL;
// 初始化函数：严格限制数组容量，防止越界
bool BMS_init_cell_data(uint8_t cell_num)
{
    // 先释放旧数据
    if (g_cell_data != NULL)
    {
        BMS_free_cell_data(g_cell_data);
        g_cell_data = NULL;
    }
    // 修改1：检查cell_num是否在合理范围（不超过硬件上限）
    if ((cell_num == 0) || (cell_num > BMS_MAX_SUPPORTED_CELLS))
    {
        return false;
    }
    g_cell_data = (BMS_cell_data_t*)malloc(sizeof(BMS_cell_data_t));
    if (g_cell_data == NULL)
    {
        return false;
    }

### 第85页

g_cell_data->max_cell_num = cell_num;
    g_cell_data->curr_cell_num = cell_num;
    g_cell_data->cell_voltages = (uint16_t*)malloc(cell_num *
sizeof(uint16_t));
    if (g_cell_data->cell_voltages == NULL)
    {
        free(g_cell_data);
        g_cell_data = NULL;
        return false;
    }
    return true;
}
// 写入函数：严格检查索引范围，防止越界写入
bool BMS_write_cell_voltage(uint8_t cell_idx, uint16_t voltage)
{
    if (g_cell_data == NULL)
    {
        return false;
    }
    // 修改2：检查索引是否在数组容量范围内
    if (cell_idx >= g_cell_data->max_cell_num)
    {
        return false;
    }
    g_cell_data->cell_voltages[cell_idx] = voltage;
    return true;
}
// 拷贝函数：限制拷贝长度，防止缓冲区溢出
bool BMS_copy_cell_voltages(const uint16_t* src, uint8_t src_len)
{
    if ((g_cell_data == NULL) || (src == NULL) || (src_len == 0))
    {
        return false;
    }
    // 修改3：拷贝长度不超过数组容量（取较小值）
    uint8_t copy_len = (src_len <= g_cell_data->max_cell_num) ? src_len
: g_cell_data->max_cell_num;
    memcpy(g_cell_data->cell_voltages, src, copy_len *
sizeof(uint16_t));
    return true;
}

### 第86页

7.9 规则-禁止引用已经释放的内存空间
反面案例
复制代码
// 读取函数：检查索引有效性，防止读取越界
uint16_t BMS_read_cell_voltage(uint8_t cell_idx, bool* is_valid)
{
    if (g_cell_data == NULL)
    {
        return 0;
    }
    if (is_valid != NULL)
    {
        *is_valid = false;  // 默认无效
    }

    //修改4：检查索引是否在实际有效数据范围内
    if (cell_idx >= g_cell_data->curr_cell_num)
    {
        return 0;
    }

    if (is_valid != NULL)
    {
        *is_valid = true;  // 标记数据有效
    }
    return g_cell_data->cell_voltages[cell_idx];
}
// 销毁函数：释放所有内存
void BMS_destroy_cell_data()
{
    if (g_cell_data != NULL)
    {
        // 由里到外逐步释放
        free(g_cell_data->cell_voltages);
        g_cell_data->cell_voltages = NULL;
        free(g_cell_data);
        g_cell_data = NULL;
    }
//=========== 反面案例

### 第87页

正面案例
复制代码
8. 代码效率
8.1 规则-中断中不能执行延时或其他耗时操作，只做最小必要
操作
说明：中断服务函数（ISR）极简：ISR 内只做 “数据采集 / 缓存 / 标志置位”，复杂逻辑丢给
后台任务；
复制代码
uint8_t* BMS_get_safe_data()
{
    uint8_t stack_buf[10];  // 栈上分配的局部数组
    // 问题1：返回栈内存指针，函数退出后栈内存已释放，指针变为野指针
    return stack_buf;
}
//=========== 正面案例
// 修改1：不返回栈指针，改为通过参数输出到堆内存或调用者提供的缓冲区
bool BMS_get_safe_data(uint8_t* out_buf, uint16_t out_len)
{
    if ((out_buf == NULL) || (out_len == 0))
    {
        return false;
    }
    uint8_t stack_buf[SAFE_DATA_LEN];  // 栈内存仅在函数内使用
    uint16_t copy_len = ((out_len <= SAFE_DATA_LEN)) ? (out_len) :
(SAFE_DATA_LEN);
    memcpy(out_buf, stack_buf, copy_len);  // 复制数据而非返回指针
    return true;
}
//=========== 反面案例
// 低效：ISR内做滤波+故障判断（阻塞其他中断）
void ADC1_IRQHandler(void)
{
    uint16_t adc_val = ADC_GetValue(ADC1);
    uint16_t volt = calc_real_volt(adc_val);  // 复杂计算
    if (volt > MAX_VOLT)
    {

### 第88页

正面案例
复制代码
8.2 建议-合理使用 inline 函数（减少函数调用栈开销）
说明：inline （内联函数）是 C 语言的编译器指令，作用是将函数的代码直接嵌入到调用
处，而非通过 “函数调用”（压栈→执行→出栈）的方式运行，让运行效率得到提高；
适用场景：高频调用的小函数，相比宏更安全（有类型检查），但不适合复杂函数；
        set_error(ERROR_OVER_VOLT);  // 故障判断
    }
    ADC_ClearFlag(ADC1, ADC_FLAG_EOC);
}
//=========== 正面案例
// 高效：ISR仅缓存数据，逻辑丢给后台
static uint16_t adc_buf[16] = {0};  // 静态缓存
static uint8_t adc_idx = 0;
volatile uint8_t adc_sample_done = 0;  // 全局标志
void ADC1_IRQHandler(void)
{
    adc_buf[adc_idx++] = ADC_GetValue(ADC1);  // 仅缓存
    if (adc_idx >= 16)
    {
        adc_idx = 0;
        adc_sample_done = 1;  // 置位标志
    }
    ADC_ClearFlag(ADC1, ADC_FLAG_EOC);  // 清中断
}
●
注意：
●
仅用static inline （避免全局 inline 导致代码膨胀），函数行数≤10 行。
○

### 第89页

示例
复制代码
9. 宏定义
9.1 规则-多语句宏使用do-while(0)包裹（注意：最后的
while (0)后没有分号）
反面案例
复制代码
inline 只是 “提示” 编译器内联，不是 “强制”，编译器会自动判断：若函数含循环
/ 递归 / 长逻辑，会忽略 inline 指令；
○
/**
 * @brief 内联函数：校验单体电压（高频调用）
 * @param volt: 单体电压
 * @return true-正常，false-超限
 */
static inline bool bms_check_cell_volt(float volt)
{
    // 短小逻辑，编译器会内联
    return (volt >= CELL_VOLT_MIN && volt <= CELL_VOLT_MAX);
}
//=========== 反面案例
// 多语句宏：未用do-while(0)包裹，可能引发语法问题
#define BMS_SET_UNDERVOLT(volt, state) \
    if ((volt) < 2500) \
    { \
        *(state) = 1; \
    } \
    else \
    { \
        *(state) = 0; \
    }
void BMS_check_undervolt(uint16_t volt, uint8_t* fault_state)
{
    if (fault_state == NULL)
    {
        return;
    }

### 第90页

正面案例
复制代码
9.2 规则-用宏定义表达式时，要使用完备的括号
反面案例
复制代码
    // 问题1：宏展开后加分号会导致else匹配错误
    if (volt > 0)
        BMS_SET_UNDERVOLT(volt, fault_state);  // 宏展开后此处相当于多句代
码
    else
        *fault_state = 0;  // 编译报错：else无匹配的if
}
//=========== 正面案例
// 多语句宏：用do-while(0)包裹，确保语法正确
#define BMS_SET_UNDERVOLT(volt, state) \
    do \
    { \
        if ((volt) < 2500) \
        { \
            *(state) = 1; \
        } \
        else \
        { \
            *(state) = 0; \
        } \
    } while(0)
void BMS_check_undervolt(uint16_t volt, uint8_t* fault_state)
{
    if (fault_state == NULL)
    {
        return;
    }
    // 修改1：宏展开后整体作为一个语句块，不影响else匹配
    if (volt > 0)
        BMS_SET_UNDERVOLT(volt, fault_state);  // 加分号后语法仍正确
    else
        *fault_state = 0;  // 编译通过，逻辑正常
}

### 第91页

//=========== 反面案例
// 电池单体电压范围（mV）
#define BMS_CELL_VOLT_MIN 2500
#define BMS_CELL_VOLT_MAX 4200
// 问题1：宏定义表达式未用括号包裹，可能因运算符优先级导致计算错误
#define BMS_CELL_VOLT_RANGE BMS_CELL_VOLT_MAX - BMS_CELL_VOLT_MIN
// 问题2：带参数的宏未对参数单独加括号，传入表达式时会出错
#define BMS_IS_CELL_OVERVOLT(volt) volt > BMS_CELL_VOLT_MAX
// 问题3：复杂表达式未整体加括号，组合运算时逻辑混乱
#define BMS_CELL_VOLT_OFFSET(volt) (BMS_CELL_VOLT_MAX - volt) * 2
// 计算电压范围的1/2（依赖BMS_CELL_VOLT_RANGE）
uint32_t BMS_calc_half_range()
{
    // 实际执行：4200 - 2500 / 2 → 4200 - 1250 = 2950（正确应为(4200-
2500)/2=850）
    return BMS_CELL_VOLT_RANGE / 2;
}
// 判断电芯是否过压（传入表达式）
bool BMS_check_cell_overvolt(uint16_t measured_volt)
{
    // 实际执行：measured_volt + 100 > 4200 → 正确，但假设宏定义是
volt+100>max时会出错
    // 若宏定义为IS_OVER(volt) volt+100>BMS_MAX，传入a*2时会变成
a*2+100>BMS_MAX（而非(a*2)+100）
    return BMS_IS_CELL_OVERVOLT(measured_volt + 100);
}
// 计算电压补偿值（依赖BMS_CELL_VOLT_OFFSET）
int32_t BMS_Calc_voltage_compensate(uint16_t volt, int32_t base)
{
    // 实际执行：base + (4200 - volt) * 2 → 正确，但假设base带运算时会出错
    // 若传入base为a + b，宏未加括号会导致a + b + (4200 - volt)*2（逻辑正
确）
    // 但宏定义若为(MAX - volt)*2 + base，传入a + b会变成(MAX-volt)*2 + a
+ b（仍正确）
    // 反例：若宏定义为MAX - volt * 2（未加括号），传入volt=100+50会变成MAX
- 100+50*2（错误）
    return base + BMS_CELL_VOLT_OFFSET(volt);
}

### 第92页

正面案例
复制代码
//=========== 正面案例
// 电池单体电压范围（mV）
#define BMS_CELL_VOLT_MIN 2500
#define BMS_CELL_VOLT_MAX 4200
// 修改1：宏定义表达式整体加括号，确保独立运算
#define BMS_CELL_VOLT_RANGE (BMS_CELL_VOLT_MAX - BMS_CELL_VOLT_MIN)
// 修改2：带参数的宏，参数和整体表达式均加括号，防止运算符优先级干扰
#define BMS_IS_CELL_OVERVOLT(volt) ((volt) > BMS_CELL_VOLT_MAX)
// 修改3：复杂表达式中，子表达式和整体均加括号，确保逻辑正确
#define BMS_CELL_VOLT_OFFSET(volt) ((BMS_CELL_VOLT_MAX - (volt)) * 2)
// 新增示例：多参数宏的括号保护
#define BMS_CELL_VOLT_DIFF(a, b) ((a) - (b))
// 计算电压范围的1/2（依赖BMS_CELL_VOLT_RANGE）
uint32_t BMS_calc_half_range()
{
    // 执行：(4200 - 2500) / 2 → 1700 / 2 = 850（正确）
    return BMS_CELL_VOLT_RANGE / 2;
}
// 判断电芯是否过压（传入表达式）
bool BMS_check_cell_overvolt(uint16_t measured_volt)
{
    // 执行：((measured_volt + 100) > 4200)（正确，参数表达式被括号保护）
    return BMS_IS_CELL_OVERVOLT(measured_volt + 100);
}
// 计算电压补偿值（依赖BMS_CELL_VOLT_OFFSET）
int32_t BMS_calc_voltage_compensate(uint16_t volt, int32_t base)
{
    // 执行：base + ((4200 - (volt)) * 2)（正确，子表达式被括号保护）
    // 若传入volt为100+50，会被解析为(4200 - (100+50)) * 2（正确）
    return base + BMS_CELL_VOLT_OFFSET(volt);
}
// 计算两个电压差值的绝对值
uint32_t BMS_calc_abs_diff(uint16_t v1, uint16_t v2)
{
    // 执行：abs(((v1 * 2) - (v2 + 100)))（正确，参数和整体均被括号保护）

### 第93页

9.3 规则-使用带参数的宏时，不允许在宏调用时，传入带操作
符的参数
反面案例
复制代码
正面案例
复制代码
    return BMS_CELL_VOLT_DIFF(v1 * 2, v2 + 100);
}
//=========== 反面案例
// 宏：计算电压与阈值的差值（参数被多次引用）
#define BMS_VOLT_DIFF(volt) ((volt) - 3000 + (volt))
void BMS_calc_diff()
{
    uint16_t volt = 3500;

    // 问题1：宏参数含自增，导致两次引用值不同
    uint16_t diff = BMS_VOLT_DIFF(volt++);
    // 实际执行：(3500) - 3000 + (3501) → 结果为3500-3000+3501=4001
    // 预期（若参数不变）：3500-3000+3500=4000，结果偏差

    printf("错误计算结果：%d\n", diff);  // 输出4001（非预期）
}
//=========== 正面案例
// 宏：计算电压与阈值的差值
#define BMS_VOLT_DIFF(volt) ((volt) - 3000 + (volt))
void BMS_calc_diff()
{
    uint16_t volt = 3500;
    uint16_t current_volt = volt;  // 保存参数固定值

    // 修改1：宏参数为固定值，两次引用一致
    uint16_t diff = BMS_VOLT_DIFF(current_volt);
    // 执行：3500 - 3000 + 3500 = 4000（符合预期）

    volt++;  // 宏计算后再自增，不影响结果
    printf("正确计算结果：%d\n", diff);  // 输出4000（符合预期）
}

### 第94页

9.4 建议-除非必要，应尽可能使用函数代替宏
说明：一般情况下，函数相比宏而言，具有可维护性强、方便调试、可以进行类型检查等优
势
反面案例
复制代码
正面案例
复制代码
例外：但宏的编译期展开、无调用开销、支持参数类型无关性等特性，使其在特定场景下或
比函数更优；
1) 实现 “泛型” 功能（参数类型无关的通用逻辑）
函数的参数类型是固定的，而宏通过文本替换实现类型无关的通用逻辑，无需为不同类型
重复写函数（C11 虽有 _Generic，但兼容性 / 易用性不如宏）
复制代码
//=========== 反面案例1
// 宏获取电池单体电压平均值
#define GET_CELL_AVG(volt_arr, count) (sum_volt(volt_arr, count) /
count)
// 调用时的问题
uint16_t cell_volts[10] = {3200, 3201, 3199, 3188};
// 宏无边界检查，count=0时直接除以0，BMS中会触发硬件异常（程序崩溃）
uint16_t avg = GET_CELL_AVG(cell_volts, 0);
//=========== 正面案例：函数计算电芯平均电压
uint16_t CELL_get_cell_avg(const uint16_t *volt_arr, uint8_t count)
{
    // 1. 入参校验：避免空指针和非法count（BMS防崩溃核心）
    if (volt_arr == NULL || count < MIN_CELL_COUNT || count >
MAX_CELL_COUNT)
    {
        bms_log("Invalid cell count: %d", count);
        return 0;  // 返回安全值，而非直接崩溃
    }
    // 2. 计算总和
    uint32_t sum = sum_volt(volt_arr, count);

    // 3. 安全除法（避免除0）
    return (uint16_t)(sum / count);
}

### 第95页

2) 消除函数调用开销（高频调用的小逻辑）
函数调用存在 “栈帧创建 / 销毁、参数压栈、返回值传递” 的开销，对于高频调用的极简逻辑
（如单步计算、状态判断），宏的编译期展开可彻底消除该开销，提升性能。
嵌入式场景中高频调用的寄存器操作宏
复制代码
适用场景：嵌入式中断服务函数、实时性要求极高的循环（如 1ms 定时器中断）
总结：
9.5 建议-宏定义中尽量不使用return、continue、break等改
变程序流程的语句
说明：宏中使用return等，导致改变成语流程，出现资源未释放等应实现的流程未进行
反面案例
复制代码
// 宏：支持任意可比较类型，无需重复定义函数
#define MAX(a, b) ((a) > (b) ? (a) : (b))
// 对比函数：需为每种类型写一个版本，冗余且维护成本高
int max_int(int a, int b) { return a > b ? a : b; }
float max_float(float a, float b) { return a > b ? a : b; }
long max_long(long a, long b) { return a > b ? a : b; }
// 宏：编译期展开，无调用开销，适合中断/高频轮询中使用
#define REG_WRITE(addr, val) (*(volatile uint32_t *)(addr) = (val))
// 对比函数：每次调用都有栈开销，中断中可能导致延迟
uint32_t reg_write(uint32_t *addr) { *addr = val; }
场景
选宏
选函数
复杂逻辑（>3行）/ 需要调
试
×
√
需要类型检查 / 避免宏副作
用
×
√
泛型逻辑（类型无关）
√
×
高频调用的极简逻辑（无开
销）
√
×

### 第96页

正面案例
复制代码
//=========== 反面案例
#define BMS_MAX_CELL_NUM 16
// 问题：宏内使用return，导致内存/硬件资源未释放
#define BMS_CHECK_VOLT_RANGE(volt) \
    if ((volt) < 2500 || (volt) > 4200) \
    { \
        /* 直接return，跳过后续资源释放逻辑 */ \
        return; \
    }
// BMS初始化电芯数据缓冲区（动态内存+硬件锁资源）
void BMS_init_cell_buffer(uint16_t init_volt)
{
    // 1. 申请动态内存资源
    uint16_t* cell_volt_buf = (uint16_t*)malloc(BMS_MAX_CELL_NUM *
sizeof(uint16_t));
    if (cell_volt_buf == NULL) return;
    // 2. 占用硬件锁资源（BMS电芯通信总线锁）
    uint8_t bus_lock = 1; // 模拟硬件锁占用
    // 调用含return的宏：若电压异常，直接终止函数
    BMS_CHECK_VOLT_RANGE(init_volt);
    // 正常逻辑：初始化缓冲区+释放资源
    for (uint8_t i = 0; i < BMS_MAX_CELL_NUM; i++)
    {
        cell_volt_buf[i] = init_volt;
    }
    // code...
    free(cell_volt_buf); // 内存释放
    bus_lock = 0;        // 硬件锁释放
}
//=========== 正面案例
#define BMS_MAX_CELL_NUM 16
// 修改：宏仅返回状态，不改变流程，由调用方控制逻辑
#define BMS_IS_VOLT_OUT_RANGE(volt) ((volt) < 2500 || (volt) > 4200)

### 第97页

10. 其他基本规范
10.1 规则-文件统一使用utf-8编码
说明：统一使用utf-8编码，避免不同环境下出现乱码的情况
10.2 规则-不能使用魔鬼数字，不能直观理解的数字需要加上
注释，特定意义的数字使用宏定义封装；
反面案例
复制代码
// BMS初始化电芯数据缓冲区（资源释放逻辑完整）
void BMS_init_cell_buffer(uint16_t init_volt)
{
    uint16_t* cell_volt_buf = (uint16_t*)malloc(BMS_MAX_CELL_NUM *
sizeof(uint16_t));
    if (cell_volt_buf == NULL) return;
    uint8_t bus_lock = 1; // 模拟硬件锁占用
    // 调用宏：仅判断状态，不直接return
    if (BMS_IS_VOLT_OUT_RANGE(init_volt))
    {
        // 异常分支：先释放所有资源，再终止函数
        free(cell_volt_buf); // 内存释放
        bus_lock = 0;        // 硬件锁释放
        return;
    }
    // 正常逻辑：初始化+释放资源
    for (uint8_t i = 0; i < BMS_MAX_CELL_NUM; i++)
    {
        cell_volt_buf[i] = init_volt;
    }
    free(cell_volt_buf);
    bus_lock = 0;
}
//=========== 反面案例
// 裸数字无含义，无法判断2700是过放阈值还是其他

### 第98页

正面案例
复制代码
10.3 规则-BIT位使用时需要赋予意义
反面案例
复制代码
正面案例
复制代码
10.4 规则-严禁使用未经初始化的变量为右值
if (cell_voltage < 2700)
{
    bms_set_fault(FAULT_CELL_UNDERVOLTAGE); // 过放故障，但2700单位/含义不
明确
}
//=========== 正面案例
// 电芯过放保护阈值（mV）
#define BMS_CELL_UNDERVOLTAGE_THRESHOLD_MV  2700
// 调用示例：语义清晰，修改时仅需改宏定义
if (cell_voltage < BMS_CELL_UNDERVOLTAGE_THRESHOLD_MV)
{
    bms_set_fault(FAULT_CELL_UNDERVOLTAGE);
}
//=========== 反面案例
// 问题1：BIT位定义无明确意义，仅用数字标识
#define BMS_FLAG_0 (1 << 0)
#define BMS_FLAG_1 (1 << 1)
#define BMS_FLAG_2 (1 << 2)
#define BMS_FLAG_3 (1 << 3)
//=========== 正面案例
// 改进1：BIT位定义直接体现物理意义，与BMS功能关联
#define BMS_FLAG_CELL_OVERVOLT  (1 << 0)  // 电芯过压（单BIT含义）
#define BMS_FLAG_OVERCURRENT    (1 << 1)  // 过流（单BIT含义）
#define BMS_FLAG_CELL_UNDERVOLT (1 << 2)  // 电芯欠压（单BIT含义）
#define BMS_FLAG_UNDERCURRENT   (1 << 3)  // 欠流（单BIT含义）

### 第99页

说明：未经初始化的变量是个随机的内存垃圾值，做右值时会导致结果无法预测
反面案例
复制代码
正面案例
复制代码
//=========== 反面案例
// BMS核心参数：电芯电压阈值判断
bool BMS_check_cell_overvolt(uint16_t measured_volt)
{
    // 问题1：局部变量未初始化，直接作为右值参与运算
    uint16_t overvolt_threshold; // 未初始化，值为随机垃圾数据
    if (measured_volt > overvolt_threshold) // 使用未初始化变量作为右值
    {
        return true; // 阈值随机，导致过压判断结果不可控
    }
    return false;
}
// BMS故障计数：未初始化变量参与累加
uint8_t BMS_get_fault_count()
{
    // 问题2：全局变量未显式初始化（依赖编译器零初始化，不可靠）
    static uint8_t fault_cnt; // 部分编译器可能不自动初始化为0
    fault_cnt += 1; // 使用未确保初始化的变量作为右值累加
    return fault_cnt; // 首次调用结果可能为随机值（如0x01或0xFF+1）
}
//=========== 正面案例
// BMS核心参数：电芯电压阈值判断（变量初始化后使用）
bool BMS_check_cell_overvolt(uint16_t measured_volt)
{
    // 改进1：局部变量显式初始化，赋予明确的业务意义值
    uint16_t overvolt_threshold = BMS_Get_overvolt_threshold(); // 初始化
为BMS过压阈值（mV）
    if (measured_volt > overvolt_threshold) // 使用初始化后的变量作为右值
    {
        return true; // 阈值固定，判断结果可预期
    }
    return false;
}
// BMS故障计数：全局变量显式初始化
uint8_t BMS_get_fault_count()
{
    // 改进2：全局/静态变量显式初始化，不依赖编译器行为

### 第100页

10.5 建议-在首次使用前初始化变量，初始化的地方离使用的
地方越近越好
说明：优势体现在：
1）提升代码可读性，降低认知负担
人的短期记忆和注意力是有限的 —— 如果变量在几百行之上的位置初始化，再到下方使用
时，读者（包括未来的自己）需要：
回溯代码找初始化值，打断阅读节奏；
记忆 “这个变量的初始值是什么？有没有被中途修改过？”，增加认知成本。
2）缩小变量作用域，减少误修改风险
变量的作用域（生效范围）越小，被意外修改的概率越低 —— 如果初始化离使用地太
远，变量会在一个更大的作用域内 “存活”，可能被中间无关代码误赋值
3）避免 “未初始化 / 初始化失效” 问题
杜绝 “未初始化使用”：如果变量初始化太早，可能因后续逻辑（如条件分支）导致初始
值被覆盖 / 失效，而就近初始化能确保 “使用时一定是预期的初始状态”；
避免 “冗余初始化”：提前初始化的变量，若后续逻辑分支中重新赋值，会造成 “无效初始
化”（比如先赋值int a = 0，后在分支里a = 10，初始值 0 无意义），就近初始化可消除这
种冗余。
4）简化代码维护，降低重构成本
重构更安全：如果需要删除 / 修改某段逻辑，就近初始化的变量仅和当前逻辑绑定，不会
因 “变量在远处初始化” 导致重构时遗漏，或影响其他代码；
删除更彻底：若某段使用逻辑被删除，就近初始化的变量可直接一起删除，而提前初始化
的变量可能被遗忘，成为 “僵尸变量”。
5）优化内存 / 性能（局部变量场景）
对于局部变量（如函数内的变量），就近初始化意味着：
变量在栈上的分配时机更晚，减少栈空间的无效占用（尤其大变量 / 复杂对象）；
若变量未被使用（如分支跳过），就近初始化可避免不必要的初始化开销（提前初始化会
无条件执行）。
反面案例
复制代码
    static uint8_t fault_cnt = 0; // 显式初始化为0
    fault_cnt += 1; // 使用已初始化的变量作为右值累加
    return fault_cnt; // 首次调用结果必为1，逻辑可控
}
●
●
●
●
●
●
●
●
●
//=========== 反面案例

### 第101页

正面案例
复制代码
#define BMS_MAX_CELL_NUM 16
// 问题1：变量初始化与使用位置相距过远，可读性差且易遗漏修改
void BMS_calc_cell_avg(uint16_t* cell_volts)
{
    // 初始化位置：函数开头（远离实际使用位置）
    uint16_t sum_volt = 0;
    uint8_t valid_cell_cnt = 0;
    // 中间大量无关逻辑，隔离初始化与使用
    if ((cell_volts == NULL))
    {
        return;
    }

    for (uint8_t i = 0; i < BMS_MAX_CELL_NUM; i++)
    {
        // code...
        // 使用位置：循环内部（与初始化隔多行代码）
        sum_volt += cell_volts[i];
        valid_cell_cnt++;
    }
    uint16_t avg_volt = sum_volt / valid_cell_cnt;
}
// 问题2：变量首次使用前未初始化，且初始化位置滞后
void BMS_check_overcurrent(uint16_t current)
{
    bool is_overcurrent; // 仅声明，未初始化
    // 首次使用：先作为右值判断，后初始化（逻辑错误）
    if (is_overcurrent)
    {
        // 此处is_overcurrent为随机值，逻辑不可控
    }
    // 初始化位置：首次使用之后，无意义
    is_overcurrent = (current > 5000);
}
//=========== 正面案例
// 修改1：变量初始化紧邻使用位置，逻辑关联性强
void BMS_calc_cell_avg(uint16_t* cell_volts)
{
    if ((cell_volts == NULL))

### 第102页

10.6 建议-用括号明确表达式的操作顺序，避免过分依赖默认
优先级
反面案例
复制代码
    {
        return;
    }
    // 初始化位置：紧邻循环（使用位置），仅在需要时初始化
    uint16_t sum_volt = 0;
    uint8_t valid_cell_cnt = 0;
    for (uint8_t i = 0; i < BMS_MAX_CELL_NUM; i++)
    {
        // code...
        sum_volt += cell_volts[i];
        valid_cell_cnt++;
    }
    // 初始化位置：紧邻使用位置（计算均值）
    uint16_t avg_volt = sum_volt / valid_cell_cnt;
}
// 修改2：首次使用前完成初始化，且初始化靠近使用位置
void BMS_check_overcurrent(uint16_t current)
{
    // 初始化位置：首次使用前，且紧邻判断逻辑
    bool is_overcurrent = (current > 5000);
    // 首次使用：初始化后立即使用，逻辑可控
    if (is_overcurrent)
    {
        // 基于明确初始化的值判断，结果可靠
    }
}
//=========== 反面案例
#include <stdint.h>
// BMS故障判断：复合条件依赖默认优先级
bool BMS_is_critical_fault(uint16_t volt, int16_t current)
{
    // 问题1：逻辑运算符默认优先级（&& > ||）导致判断逻辑与预期不符
    // 意图：(volt < 2500 || volt > 4200) && (current > 5000 || current
< -2000)

### 第103页

正面案例
复制代码
10.7 建议-类型定义使用typedef
说明：使用typedef定义结构体和枚举，这样使用时不需要再写关键字 struct 和 enum，直接
使用别名，更加方便
反面案例
复制代码
    // 实际执行：volt < 2500 || (volt > 4200 && current > 5000) ||
current < -2000
    return volt < 2500 || volt > 4200 && current > 5000 || current <
2000;
//=========== 正面案例
#include <stdint.h>
// BMS故障判断：复合条件用括号明确逻辑顺序
bool BMS_is_critical_fault(uint16_t volt, int16_t current)
{
    // 修改1：括号明确“电压异常”和“电流异常”为独立条件，再做与运算
    bool volt_abnormal = ((volt < 2500) || (volt > 4200));
    bool current_abnormal = ((current > 5000) || (current < -2000));
    return (volt_abnormal && current_abnormal);
    // 也可直接嵌套括号，结果一致：
    // return (((volt < 2500) || (volt > 4200)) && ((current > 5000) ||
(current < -2000)));
}
//=========== 反面案例
struct point_t
{
    int x;
    int y;
};
enum color_e
{
    RED,
    GREEN,
    BLUE
};
// 定义结构体变量和枚举变量时，需要写关键字 struct 和 enum
struct point_t point = {0};

### 第104页

复制代码
10.8 建议-优先使用位域提升可读性
1) 位域的核心概念
位域本质是结构体成员的一种特殊声明方式，通过指定成员占用的二进制位数，让多个成员
共用一个或多个字节，从而节省内存。
比如：用 1 位表示 “开关状态”（0/1）、用 4 位表示 “数字 0-15”，而不是让每个成员默认占
用 1 个字节（8 位）。
2) 位域的基本语法
位域必须声明在结构体 / 共用体中，语法格式：
复制代码
enum color e color = {0};
//=========== 正面案例
typedef struct
{
    int x;
    int y;
} point_t;
typedef enum
{
    RED,
    GREEN,
    BLUE
} color_e;
// 定义结构体变量和枚举变量时，不需要写关键字 struct 和 enum，直接使用别名
point_t point = {0};
color_e color = {0};
struct 结构体名
{
    类型 成员名 : 位数;  // 核心：冒号+数字（表示占用的二进制位数）
    类型 成员名 : 位数;
    // 可加无名位域（用于填充/对齐）
    类型 : 位数;
    // 可加占位符（仅对齐，无意义）

### 第105页

关键规则：
位数限制：指定的位数不能超过基础类型的总位数（比如 int 占 4 字节 = 32 位，位数不
能≥32）；
无名位域：仅写类型 : 位数; ，用于内存填充（占住位数但不使用）；
位数为 0 的位域：unsigned int : 0; ，强制下一个位域从新的存储单元（字节 / 字）
开始，用于内存对齐。
3) 位域的使用示例
示例 1：基础用法（节省内存）
比如用一个结构体存储 “设备状态”，原本需要多个字节，用位域仅需 1 个字节：
复制代码
    unsigned int : 0;
};
类型限制：位域的基础类型只能是 unsigned int 、signed int  或 int （不同编译
器可能支持 char / short ，当前IAR支持char / short ，但int 是标准推荐）；
●
unsigned int ：无符号，适合存储非负数（如状态、标志）；
signed int ：有符号，最高位为符号位，实际可用位数 = 指定位数 - 1。
○
○
●
●
●
#include <stdio.h>
// 定义位域结构体：总占用1字节（8位）
struct device_status
{
    unsigned int power : 1;    // 电源状态：1位（0=关，1=开）
    unsigned int mode : 3;     // 工作模式：3位（0-7）
    unsigned int error : 4;    // 错误码：4位（0-15）
};  // 1+3+4=8位=1字节
int fun()
{
    struct device_status dev;

    // 1. 赋值：直接赋数值，超出位数的部分会被截断
    dev.power = 1;    // 合法：1位能存0/1
    dev.mode = 5;     // 合法：3位能存0-7
    dev.error = 12;   // 合法：4位能存0-15

### 第106页

示例 2：无名位域与 0 位域（填充 / 对齐）
复制代码
    // 2. 取值：直接访问成员
    printf("电源状态：%d\n", dev.power);   // 输出：1
    printf("工作模式：%d\n", dev.mode);     // 输出：5
    printf("错误码：%d\n", dev.error);      // 输出：12

    // 3. 测试超出位数的截断：mode仅3位，赋值8（二进制1000）会截断为0
    dev.mode = 8;
    printf("超出位数的mode：%d\n", dev.mode);  // 输出：0

    // 查看结构体总大小：验证仅占1字节
    printf("结构体大小：%zu 字节\n", sizeof(dev));  // 输出：1（不同编译器可
能因对齐略有差异）

    return 0;
}
#include <stdio.h>
struct bit_field_demo
{
    unsigned int a : 2;    // 2位
    unsigned int : 3;      // 无名位域：3位（填充，不可访问）
    unsigned int b : 3;    // 3位（2+3+3=8位，占1字节）
    unsigned int : 0;      // 0位域：强制下一个成员从新字节开始
    unsigned int c : 4;    // 4位（新字节）
};
int fun()
{
    struct bit_field_demo bf = {.a=1, .b=5, .c=10};
    printf("a=%d, b=%d, c=%d\n", bf.a, bf.b, bf.c);  // 输出：a=1, b=5,
c=10
    // 结构体大小：1（a+b+填充） + 1（c） = 2字节（编译器对齐后可能为4字节，
取决于系统）
    printf("结构体大小：%zu 字节\n", sizeof(bf));
    return 0;
}

### 第107页

4) 位域的使用场景
硬件 / 嵌入式编程：与硬件寄存器交互（寄存器通常按位定义功能，比如某几位控制外
设、某几位表示状态）；
网络协议 / 数据压缩：协议头的字段往往按位划分（比如 IP 头的版本号占 4 位、服务类
型占 8 位）；
内存敏感场景：比如存储大量状态标志（如 100 个开关状态），用位域仅需 13 字节
（100/8≈13），而普通 int 需要 400 字节。
5) 注意事项（避坑重点）
不能取位域的地址：&dev.power  是非法的（位域不是完整的内存单元，地址无意
义）；
赋值超出位数会截断：比如 1 位的位域赋值 2，二进制是 10，会截断为 0（仅保留最低
位）；
位域的大小计算：编译器会自动对齐，比如多个位域总位数不足 1 字节，会补到 1 字
节；超过 1 字节则按基础类型的大小对齐（比如 int 占 4 字节，位域总位数 10 位，会占
4 字节）。
6) 位域 vs 位运算
新手容易混淆位域和位运算，两者都能操作二进制位，但适用场景不同：
示例：用位运算实现和位域相同的功能（对比可读性）
●
●
●
跨平台兼容性：
●
位域的存储顺序（高位在前 / 低位在前）由编译器和 CPU 架构决定（大端 / 小
端），移植时需注意；
不同编译器对 “位域基础类型” 的支持可能不同（比如有些不支持 char 型位域），优
先用unsigned int 。
○
○
●
●
●
特性
位域
位运算（&、|、<<、>>）
可读性
高（直接用成员名）
 低（需手动计算位掩码）
灵活性
低（仅结构体中使用）
高（可操作任意变量）
内存控制
精准按位分配
需手动计算，易浪费内存
跨平台性
较差
较好

### 第108页

复制代码
7) 总结
核心作用：位域通过指定结构体成员的二进制位数，精准控制内存占用，适合内存敏感或
硬件交互场景；
语法规则：必须声明在结构体 / 共用体中，基础类型优先用unsigned int ，位数不能超
过基础类型总位数；
关键注意：跨平台兼容性差、不能取地址、赋值超位数会截断；
使用选择：优先用位域提升可读性（嵌入式 / 硬件场景），跨平台场景优先用位运算。
// 用位运算模拟device_status
unsigned char dev_status = 0;
// 设置power（第0位）为1
dev_status |= (1 << 0);
// 设置mode（第1-3位）为5
dev_status &= ~(7 << 1);  // 先清空第1-3位
dev_status |= (5 << 1);
// 读取error（第4-7位）
unsigned char error = (dev_status >> 4) & 0x0F;
●
●
●
●
