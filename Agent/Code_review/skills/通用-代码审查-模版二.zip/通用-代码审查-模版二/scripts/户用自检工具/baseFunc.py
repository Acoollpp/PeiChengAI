import re


def evaluate_conditions(conditions: list[bool], logic_str: str) -> bool:
    """
    根据条件结果和逻辑表达式计算最终结果

    :param conditions: 条件结果列表，如 [True, False, True]
    :param logic_str: 逻辑表达式字符串，如 "((1 || 2) && (3 || 4))"
    :return: 组合逻辑判断结果
    """
    # 替换操作符为Python语法
    expr = logic_str.replace("&&", " and ").replace("||", " or ").replace("!", "not ")

    # 将数字替换为conditions列表中的对应值
    for i in range(len(conditions)):
        # 注意：列表索引从0开始，但表达式中的数字从1开始
        expr = expr.replace(str(i + 1), str(conditions[i]))

    # 安全评估表达式
    try:
        return eval(expr)
    except:
        raise ValueError(f"Invalid logic expression: {logic_str}")


def extract_numeric_substrings(input_string):
    """
    从字符串中提取以数字开头和结尾的子字符串，小数点视为有效字符

    参数:
        input_string (str): 要处理的输入字符串

    返回:
        list: 包含所有符合条件的子字符串的列表
    """
    # 使用正则表达式匹配模式：
    # \d+ 匹配一个或多个数字开头
    # [\d.]* 匹配零个或多个数字或小数点
    # \d+ 匹配一个或多个数字结尾
    pattern = r'\d+[\d.]*\d+'

    # 使用findall方法查找所有匹配的子字符串
    matches = re.findall(pattern, input_string)

    return matches


def extract_numbers_from_string(input_str: str) -> list[float]:
    """
    从字符串中提取所有数字（包括小数），返回浮点数列表

    参数:
        input_str: 要提取数字的字符串

    返回:
        包含字符串中所有数字的浮点数列表

    异常:
        ValueError: 如果字符串中不包含任何数字

    示例:
        >>> extract_numbers_from_string("abc 12.3 def 45 ghi 6.78")
        [12.3, 45.0, 6.78]
        >>> extract_numbers_from_string("没有数字的字符串")
        ValueError: 字符串中不包含任何数字
    """
    # 使用正则表达式匹配所有数字（包括小数和整数）
    numbers = re.findall(r"-?\d+\.?\d*", input_str)

    if not numbers:
        raise ValueError(f"字符串[{input_str}]中不包含任何数字")

    # 将字符串形式的数字转换为浮点数
    return [float(num) for num in numbers]


# ==================== 测试用例 ====================
if __name__ == '__main__':
    print("basc_func test")
    try:
        result = extract_numbers_from_string("温度是23.5℃，湿度是50%，压力1013.25hPa")
        print(result)  # 输出: [23.5, 50.0, 1013.25]

        result = extract_numeric_substrings("P16S150A-41088-1.01-001")
        print(result)
        result = extract_numbers_from_string("没有任何数字的文本")
    except ValueError as e:
        print(e)  # 输出: 字符串中不包含任何数字
