import os
from typing import Union, List, Optional


def get_file_list(
        folder_path: str = None,
        extensions: Union[str, List[str]] = None,
        exclude_conditions: Optional[List[str]] = None,
        recursive: bool = True
) -> List[str]:
    """
    获取指定文件夹下的文件列表，支持扩展名筛选和路径过滤

    参数:
        folder_path (str, optional): 要扫描的文件夹路径，默认为当前文件夹
        extensions (Union[str, List[str]], optional): 要筛选的文件扩展名，可以是单个字符串或列表
        exclude_conditions (List[str], optional): 要排除的路径条件列表，路径中包含任一条件的文件将被过滤
        recursive (bool, optional): 是否递归扫描子文件夹，默认为True

    返回:
        List[str]: 符合条件的文件路径列表

    示例:
        # 获取所有.py文件，但排除包含"test"或"temp"的路径
        get_file_list(extensions='.py', exclude_conditions=['test', 'temp'])
    """
    # 处理默认文件夹路径
    if folder_path is None:
        folder_path = os.getcwd()

    # 确保文件夹存在
    if not os.path.isdir(folder_path):
        raise ValueError(f"指定的路径不是文件夹或不存在: {folder_path}")

    # 处理扩展名参数
    if extensions is not None:
        if isinstance(extensions, str):
            extensions = [extensions.lower()]
        else:
            extensions = [ext.lower() for ext in extensions]
        # 确保扩展名以点开头
        extensions = [ext if ext.startswith('.') else f'.{ext}' for ext in extensions]

    # 处理过滤条件
    if exclude_conditions is None:
        exclude_conditions = []

    # 转换为小写以便不区分大小写匹配
    exclude_conditions = [cond.lower() for cond in exclude_conditions]

    file_list = []

    # 根据是否递归选择遍历方法
    if recursive:
        for root, _, files in os.walk(folder_path):
            for file in files:
                file_path = os.path.join(root, file)
                if _is_file_valid(file_path, extensions, exclude_conditions):
                    file_list.append(file_path)
    else:
        for item in os.listdir(folder_path):
            full_path = os.path.join(folder_path, item)
            if os.path.isfile(full_path) and _is_file_valid(full_path, extensions, exclude_conditions):
                file_list.append(full_path)

    return file_list


def _is_file_valid(
        file_path: str,
        extensions: Optional[List[str]],
        exclude_conditions: List[str]
) -> bool:
    """检查文件是否符合所有条件"""
    # 检查扩展名
    if extensions is not None:
        file_ext = os.path.splitext(file_path)[1].lower()
        if file_ext not in extensions:
            return False

    # 检查排除条件（所有条件都必须不包含）
    file_path_lower = file_path.lower()
    for condition in exclude_conditions:
        if condition in file_path_lower:
            return False

    return True


def is_filename_in_paths(filename: str, path_list: List[Union[str, bytes, os.PathLike]]) -> bool:
    """
    检查指定文件名是否存在于给定的全路径列表中

    参数:
        filename: 要查找的文件名（不含路径）
        path_list: 包含完整文件路径的列表（可以是字符串、bytes或PathLike对象）

    返回:
        bool: 如果文件名存在于路径列表中则返回True，否则返回False

    示例:
        >>> paths = ['/home/user/file.txt', '/tmp/data.csv', 'C:\\Windows\\system.ini']
        >>> is_filename_in_paths('file.txt', paths)
        True
        >>> is_filename_in_paths('nonexistent.txt', paths)
        False
    """
    target_name = filename.lower()
    for path in path_list:
        # 统一处理不同路径类型(str/bytes/PathLike)，并统一大小写比较
        if os.path.basename(path).lower() == target_name:
            # print('File find Succecc', filename, 'path:', path)
            return True
    # print('File find Fail', filename)
    return False


def find_file_in_list(file_name: str, file_list: List[str], case_sensitive: bool = False) -> Optional[str]:
    """
    在已有的文件列表中查找指定文件名的完整路径

    参数:
        file_name (str): 要查找的文件名(可以带扩展名)
        file_list (List[str]): 已有的文件路径列表
        case_sensitive (bool): 是否区分大小写，默认为False

    返回:
        Optional[str]: 找到的文件全路径，如果未找到则返回None
    """
    if not file_list:
        return None

    if not case_sensitive:
        file_name = file_name.lower()

    for file_path in file_list:
        current_file = os.path.basename(file_path)
        if not case_sensitive:
            current_file = current_file.lower()

        if current_file == file_name:
            return file_path

    return None


def find_files_in_list(
        file_name: str,
        file_list: List[str],
        case_sensitive: bool = False
) -> List[str]:
    """
    在已有的文件列表中查找所有匹配指定文件名的完整路径

    参数:
        file_name (str): 要查找的文件名(可以带扩展名)
        file_list (List[str]): 已有的文件路径列表
        case_sensitive (bool): 是否区分大小写，默认为False

    返回:
        List[str]: 找到的所有匹配文件的全路径列表
    """
    if not file_list:
        return []

    if not case_sensitive:
        file_name = file_name.lower()

    result = []

    for file_path in file_list:
        current_file = os.path.basename(file_path)
        if not case_sensitive:
            current_file = current_file.lower()

        if current_file == file_name:
            result.append(file_path)

    return result


# 使用示例
if __name__ == "__main__":
    # 示例1：获取当前目录所有文件（递归）
    print("当前目录所有文件（递归）:")
    file_list = get_file_list("工程文件", [".c", ".h"], ["User_Lib"])
    print(file_list)
    for file in file_list:
        print(file)

    # 示例2：获取指定目录文件（非递归）
    # print("\n指定目录文件（非递归）:")
    # for file in get_file_list("SST22-1887-V1.30", recursive=False):
        # print(file)

    print(is_filename_in_paths('index.html', file_list))  # 输出: True
    print(is_filename_in_paths('Inverter_Data.h', file_list))  # 输出: True
    print(find_file_in_list("Data_Init.c", file_list))

    # 示例3：处理异常情况
    try:
        get_file_list("SST22-1887-V1.30")
    except ValueError as e:
        print(f"\n错误捕获: {e}")
