import re
from colorama import init, Fore, Back, Style

# 初始化colorama
init(autoreset=True)


def extract_upgrade_config_value(file_path):
    """
    从C源码文件中提取Upgrade_UpdateParameters函数内第一次出现的UpgradeConfig |= value;语句中的赋值值

    参数:
        file_path (str): C源码文件路径

    返回:
        str: 提取到的赋值值字符串，如果没找到则返回None
    """
    pattern = re.compile(
        r'UpgradeConfig\s*\|\=\s*(0x[0-9A-Fa-f]+|\d+)\s*;',
        re.IGNORECASE
    )

    inside_target_function = False
    found = False
    result = None

    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            for line in file:
                # 检查是否进入目标函数
                if not inside_target_function:
                    if re.search(r'void\s+Upgrade_UpdateParameters\s*\(', line):
                        inside_target_function = True
                    continue

                # 检查是否离开函数（遇到右花括号）
                if inside_target_function and line.strip() == '}':
                    break

                # 在目标函数内查找赋值语句
                if not found:
                    match = pattern.search(line)
                    if match:
                        result = match.group(1)
                        found = True
                        break  # 找到第一个就退出

        if not found:
            print(Back.YELLOW + Fore.BLACK + "警告: 未在Upgrade_UpdateParameters函数中找到UpgradeConfig赋值语句")
        return result

    except FileNotFoundError:
        print(Back.RED + f"错误: 文件 {file_path} 未找到")
        return None
    except Exception as e:
        print(Back.RED + f"读取文件时出错: {e}")
        return None


# 使用示例
if __name__ == "__main__":
    file_path = "F:\\Python-project\\checkList_pro\\pythonProject\\dist\\工程文件\\21887-3.2\\SST22-1887-V3.20\\SST22-1887-V3.20\\User\\Data_Init.c"  # 替换为你的C文件路径
    value = extract_upgrade_config_value(file_path)
    print(value)
    if value:
        print(f"提取到的赋值值: {value}")
    else:
        print("未找到UpgradeConfig赋值语句")
