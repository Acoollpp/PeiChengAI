import yaml
from typing import List, Dict, Optional


class BMSHardwareConfig:
    """
    BMS硬件配置接口类，用于加载和查询bms_pro_cfg.yml中的配置信息
    """

    def __init__(self, config_path: str):
        """
        初始化配置

        :param config_path: YAML配置文件路径
        """
        self.config_path = config_path
        self.config_data = None
        self.hardware_map = {}  # PCB编号到配置项的映射
        self.load_config()

    def _print_warning(self, message: str) -> None:
        """打印黄色警告信息"""
        print(f"\033[93mWarning: {message}\033[0m")

    def load_config(self) -> None:
        """
        加载并解析YAML配置文件
        """
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                self.config_data = yaml.safe_load(f)

            # 构建PCB编号到配置项的快速查找映射
            if 'hardWares' in self.config_data:
                self.hardware_map = {
                    hw['pcb']: hw for hw in self.config_data['hardWares']
                }
            else:
                self._print_warning(f"'hardWares' section not found in config file {self.config_path}")
                self.hardware_map = {}
        except Exception as e:
            self._print_warning(f"Failed to load config file {self.config_path}: {str(e)}")
            self.config_data = {}
            self.hardware_map = {}

    def get_all_hardware(self) -> List[Dict]:
        """
        获取所有硬件配置项

        :return: 所有硬件配置项的列表
        """
        if not self.config_data or 'hardWares' not in self.config_data:
            self._print_warning("No hardware configuration found")
            return []
        return self.config_data['hardWares']

    def get_hardware_by_pcb(self, pcb: str) -> Optional[Dict]:
        """
        根据PCB编号获取硬件配置

        :param pcb: PCB编号(如"1147V410")
        :return: 硬件配置字典，如果不存在则返回None
        """
        if pcb not in self.hardware_map:
            self._print_warning(f"PCB {pcb} not found in hardware configuration")
        return self.hardware_map.get(pcb)

    def get_afe_by_pcb(self, pcb: str) -> Optional[str]:
        """
        根据PCB编号获取AFE类型

        :param pcb: PCB编号
        :return: AFE类型字符串，如果不存在则返回None
        """
        hw = self.get_hardware_by_pcb(pcb)
        if not hw:
            return None
        if 'afe' not in hw:
            self._print_warning(f"AFE type not found for PCB {pcb}")
            return None
        return hw['afe']

    def get_specs_by_pcb(self, pcb: str) -> Optional[List[Dict]]:
        """
        根据PCB编号获取规格列表

        :param pcb: PCB编号
        :return: 规格列表，如果不存在则返回None
        """
        hw = self.get_hardware_by_pcb(pcb)
        if not hw:
            return None
        if 'spec' not in hw:
            self._print_warning(f"Specs not found for PCB {pcb}")
            return None
        return hw['spec']

    def get_current_options(self, pcb: str) -> List[int]:
        """
        获取PCB支持的所有电流选项

        :param pcb: PCB编号
        :return: 电流(A)列表，如果没有则返回空列表
        """
        specs = self.get_specs_by_pcb(pcb)
        if not specs:
            self._print_warning(f"No current options found for PCB {pcb}")
            return []
        return [spec['current'] for spec in specs]

    def get_sample_resistor_for_current(self, pcb: str, current: int) -> Optional[int]:
        """
        获取特定PCB和电流下的采样电阻个数

        :param pcb: PCB编号
        :param current: 电流值(A)
        :return: 采样电阻个数，如果找不到则返回None
        """
        specs = self.get_specs_by_pcb(pcb)
        if not specs:
            self._print_warning(f"No specs found for PCB {pcb} when getting sample resistor")
            return None

        current_int = int(current)
        for spec in specs:
            if spec['current'] == current_int:
                return spec['sample_resistor']

        self._print_warning(f"Current {current}A not found in specs for PCB {pcb}")
        return None

    def get_version(self) -> str:
        """
        获取配置版本

        :return: 版本字符串
        """
        if not self.config_data or 'version' not in self.config_data:
            self._print_warning("Version not found in configuration")
            return "unknown"
        return self.config_data['version']


if __name__ == "__main__":
    # 初始化配置
    config = BMSHardwareConfig("bms_pro_cfg.yml")

    # 示例1: 获取所有硬件配置
    all_hardware = config.get_all_hardware()
    print(f"所有硬件配置数量: {len(all_hardware)}")

    # 示例2: 查询特定PCB的配置
    pcb_num = "1547V320"
    hw_info = config.get_hardware_by_pcb(pcb_num)
    print(f"\nPCB {pcb_num} 的配置:")
    print(hw_info)

    # 示例3: 获取PCB支持的电流选项
    currents = config.get_current_options(pcb_num)
    print(f"\nPCB {pcb_num} 支持的电流选项: {currents}")

    # 示例4: 查询特定电流下的采样电阻数
    current = 200
    resistors = config.get_sample_resistor_for_current(pcb_num, current)
    print(f"\nPCB {pcb_num} 在 {current}A 时的采样电阻数: {resistors}")

    print('查询指定pcb板的afe类型')
    pcb_num = "1547V420"
    afe_type = config.get_afe_by_pcb(pcb_num)
    print(afe_type)

    # 示例5: 获取配置版本
    print(f"\n配置版本: {config.get_version()}")
