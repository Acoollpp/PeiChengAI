param(
    [Parameter(Mandatory = $true, Position = 0)]
    [string]$SvnUrl,

    [string]$Revision = "",

    [string]$ReportPath = "",

    [switch]$KeepTemp
)

$ErrorActionPreference = "Stop"

function Write-Step {
    param([string]$Message)
    Write-Host "[home-check-local] $Message"
}

function Stop-ProcessTree {
    param([int]$ProcessId)

    Get-CimInstance Win32_Process -Filter "ParentProcessId=$ProcessId" -ErrorAction SilentlyContinue | ForEach-Object {
        Stop-ProcessTree -ProcessId ([int]$_.ProcessId)
    }
    Stop-Process -Id $ProcessId -Force -ErrorAction SilentlyContinue
}

function Test-PackedFile {
    param([string]$Path)

    $file = Get-Item -LiteralPath $Path -ErrorAction Stop
    $headLength = [Math]::Min(16, [int]$file.Length)
    if ($headLength -le 0) {
        return $false
    }

    $fs = [System.IO.File]::OpenRead($file.FullName)
    try {
        $headBytes = New-Object byte[] $headLength
        [void]$fs.Read($headBytes, 0, $headLength)
    }
    finally {
        $fs.Close()
    }

    $headText = [System.Text.Encoding]::ASCII.GetString($headBytes)
    return $headText.StartsWith("%TSD-Header-###%")
}

$toolRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$checkerExe = Join-Path $toolRoot "checkList_V1.28.exe"

if (-not (Test-Path -LiteralPath $checkerExe)) {
    throw "Checker exe not found: $checkerExe"
}

$svnCmd = Get-Command svn -ErrorAction SilentlyContinue
if ($null -eq $svnCmd) {
    throw "svn command not found. Please install SVN CLI or add svn.exe to PATH."
}

if ([string]::IsNullOrWhiteSpace($ReportPath)) {
    $timeText = Get-Date -Format "yyyyMMdd_HHmmss"
    $ReportPath = Join-Path $toolRoot "check_report_svn_local_$timeText.txt"
}

$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("home_check_local_" + [System.Guid]::NewGuid().ToString("N"))
$svnRoot = Join-Path $tempRoot "svn_project"
$runRoot = Join-Path $tempRoot "runner"
$projectDirName = ([string]([char]0x5DE5) + [string]([char]0x7A0B) + [string]([char]0x6587) + [string]([char]0x4EF6))
$projectRoot = Join-Path $runRoot $projectDirName
$svnLog = Join-Path $tempRoot "svn.log"
$svnErrLog = Join-Path $tempRoot "svn_stderr.log"

try {
    New-Item -ItemType Directory -Path $svnRoot -Force | Out-Null
    New-Item -ItemType Directory -Path $runRoot -Force | Out-Null
    New-Item -ItemType Directory -Path $projectRoot -Force | Out-Null

    foreach ($name in @("checkList_V1.28.exe", "checkList_item_cfg.yml", "bms_pro_cfg.yml")) {
        $src = Join-Path $toolRoot $name
        if (-not (Test-Path -LiteralPath $src)) {
            throw "Required checker file is missing: $src"
        }
        Copy-Item -LiteralPath $src -Destination $runRoot -Force
    }

    Write-Step "Exporting SVN code to a short temporary path: $SvnUrl"
    $svnArgs = @(
        "export",
        "--force",
        "--depth", "infinity",
        "--non-interactive",
        "--trust-server-cert-failures=unknown-ca,cn-mismatch,expired,not-yet-valid,other"
    )
    if (-not [string]::IsNullOrWhiteSpace($Revision)) {
        $svnArgs += @("-r", $Revision)
    }
    $svnArgs += @($SvnUrl, $svnRoot)

    $svnProcess = Start-Process -FilePath $svnCmd.Source -ArgumentList $svnArgs -Wait -PassThru -NoNewWindow -RedirectStandardOutput $svnLog -RedirectStandardError $svnErrLog
    if ($svnProcess.ExitCode -ne 0) {
        @(
            "SVN export failed.",
            "SVN exit code: $($svnProcess.ExitCode)",
            "SVN log: $svnLog",
            "SVN error log: $svnErrLog"
        ) | Set-Content -LiteralPath $ReportPath -Encoding UTF8
        throw "SVN export failed. Exit code: $($svnProcess.ExitCode)"
    }

    $bmsConfig = Get-ChildItem -Path $svnRoot -Recurse -File -Filter "Bms_Config.h" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -eq $bmsConfig) {
        @(
            "Bms_Config.h was not found after SVN export.",
            "SVN log: $svnLog",
            "SVN error log: $svnErrLog",
            "The checker was not run because the project configuration cannot be read."
        ) | Set-Content -LiteralPath $ReportPath -Encoding UTF8
        throw "Bms_Config.h was not found after SVN export."
    }

    if (Test-PackedFile -Path $bmsConfig.FullName) {
        @(
            "SVN export finished, but Bms_Config.h is still packed/encrypted.",
            "Bms_Config.h: $($bmsConfig.FullName)",
            "Header: %TSD-Header-###%",
            "The checker was not run because the project configuration cannot be read.",
            "Use a local SVN/decrypt workflow that produces plain C files, then run local self-check."
        ) | Set-Content -LiteralPath $ReportPath -Encoding UTF8
        throw "Bms_Config.h is still packed after SVN export."
    }

    Write-Step "Copying exported code into runner 工程文件 directory."
    Copy-Item -Path (Join-Path $svnRoot "*") -Destination $projectRoot -Recurse -Force

    $runnerBmsConfig = Get-ChildItem -Path $projectRoot -Recurse -File -Filter "Bms_Config.h" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -eq $runnerBmsConfig) {
        @(
            "Bms_Config.h was not found after copying code into 工程文件.",
            "The checker was not run because running it now would produce a low-confidence PCB=0000V000 report."
        ) | Set-Content -LiteralPath $ReportPath -Encoding UTF8
        throw "Bms_Config.h was not found after copy."
    }

    Write-Step "Running checkList_V1.28.exe."
    $sourceReport = Join-Path $runRoot "check_report.txt"
    if (Test-Path -LiteralPath $sourceReport) {
        Remove-Item -LiteralPath $sourceReport -Force
    }

    $checkerCmd = 'cd /d "' + $runRoot + '" && checkList_V1.28.exe'
    $process = Start-Process -FilePath "cmd.exe" -ArgumentList @("/d", "/c", $checkerCmd) -WorkingDirectory $runRoot -WindowStyle Hidden -PassThru

    $deadline = (Get-Date).AddSeconds(180)
    $lastLength = -1
    $stableCount = 0
    while ((Get-Date) -lt $deadline) {
        if (Test-Path -LiteralPath $sourceReport) {
            $length = (Get-Item -LiteralPath $sourceReport).Length
            if (($length -eq $lastLength) -and ($length -gt 1000)) {
                $stableCount += 1
            }
            else {
                $stableCount = 0
                $lastLength = $length
            }

            if ($stableCount -ge 3) {
                break
            }
        }
        Start-Sleep -Milliseconds 500
    }

    if (Test-Path -LiteralPath $sourceReport) {
        Copy-Item -LiteralPath $sourceReport -Destination $ReportPath -Force
        Write-Step "Report generated: $ReportPath"
    }
    else {
        @(
            "check_report.txt was not generated.",
            "The checker was started in a hidden cmd window and waited for 180 seconds.",
            "Runner root: $runRoot",
            "SVN log: $svnLog",
            "SVN error log: $svnErrLog",
            "The source runner fallback is not used automatically unless the YAML rules are confirmed to be plain and readable."
        ) | Set-Content -LiteralPath $ReportPath -Encoding UTF8
        Write-Step "Report not found. Diagnostic file generated: $ReportPath"
    }

    Stop-ProcessTree -ProcessId ([int]$process.Id)
}
finally {
    if ($KeepTemp) {
        Write-Step "Temporary directory kept by request: $tempRoot"
    }
    elseif (Test-Path -LiteralPath $tempRoot) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force
        Write-Step "Temporary directory removed."
    }
}
