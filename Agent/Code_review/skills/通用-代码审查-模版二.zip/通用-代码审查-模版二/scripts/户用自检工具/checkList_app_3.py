import os
import yaml
from typing import List, Dict, Any, Optional, Set
import re
from pro_cfg_class import BMSHardwareConfig
import baseFunc
import project_class
import file_base
from macro_class import CMacroDefinition
import logging
import sys
import colorama
colorama.init()


class ConfigLoader:
    """配置加载器"""

    @staticmethod
    def load_yaml(file_path: str) -> Dict[str, Any]:
        """加载YAML配置文件"""
        with open(file_path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)


class ProjectConfig:
    """工程配置类"""

    def __init__(self, project_path: str):
        self.project_path = project_path
        self.file_list = self._get_project_files()
        self.cfg_table = BMSHardwareConfig('bms_pro_cfg.yml')
        self.software_ver = self._detect_software_ver()
        self.pcb_type = self._detect_pcb_type()
        self.afe_type = self._detect_afe_type()
        self.current = self._detect_current()
        self.sample_resistor = self._detect_sample_resistor()
        self.sample_resistor_exp = self._detect_sample_resistor_exp()
        self.upgrade_config = self._detect_upgrade_config()

    def _get_project_files(self) -> List[str]:
        """获取工程文件夹下的所有文件列表"""
        file_list = file_base.get_file_list(self.project_path, [".c", ".h"], ["BOOTLOADER"])
        print("ProjectConfig file list:")
        for idx, file in enumerate(file_list):
            if 'Bms_Config.h' in file:
                print(f'{idx}: {file}')
        return file_list

    def _detect_software_ver(self) -> str:
        """检测软件版本号 - 预留实现 - 示例值:"P16S200A-21887-3.20-013" """
        # 实际项目中可以从工程文件中的特定文件或宏定义中获取
        macro_hardware = CMacroDefinition(self.file_list, "Bms_Config.h", "PACESOFTWARE_VERSOIN")
        if macro_hardware:
            s = macro_hardware.macro_value
            software_ver = s.strip('"\'') if isinstance(s, str) else s
            return software_ver
        return "P00S000A-00000-0.00-000"

    def _detect_pcb_type(self) -> str:
        """检测PCB类型 - 预留实现 - 示例值:"1547V320" """
        # 实际项目中可以从工程文件中的特定文件或宏定义中获取
        macro_hardware = CMacroDefinition(self.file_list, "Bms_Config.h", "HARDWARE_VERSOIN")
        if macro_hardware:
            s = macro_hardware.macro_value
            pcb_type = s.strip('"\'') if isinstance(s, str) else s
            return pcb_type
        return "0000V000"

    def _detect_afe_type(self) -> str:
        """检测AFE类型 - 预留实现 - 示例值:"MPS2797" """
        # 实际项目中可以从工程文件中的特定文件或宏定义中获取

        afe_type = self.cfg_table.get_afe_by_pcb(self.pcb_type)
        return afe_type  # 示例值

    def _detect_current(self) -> int:
        """检测电流规格 - 从SOFTWARE_VERSOIN宏中提取（例如"P16S150A-32107-1.00"中的150） - 示例值:"150" """
        # 首先尝试从Bms_Config.h文件中的SOFTWARE_VERSOIN宏获取电流值
        import re
        macro_version = CMacroDefinition(self.file_list, "Bms_Config.h", "SOFTWARE_VERSOIN")
        if macro_version:
            try:
                # 从版本号中提取S后面、A前面的数字（电流值）
                # 例如: "P16S150A-32107-1.00" -> 150
                match = re.search(r'S(\d+)A', macro_version.macro_value)
                if match:
                    return int(match.group(1))
                else:
                    print(f"警告: 无法从SOFTWARE_VERSOIN中提取电流值: {macro_version.macro_value}")
            except (ValueError, TypeError) as e:
                print(f"警告: 解析SOFTWARE_VERSOIN时出错: {e}")
        
        # 如果从SOFTWARE_VERSOIN获取失败，尝试从LIMIT_START_CURRENT获取（向后兼容）
        macro_current = CMacroDefinition(self.file_list, "Bms_Config.h", "LIMIT_START_CURRENT")
        if macro_current:
            try:
                # 获取宏值并转换为数字，然后除以1000
                current_value = int(macro_current.macro_value)
                return current_value // 1000  # 整除1000
            except (ValueError, TypeError):
                print(f"警告: 无法解析LIMIT_START_CURRENT的值: {macro_current.macro_value}")
        
        return 0  # 默认值 

    def _detect_sample_resistor(self) -> int:
        """检测采样电阻个数 - 从SAMPLINGRESISTANCE宏获取 - 示例值:"16" """
        # 从Bms_Config.h文件中获取SAMPLINGRESISTANCE宏定义的值
        macro_resistor = CMacroDefinition(self.file_list, "Bms_Config.h", "SAMPLINGRESISTANCE")
        if macro_resistor:
            try:
                # 先转换为 float 再转为 int，支持 "10.0" 这种格式
                return int(float(macro_resistor.macro_value))
            except (ValueError, TypeError):
                print(f"警告: SAMPLINGRESISTANCE 宏值 '{macro_resistor.macro_value}' 无法转换为整数")
                return 0
        return 0  # 默认值

    def _detect_sample_resistor_exp(self) -> int:
        """检测采样电阻个数 - 预留实现 - 示例值:"16" """
        # 实际项目中可以从工程配置或特定文件中获取
        sample_resistor_exp = self.cfg_table.get_sample_resistor_for_current(self.pcb_type, self.current)
        return sample_resistor_exp  # 默认值

    def _detect_upgrade_config(self) -> str:
        """检测采样电阻个数 - 预留实现 - 示例值:"0x0F" """
        # 实际项目中可以从工程配置或特定文件中获取
        file_path = file_base.find_file_in_list("Data_Init.c", self.file_list)
        upgrade_config = project_class.extract_upgrade_config_value(file_path)
        return upgrade_config


class CheckItem:
    """检查项类"""

    def __init__(self, item_config: Dict[str, Any]):
        self.id = item_config['id']
        self.description = item_config['description']
        self.pcb_type = item_config.get('pcb_type', ['all'])
        self.afe_type = item_config.get('afe_type', ['all'])
        self.enabled = item_config.get('enabled', True)
        self.if_list = item_config.get('if_list', [])
        self.if_logic = item_config.get('if_logic', "")
        self.version_filter = item_config.get('version_filter', None)  # 新增：版本过滤

    def is_applicable(self, pcb_type: str, afe_type: str, sample_resistor: int, software_ver: str = "") -> bool:
        """检查是否适用于当前工程配置"""
        if not self.enabled:
            print('\033[33m---- 自检项未使能，无需自检 ----\033[0m')
            return False

        # 处理版本号过滤
        if self.version_filter and software_ver:
            # 从软件版本中提取版本号，支持字母后缀，例如：
            #   "P16S200A-21887-3.20-013"  -> "3.20"
            #   "SST22-1887-1.00A-013"     -> "1.00A"
            import re
            version_match = re.search(r'-(\d+\.\d+[A-Za-z]?)-', software_ver)
            if version_match:
                current_version = version_match.group(1)

                def _ver_equal(v1, v2):
                    """比较两个版本号：纯数字部分用 float 比较（1.00==1.0），
                    字母后缀须完全一致（1.0A != 1.0）。"""
                    m1 = re.match(r'^(\d+\.\d+)([A-Za-z]*)$', str(v1))
                    m2 = re.match(r'^(\d+\.\d+)([A-Za-z]*)$', str(v2))
                    if m1 and m2:
                        return (float(m1.group(1)) == float(m2.group(1))
                                and m1.group(2).upper() == m2.group(2).upper())
                    return str(v1) == str(v2)

                # version_filter 可以是列表或字典
                if isinstance(self.version_filter, list):
                    # 如果是列表，检查当前版本是否在列表中
                    if not any(_ver_equal(current_version, v) for v in self.version_filter):
                        print(f'\033[33m---- 版本:{current_version}，不在检查范围内（需要: {self.version_filter}），无需自检 ----\033[0m')
                        return False
                elif isinstance(self.version_filter, dict):
                    # 如果是字典，支持 include 和 exclude
                    # 检查是否在排除列表中
                    exclude_versions = self.version_filter.get('exclude', [])
                    if any(_ver_equal(current_version, v) for v in exclude_versions):
                        print(f'\033[33m---- 版本:{current_version}，在排除范围内，无需自检 ----\033[0m')
                        return False
                    # 检查是否在包含列表中
                    include_versions = self.version_filter.get('include', [])
                    if include_versions and not any(_ver_equal(current_version, v) for v in include_versions):
                        print(f'\033[33m---- 版本:{current_version}，不在检查范围内，无需自检 ----\033[0m')
                        return False

        # 处理PCB类型检查
        pcb_ok = True
        # 首先检查排除项（!pcb_type格式）
        exclude_types = [t[1:] for t in self.pcb_type if t.startswith('!')]
        if pcb_type in exclude_types:
            print(f'\033[33m---- pcb:{pcb_type}，在排除范围内，无需自检 ----\033[0m')
            return False
        # 然后检查包含项（常规检查）
        include_types = [t for t in self.pcb_type if not t.startswith('!')]
        if include_types:  # 只有存在包含项时才需要检查
            pcb_ok = ('all' in include_types) or (pcb_type in include_types)
        if not pcb_ok:
            print(f'\033[33m---- pcb:{pcb_type}，不在检查范围内，无需自检 ----\033[0m')
        # AFE类型检查保持不变
        afe_ok = ('all' in self.afe_type) or (afe_type in self.afe_type)
        if not afe_ok:
            print(f'\033[33m---- afe:{afe_type}，不在检查范围内，无需自检 ----\033[0m')

        return pcb_ok and afe_ok


class ConditionChecker:
    """条件检查器"""

    def __init__(self, project_path: str, file_list: List[str]):
        self.project_path = project_path
        self.pro_cfg = ProjectConfig(project_path)
        self.file_list = file_list

    def check_condition(self, condition: Dict[str, Any]) -> bool:
        """检查单个条件"""
        if_type = condition['if_type']

        if if_type == 'file':
            return self._check_file_condition(condition)
        elif if_type == 'struct':
            return self._check_struct_condition(condition)
        elif if_type == 'macro':
            return self._check_macro_condition(condition)
        elif if_type == 'code':
            return self._check_code_condition(condition)
        elif if_type == 'line':
            return self._check_line_condition(condition)
        elif if_type == 'logic':
            return self._check_logic_condition(condition)
        elif if_type == 'ewp_version':
            return self._check_ewp_version_condition(condition)
        else:
            raise ValueError(f"Unknown condition type: {if_type}")

    def _check_file_condition(self, condition: Dict[str, Any]) -> bool:
        """检查文件是否存在"""
        file_name = condition['file_name']
        expected_flag = condition.get('flag', True)

        # 检查文件是否在工程文件列表中
        # file_exists = file_name in self.file_list
        from file_base import is_filename_in_paths
        file_exists = is_filename_in_paths(file_name, self.file_list)

        return file_exists == expected_flag

    def _check_struct_condition(self, condition: Dict[str, Any]) -> bool:
        """检查结构体定义"""
        file_name = condition["file_name"]
        struct_name = condition['struct_name']
        ele_cfg = condition['ele_cfg']
        # 检查文件是否存在
        if file_base.is_filename_in_paths(file_name, self.file_list) is False:
            print('检查文件是否存在:不存在', file_name)
            return False

        # 实际实现需要struct_class.py支持
        # 这里预留接口，实际项目中实现具体检查逻辑
        from struct_class import CStructRead
        checker = CStructRead(self.file_list, file_name, struct_name)
        return checker.validate_members(ele_cfg, True)

    def _check_macro_condition(self, condition: Dict[str, Any]) -> bool:
        """检查宏定义"""
        print("====== macro condition ======")
        macro_cfg = condition['macro_cfg']
        # print(macro_cfg)

        # 实际实现需要macro_class.py支持
        # 这里预留接口，实际项目中实现具体检查逻辑
        from macro_class import CMacroDefinition
        results = []
        
        # 特殊处理：检查SOFTWARE_VERSOIN和PACESOFTWARE_VERSOIN版本号一致性
        if len(macro_cfg) == 2 and \
           any(m['macro_name'] == 'SOFTWARE_VERSOIN' for m in macro_cfg) and \
           any(m['macro_name'] == 'PACESOFTWARE_VERSOIN' for m in macro_cfg):
            # 这是checkList56的版本号一致性检查
            import re
            software_ver = None
            pace_software_ver = None
            
            for macro in macro_cfg:
                if file_base.is_filename_in_paths(macro['src_file_name'], self.file_list) is False:
                    print('检查文件是否存在:不存在', macro['src_file_name'])
                    continue
                macro_read = CMacroDefinition(self.file_list, macro['src_file_name'], macro['macro_name'], verbose=True)
                
                if macro['macro_name'] == 'SOFTWARE_VERSOIN':
                    software_ver = macro_read.macro_value
                elif macro['macro_name'] == 'PACESOFTWARE_VERSOIN':
                    pace_software_ver = macro_read.macro_value
            
            if software_ver and pace_software_ver:
                # 提取版本号主体部分（去掉引号、空格和版本后缀）
                # 例如: '"P16S150A-32107-1.00  "' -> "P16S150A-32107-1.00"
                # 例如: '"P16S150A-32107-1.00-002"' -> "P16S150A-32107-1.00"
                software_main = software_ver.strip().strip('"').strip()
                pace_full = pace_software_ver.strip().strip('"').strip()
                # 从PACESOFTWARE_VERSOIN中提取主版本号（去掉-xxx后缀）
                pace_match = re.match(r'([^-]+-[^-]+-[^-]+)', pace_full)
                pace_main = pace_match.group(1) if pace_match else pace_full
                
                print(f"SOFTWARE_VERSOIN主体: '{software_main}'")
                print(f"PACESOFTWARE_VERSOIN主体: '{pace_main}'")
                
                if software_main == pace_main:
                    print("✓ 版本号一致")
                    return True
                else:
                    print(f"✖ 版本号不一致: SOFTWARE_VERSOIN='{software_main}' vs PACESOFTWARE_VERSOIN='{pace_main}'")
                    return False
            else:
                print("警告: 无法读取版本号宏")
                return False
        
        # 常规宏检查逻辑
        for macro in macro_cfg:
            # 检查文件是否存在
            if file_base.is_filename_in_paths(macro['src_file_name'], self.file_list) is False:
                print('检查文件是否存在:不存在', macro['src_file_name'])
                results.append(False)
                continue
            macro_read = CMacroDefinition(self.file_list, macro['src_file_name'], macro['macro_name'], verbose=True)
            
            # 检查是否有字符串长度限制
            if 'string_max_length' in macro or 'string_min_length' in macro:
                min_len = macro.get('string_min_length', None)
                max_len = macro.get('string_max_length', None)
                result = macro_read.is_string_length_in_range(min_len, max_len)
            elif macro.get('check_exists_only', False):
                # 仅检查宏是否存在，不关心值
                result = macro_read.exists
                print(f'[仅检查存在] 宏: {macro["macro_name"]} => {"存在" if result else "不存在"}')
            elif 'macro_value' not in macro:
                # 未提供目标值时，回退为存在性检查，避免配置缺少macro_value导致崩溃
                result = macro_read.exists
                print(f'[缺少macro_value，回退为存在性检查] 宏: {macro["macro_name"]} => {"存在" if result else "不存在"}')
            else:
                # 常规值比较
                result = macro_read.is_value_equal(macro['macro_value'])
                if macro_read.macro_name == 'SAMPLINGRESISTANCE':
                    print('采样电阻数单独处理:')
                    if self.pro_cfg.sample_resistor == self.pro_cfg.sample_resistor_exp:
                        result = True
                    else:
                        result = False
            results.append(result)

        return all(results)

    def _check_code_condition(self, condition: Dict[str, Any]) -> bool:
        """检查代码逻辑"""
        code_cfg = condition['code_cfg']
        expected_flag = condition.get('flag', True)

        # 实际实现需要key_code_class.py支持
        # 这里预留接口，实际项目中实现具体检查逻辑
        from key_code_class import check_c_key_logic

        results = []
        for code in code_cfg:
            # 检查文件是否存在
            if file_base.is_filename_in_paths(code['file_name'], self.file_list) is False:
                print('检查文件是否存在:不存在', code['file_name'])
                results.append(False)
                continue
            expected_flag = code.get('flag', True)
            allow_function_not_exist = code.get('allow_function_not_exist', False)
            
            result_temp, line = check_c_key_logic(
                file_list=self.file_list,
                target_filename=code["file_name"],
                function_name=code["func_name"],
                keywords=code["key_list"],
                verbose=True
            )

            # 如果允许函数不存在，且line为None（表示函数不存在），则认为通过
            if allow_function_not_exist and line is None and not result_temp:
                print(f'函数不存在，但allow_function_not_exist=True，检查通过')
                condition_ret = True
            else:
                condition_ret = result_temp == expected_flag
            
            print(f'expected_flag:{expected_flag} condition ret:{condition_ret}\n')
            results.append(condition_ret)
        return all(results)

    def _check_line_condition(self, condition: Dict[str, Any]) -> bool:
        """检查关键行"""
        line_cfg_list = condition['line_cfg']
        from key_code_class import check_keywords_in_file_line

        results = []
        for line_cfg in line_cfg_list:
            # 检查文件是否存在
            if file_base.is_filename_in_paths(line_cfg['file_name'], self.file_list) is False:
                print('检查文件是否存在:不存在', line_cfg['file_name'])
                results.append(False)
                continue
            expected_flag = line_cfg.get('flag', True)
            result_temp, line = check_keywords_in_file_line(
                file_list=self.file_list,
                target_filename=line_cfg["file_name"],
                keywords=line_cfg["key_list"],
            )

            condition_ret = result_temp == expected_flag
            print(f'expected_flag:{expected_flag} condition ret:{condition_ret}')
            results.append(condition_ret)
        return all(results)

    def _check_logic_condition(self, condition: Dict[str, Any]) -> bool:
        """检查逻辑组合"""
        return True

    def _check_ewp_version_condition(self, condition: Dict[str, Any]) -> bool:
        """检查.ewp文件中的输出文件名与PACESOFTWARE_VERSOIN版本号一致性"""
        print("====== ewp_version condition ======")
        ewp_cfg = condition['ewp_cfg']
        
        import re
        import xml.etree.ElementTree as ET
        from macro_class import CMacroDefinition
        
        for cfg in ewp_cfg:
            ewp_pattern = cfg.get('ewp_pattern', '*.ewp')
            macro_name = cfg['macro_name']
            src_file_name = cfg['src_file_name']
            
            # 1. 读取PACESOFTWARE_VERSOIN宏的值
            if not file_base.is_filename_in_paths(src_file_name, self.file_list):
                print(f'检查文件是否存在:不存在 {src_file_name}')
                continue
                
            macro_read = CMacroDefinition(self.file_list, src_file_name, macro_name, verbose=True)
            if not macro_read.macro_value:
                print(f'无法读取宏 {macro_name}')
                return False
            
            # 提取宏中的版本号部分（例如: "P16S150A-32107-1.00-002" -> "32107-1.00-002"）
            # 支持版本号中包含字母，如: "P16S100A-52121-1.00G-000" -> "52121-1.00G-000"
            pace_version = macro_read.macro_value.strip().strip('"').strip()
            version_match = re.search(r'-(\d+-[\d\.A-Za-z]+-\d+)', pace_version)
            if not version_match:
                print(f'无法从PACESOFTWARE_VERSOIN中提取版本号: {pace_version}')
                return False
            
            expected_version = version_match.group(1)  # 例如: "32107-1.00-002"
            print(f"从PACESOFTWARE_VERSOIN提取的版本号: '{expected_version}'")
            
            # 2. 查找.ewp文件（重新扫描工程目录，因为file_list中只包含.c和.h文件）
            import os
            ewp_files = []
            for root, dirs, files in os.walk(self.project_path):
                # 排除BOOTLOADER文件夹
                if 'BOOTLOADER' in root:
                    continue
                for file in files:
                    if file.endswith('.ewp'):
                        ewp_files.append(os.path.join(root, file))
            
            if not ewp_files:
                print('未找到.ewp文件')
                return False
            
            print(f"找到.ewp文件: {len(ewp_files)}个")
            
            # 3. 解析.ewp文件，查找IlinkOutputFile
            for ewp_file in ewp_files:
                print(f"检查文件: {ewp_file}")
                try:
                    tree = ET.parse(ewp_file)
                    root = tree.getroot()
                    
                    # 查找所有IlinkOutputFile节点
                    found_match = False
                    for option in root.findall('.//option'):
                        name_elem = option.find('name')
                        state_elem = option.find('state')
                        
                        if name_elem is not None and state_elem is not None:
                            if name_elem.text == 'IlinkOutputFile':
                                output_file = state_elem.text
                                print(f"找到输出文件名: '{output_file}'")
                                
                                # 从输出文件名中提取版本号部分
                                # 例如: "P21887V130-32107-1.00-002.out" -> "32107-1.00-002"
                                # 支持版本号中包含字母: "P41047V200-52121-1.00G-000.out" -> "52121-1.00G-000"
                                file_version_match = re.search(r'-(\d+-[\d\.A-Za-z]+-\d+)\.out', output_file)
                                if file_version_match:
                                    file_version = file_version_match.group(1)
                                    print(f"从输出文件名提取的版本号: '{file_version}'")
                                    
                                    if file_version == expected_version:
                                        print(f"✓ 版本号一致: {file_version}")
                                        found_match = True
                                        break  # 找到匹配后立即退出循环，避免检查其他配置项
                                    else:
                                        print(f"✖ 版本号不一致:")
                                        print(f"  .ewp文件: '{file_version}'")
                                        print(f"  宏定义: '{expected_version}'")
                                        return False
                                else:
                                    # 跳过无法提取版本号的配置项（可能是旧配置或无效配置）
                                    pass
                    
                    if found_match:
                        return True
                        
                except Exception as e:
                    print(f"解析.ewp文件失败: {e}")
                    continue
            
            print("未找到匹配的IlinkOutputFile配置")
            return False
        
        return True


class CheckListProcessor:
    """检查项处理器"""

    def __init__(self, project_path: str):
        self.project_path = project_path
        self.project_config = ProjectConfig(project_path)
        self.condition_checker = ConditionChecker(
            project_path,
            self.project_config.file_list
        )

        # 加载配置文件
        self.bms_config = ConfigLoader.load_yaml('bms_pro_cfg.yml')
        self.check_items_config = ConfigLoader.load_yaml('checkList_item_cfg.yml')
        self.check_items_version = self.check_items_config['version']

        # 日志系统
        # self.debug_handler = debug_class.setup_logging()
        logging.info(f"初始化检查处理器，工程路径: {project_path}")

    def process_check_items(self) -> List[Dict[str, Any]]:
        """处理所有检查项"""
        results = []

        for item_config in self.check_items_config['checks']:
            check_item = CheckItem(item_config)
            print(f"\n\033[94m******************** {check_item.id} ********************\033[0m")

            if not check_item.is_applicable(
                    self.project_config.pcb_type,
                    self.project_config.afe_type,
                    self.project_config.sample_resistor,
                    self.project_config.software_ver
            ):
                results.append({
                    'id': check_item.id,
                    'description': check_item.description,
                    'result': True,
                    'details': "项目无需执行该自检项",
                    'pcb_type': self.project_config.pcb_type,
                    'afe_type': self.project_config.afe_type,
                    'sample_resistor': self.project_config.sample_resistor,
                    'if_list': check_item.if_list  # 添加检查条件内容
                })
                continue

            condition_results = []
            conditions = []
            for idx, condition in enumerate(check_item.if_list, 1):
                item_result = self.condition_checker.check_condition(condition)
                condition_results.append(
                    (idx, item_result))
                conditions.append(item_result)

            # 评估逻辑表达式
            # logic_expr = check_item.if_logic
            # for idx, result in condition_results:
            #     logic_expr = logic_expr.replace(str(idx), str(result))
            #
            # try:
            #     final_result = eval(logic_expr)
            # except Exception as e:
            #     print(f"Error evaluating logic expression for {check_item.id}: {e}")
            #     final_result = False
            final_result = baseFunc.evaluate_conditions(conditions, check_item.if_logic)

            if final_result is False:
                print(f'\033[31m检查结果：检测不通过\033[0m')
            else:
                print(f'\033[32m检查结果：检测通过\033[0m')

            results.append({
                'id': check_item.id,
                'description': check_item.description,
                'result': final_result,
                'details': condition_results,
                'pcb_type': self.project_config.pcb_type,
                'afe_type': self.project_config.afe_type,
                'sample_resistor': self.project_config.sample_resistor,
                'if_list': check_item.if_list  # 添加检查条件内容
            })

        return results

    def generate_report(self, project_path: str, results: List[Dict[str, Any]], report_file: str = 'check_report.txt'):
        """生成检查报告"""
        with open(report_file, 'w', encoding='utf-8') as f:
            # 1. 报告标题和工程特征
            f.write("=" * 50 + "\n")
            f.write("工程代码检查报告\n")
            f.write("=" * 50 + "\n\n")

            # 工程特征项集中展示
            f.write("工程特征配置:\n")
            f.write("-" * 50 + "\n")
            f.write(f"PCB类型: {self.project_config.pcb_type}\n")
            f.write(f"AFE类型: {self.project_config.afe_type}\n")
            f.write(f"采样电阻个数: {self.project_config.sample_resistor}\n")
            f.write(f"工程路径: {self.project_path}\n")
            f.write("-" * 50 + "\n\n")

            # 2. 检查结果汇总
            failed_items = [item for item in results if not item['result']]
            total_failed = len(failed_items)

            f.write("检查结果总览:\n")
            f.write("-" * 50 + "\n")
            f.write(f"总检查项: {len(results)}\n")
            f.write(f"通过项: {len(results) - total_failed}\n")
            f.write(f"失败项: {total_failed}\n")
            f.write("-" * 50 + "\n\n")

            # 3. 失败项明细（带工程特征提醒）
            if total_failed > 0:
                f.write("失败项明细 (当前工程配置: "
                        f"PCB={self.project_config.pcb_type}, "
                        f"AFE={self.project_config.afe_type}, "
                        f"采样电阻={self.project_config.sample_resistor}):\n")
                f.write("=" * 50 + "\n")
                for idx, item in enumerate(failed_items, 1):
                    f.write(f"{idx}. ID: {item['id']}\n")
                    f.write(f"   描述: {item['description']}\n")
                    f.write(f"   适用配置: PCB={item.get('pcb_type', 'all')}, "
                            f"AFE={item.get('afe_type', 'all')}, "
                            f"采样电阻={item.get('sample_resistor', 'N/A')}\n")

                    # 失败原因分析
                    f.write("   失败原因:\n")
                    for cond_idx, (_, cond_result) in enumerate(item['details'], 1):
                        if not cond_result:
                            condition = item['if_list'][cond_idx - 1]
                            f.write(f"     - 条件{cond_idx}: {self._format_condition_detail(condition)}\n")
                f.write("=" * 50 + "\n\n")

            # 4. 详细检查结果
            f.write("详细检查结果:\n")
            f.write("=" * 50 + "\n")
            for item in results:
                f.write(f"检查项ID: {item['id']}\n")
                f.write(f"描述: {item['description']}\n")
                f.write(f"结果: {'通过' if item['result'] else '失败'}\n")

                if not item['result']:
                    f.write("失败详情:\n")
                    for cond_idx, (_, cond_result) in enumerate(item['details'], 1):
                        condition = item['if_list'][cond_idx - 1]
                        f.write(f"  {cond_idx}. {self._format_condition_detail(condition)} → "
                                f"{'满足' if cond_result else '不满足'}\n")
                f.write("-" * 50 + "\n")

            # 5. 最终汇总
            f.write("\n最终统计:\n")
            f.write("-" * 50 + "\n")
            f.write(f"总检查项: {len(results)}\n")
            f.write(f"通过率: {(len(results) - total_failed) / len(results) * 100:.1f}%\n")
            if total_failed > 0:
                f.write("\n需关注的失败项:\n")
                for item in failed_items:
                    f.write(f" - {item['id']}: {item['description']}\n")

        # 最终结果总结
        all_pass_flag = True
        color = '\033[32m'
        ret = '通过'
        if total_failed:
            all_pass_flag = False
            color = '\033[31m'
            ret = '不通过'

        # 控制台输出
        print("\n" + "=" * 50)
        print(f"Tool ver:{self.check_items_version}".center(50))
        print(f"{color}检查结果汇总-{ret}".center(50))
        print("=" * 50)
        print(f"工程路径: {project_path}")
        print(f"软件版本: {self.project_config.software_ver}")
        print(f"工程配置: PCB={self.project_config.pcb_type}, "
              f"AFE={self.project_config.afe_type}, "
              f"电流={self.project_config.current}, "
              f"采样电阻={self.project_config.sample_resistor}, "
              f"采样电阻预期={self.project_config.sample_resistor_exp}, "
              f"\033[1;32m升级默认恢复配置={self.project_config.upgrade_config}\033[0m")
        print(f"总检查项: {len(results)}")
        print(f"{color}失败项: {total_failed}\033[0m")

        if total_failed > 0:
            print("\n失败项列表 (与当前工程配置相关):")
            for idx, item in enumerate(failed_items, 1):
                print(f"{idx}. {item['id']}: {item['description']}")
                # print(f"   适用配置范围: PCB={item.get('pcb_type', 'all')}, "
                #       f"AFE={item.get('afe_type', 'all')}")

        print("\n详细报告已生成:", report_file)

    def _format_condition_detail(self, condition: Dict[str, Any]) -> str:
        """格式化条件详情用于报告输出"""
        if_type = condition['if_type']
        if if_type == 'file':
            return f"检查文件 '{condition['file_name']}' 是否存在(期望: {'存在' if condition.get('flag', True) else '不存在'})"
        elif if_type == 'struct':
            details = []
            for ele in condition['ele_cfg']:
                details.append(f"{ele['ele_name']}(类型应为:{ele['ele_type']})")
            return f"检查结构体 '{condition['struct_name']}' 定义: {', '.join(details)}"
        elif if_type == 'macro':
            details = []
            for macro in condition['macro_cfg']:
                val_info = f"值应为: {macro['macro_value']}" if 'macro_value' in macro else "只需存在"
                details.append(f"{macro['macro_name']}(文件:{macro['src_file_name']}, {val_info})")
            return f"检查宏定义: {'; '.join(details)}"
        elif if_type == 'code':
            details = []
            for code in condition['code_cfg']:
                keys = " | ".join(code['key_list'])
                details.append(f"在 {code['file_name']} 的 {code['func_name']} 中检查: {keys}")
            return f"检查代码逻辑: {'; '.join(details)}"
        return str(condition)

    def show_debug_window(self):
        """显示调试窗口"""
        try:
            if not hasattr(self, 'debug_handler') or self.debug_handler is None:
                logging.warning("debug_handler 未初始化，跳过调试窗口显示")
                return

            import tkinter as tk
            root = tk.Tk()
            root.title("BMS检查工具调试窗口")

            text = tk.Text(root, wrap=tk.WORD)
            scroll = tk.Scrollbar(root, command=text.yview)
            text.configure(yscrollcommand=scroll.set)

            for record in self.debug_handler.log_records:
                text.insert(tk.END, record + "\n")

            text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
            scroll.pack(side=tk.RIGHT, fill=tk.Y)

            root.mainloop()
        except ImportError:
            logging.warning("未安装tkinter，无法显示调试窗口")


def main():
    # 工程路径 - 示例中使用"SST22-1887-V1.30"
    nowPath = os.getcwd()
    project_path = nowPath + '\\工程文件'

    if not os.path.exists(project_path):
        print(f"错误: 工程路径 '{project_path}' 不存在!")
        return

    # 处理检查项
    processor = CheckListProcessor(project_path)
    try:
        results = processor.process_check_items()
        processor.generate_report(project_path, results)

        # 检查是否有失败项
        # failed_items = [item for item in results if not item['result']]
        # if failed_items:
        #     print('fail---', failed_items)
        #     processor.show_debug_window()  # 有失败时自动显示调试窗口
    except Exception as e:
        logging.error(f"检查过程中发生错误: {str(e)}", exc_info=True)
        processor.show_debug_window()
        sys.exit(1)

    # 生成报告
    # processor.generate_report(project_path, results)
    folderNameInput = input("输入任意内容继续：")


if __name__ == "__main__":
    main()
