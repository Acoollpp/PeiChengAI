import os
import re
from typing import List, Tuple, Optional


def check_c_key_logic(
        file_list: List[str],
        target_filename: str,
        function_name: str,  # 格式如 "void SystemPara_Init"
        keywords: List[str],
        verbose: bool = True
) -> Tuple[bool, Optional[int]]:
    """
    简化版C语言关键逻辑检查函数

    参数:
        file_list: 文件路径列表（绝对路径）
        target_filename: 目标文件名（不含路径）
        function_name: 带返回值的函数名（如 "void SystemPara_Init"）
        keywords: 需要按顺序匹配的关键词列表
        verbose: 是否显示详细过程

    返回:
        (是否完全匹配, 最后匹配的行号)
    """
    if verbose:
        print("=" * 50)
        print(f"🔍 开始查找函数: {function_name}")
        print(f"📂 目标文件: {target_filename}")
        print(f"🔑 关键词列表: {keywords}")
        print("=" * 50)

    # ==================== 1. 文件检查 ====================
    target_file = next((f for f in file_list if os.path.basename(f).lower() == target_filename.lower()), None)
    if not target_file:
        print(f"✖ 错误：未找到目标文件 '{target_filename}'")
        return False, None

    if not os.path.exists(target_file):
        print(f"✖ 错误：文件 '{target_file}' 不存在或无法访问")
        return False, None

    # ==================== 2. 模式定义 ====================
    # 简化函数定义模式（要求输入带返回值的完整函数名）
    # func_def_pattern = re.compile(
    #     rf'^{re.escape(function_name)}\s*\([^)]*\)\s*' + r'\{?\s*$'
    # )
    func_def_pattern = re.compile(
        rf'^(?:\w+\s+)*{re.escape(function_name)}\s*\([^)]*\)\s*' + r'\{?\s*$',
    )

    # 注释处理模式
    comment_patterns = {
        'block_start': re.compile(r'/\*'),
        'block_end': re.compile(r'\*/'),
        'line_comment': re.compile(r'//.*$')
    }

    # ==================== 3. 文件解析 ====================
    found_function = False
    in_comment_block = False  # 是否在块注释中
    in_target_function = False
    brace_level = 0
    current_keyword_idx = 0
    last_matched_line = -1

    with open(target_file, 'r', encoding='utf-8', errors='ignore') as f:
        for line_num, line in enumerate(f, 1):
            # 预处理：移除字符串内容
            line = re.sub(r'"[^"]*"', '""', line)

            # 空行跳过
            if not line.strip():
                continue

            # ========== 注释处理 ==========
            if in_comment_block:
                # 块注释结束检查
                if comment_patterns['block_end'].search(line):
                    line = comment_patterns['block_end'].split(line)[1]
                    in_comment_block = False
                else:
                    continue
            else:
                # 处理行注释
                line = comment_patterns['line_comment'].sub('', line)
                # 处理块注释开始
                if comment_patterns['block_start'].search(line):
                    parts = comment_patterns['block_start'].split(line, 1)
                    line = parts[0]
                    if not comment_patterns['block_end'].search(parts[1]):
                        in_comment_block = True
                        continue

            # ========== 函数定义检测 ==========
            if not in_target_function:
                if func_def_pattern.search(line):
                    in_target_function = True
                    found_function = True
                    brace_level = line.count('{')
                    if verbose:
                        print(f"✓ 找到函数定义: {function_name} (行 {line_num})")
                    if '{' not in line:
                        continue

            # ========== 函数内关键词匹配 ==========
            if in_target_function:
                brace_level += line.count('{')
                brace_level -= line.count('}')

                # 关键词匹配（仅当在函数体内）
                remaining_line = line
                while current_keyword_idx < len(keywords) and brace_level > 0:
                    kw = keywords[current_keyword_idx]
                    if kw in remaining_line:
                        if verbose:
                            print(f"  匹配关键词 [{current_keyword_idx + 1}/{len(keywords)}]: "
                                  f"'{kw}' (行 {line_num})")
                        current_keyword_idx += 1
                        last_matched_line = line_num
                        remaining_line = remaining_line.split(kw, 1)[1]
                    else:
                        break

                # 函数结束检查
                if brace_level <= 0 and ('}' in line or line.strip().startswith('return')):
                    if verbose:
                        print(f"→ 函数结束 (行 {line_num})")
                    break

    # ==================== 4. 结果处理 ====================
    if not found_function:
        print(f"✖ 在文件 '{target_filename}' 中未找到函数 '{function_name}'")
        return False, None

    if current_keyword_idx == len(keywords):
        if verbose:
            print(f"✔ 所有关键词匹配完成！ (共 {len(keywords)} 个)")
        return True, last_matched_line
    else:
        if verbose:
            print(f"⚠ 关键词匹配不完整 ({current_keyword_idx}/{len(keywords)})")
            if last_matched_line > 0:
                print(f"  最后匹配位置: 行 {last_matched_line}")
                if current_keyword_idx < len(keywords):
                    print(f"  下一个期望关键词: '{keywords[current_keyword_idx]}'")
        return False, last_matched_line


def check_keywords_in_file_line(
        file_list: List[str],
        target_filename: str,
        keywords: List[str],
        require_order: bool = True,
        verbose: bool = True
) -> Tuple[bool, Optional[int]]:
    """
    检查指定文件中是否存在包含所有关键词的行（支持顺序检查）

    参数:
        file_list: 文件路径列表（绝对路径）
        target_filename: 目标文件名（不含路径）
        keywords: 需要匹配的关键词列表
        require_order: 是否要求关键词按顺序出现（默认为True）
        verbose: 是否显示详细过程

    返回:
        (是否匹配成功, 匹配行号)
    """
    if verbose:
        print("=" * 50)
        print(f"🔍 开始查找文件: {target_filename}")
        print(f"🔑 关键词列表: {keywords}")
        print(f"📏 顺序要求: {'是' if require_order else '否'}")
        print("=" * 50)

    # ==================== 1. 文件检查 ====================
    target_file = next((f for f in file_list if os.path.basename(f).lower() == target_filename.lower()), None)
    if not target_file:
        print(f"✖ 错误：未找到目标文件 '{target_filename}'")
        return False, None

    if not os.path.exists(target_file):
        print(f"✖ 错误：文件 '{target_file}' 不存在或无法访问")
        return False, None

    # ==================== 2. 文件扫描 ====================
    with open(target_file, 'r', encoding='utf-8', errors='ignore') as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue

            # 检查关键词匹配
            if require_order:
                # 顺序匹配逻辑
                remaining_line = line
                matched_all = True
                for kw in keywords:
                    kw_pos = remaining_line.find(kw)
                    if kw_pos == -1:
                        matched_all = False
                        break
                    remaining_line = remaining_line[kw_pos + len(kw):]
            else:
                # 非顺序匹配逻辑（只需包含所有关键词）
                matched_all = all(kw in line for kw in keywords)

            if matched_all:
                if verbose:
                    print(f"✓ 匹配成功 (行 {line_num}): {line[:100]}{'...' if len(line)>100 else ''}")
                return True, line_num

    # ==================== 3. 结果返回 ====================
    if verbose:
        print(f"✖ 未找到包含所有关键词的行")
        print(f"  搜索关键词: {keywords}")
        if require_order:
            print(f"  要求顺序: 是")
    return False, None


# ==================== 测试用例 ====================
if __name__ == "__main__":
    # 创建测试文件
    TEST_FILE = "test_code.c"
    TEST_CONTENT = """
#include <stdio.h>

void SystemPara_Init(int param) {
    // 初始化
    Status1 = 0;
    Status2 = 0;

    if (param > 100) {
        return;
    }

    printf("初始化完成");
}

void other_func() {
    SystemPara_Init(50);  // 不应被误判
}
"""
    with open(TEST_FILE, "w") as f:
        f.write(TEST_CONTENT)

    print("===== 测试1：正常情况 =====")
    check_c_key_logic(
        file_list=[os.path.abspath(TEST_FILE)],
        target_filename=TEST_FILE,
        function_name="void SystemPara_Init",
        keywords=["Status1 = 0", "Status2 = 0"],
        verbose=True
    )

    # 清理测试文件
    os.remove(TEST_FILE)
