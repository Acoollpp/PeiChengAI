﻿param(
    [Parameter(Mandatory = $true, Position = 0)]
    [string]$SvnUrl,

    [string]$Revision = "",

    [string]$RulesJson = "",

    [string]$ReportPath = ""
)

$ErrorActionPreference = "Stop"

function Invoke-SvnText {
    param(
        [ValidateSet("list", "cat")]
        [string]$Command,
        [string]$Url,
        [switch]$Recursive
    )

    $args = @(
        "--non-interactive",
        "--trust-server-cert-failures=unknown-ca,cn-mismatch,expired,not-yet-valid,other",
        $Command
    )
    if ($Command -eq "list" -and $Recursive) { $args += "-R" }
    if (-not [string]::IsNullOrWhiteSpace($Revision)) { $args += @("-r", $Revision) }
    $args += $Url

    $output = & svn @args 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw (($output | Out-String).Trim())
    }
    return ($output | Out-String)
}

function Get-BaseName {
    param([string]$Path)
    return (($Path -replace "\\", "/").TrimEnd("/") -split "/")[-1]
}

function Remove-CComments {
    param([string]$Text)
    $Text = [regex]::Replace($Text, "/\*.*?\*/", "", "Singleline")
    return [regex]::Replace($Text, "//.*?$", "", "Multiline")
}

function Get-Macro {
    param([string]$FileName, [string]$MacroName)
    $item = Read-RemoteByName $FileName
    if ($null -eq $item) { return $null }
    $pattern = "(?m)^\s*#\s*define\s+$([regex]::Escape($MacroName))\s*(\([^)]*\))?\s*(.*?)\s*(?:/\*.*?\*/|//.*?)?$"
    $m = [regex]::Match($item.Text, $pattern)
    if (-not $m.Success) { return $null }
    [pscustomobject]@{
        File = $item.Path
        Name = $MacroName
        Value = $m.Groups[2].Value.Trim()
    }
}

function Get-FunctionBody {
    param([string]$Text, [string]$FunctionName)
    $nameTail = (($FunctionName.Trim() -split "\s+")[-1])
    $pattern = "(?m)\b$([regex]::Escape($nameTail))\s*\([^)]*\)\s*\{"
    $m = [regex]::Match($Text, $pattern)
    if (-not $m.Success) { return $null }
    $brace = $Text.IndexOf("{", $m.Index)
    if ($brace -lt 0) { return $null }
    $depth = 0
    for ($i = $brace; $i -lt $Text.Length; $i++) {
        if ($Text[$i] -eq "{") { $depth++ }
        elseif ($Text[$i] -eq "}") {
            $depth--
            if ($depth -eq 0) {
                return $Text.Substring($m.Index, $i - $m.Index + 1)
            }
        }
    }
    return $null
}

function Test-KeywordsInOrder {
    param([string]$Text, [object[]]$Keywords)
    $pos = 0
    foreach ($kw in $Keywords) {
        $idx = $Text.IndexOf([string]$kw, $pos, [StringComparison]::Ordinal)
        if ($idx -lt 0) { return $false }
        $pos = $idx + ([string]$kw).Length
    }
    return $true
}

function Test-Logic {
    param([bool[]]$Conditions, [string]$Logic)
    $expr = $Logic
    for ($i = 0; $i -lt $Conditions.Count; $i++) {
        $expr = [regex]::Replace($expr, "\b$($i + 1)\b", $(if ($Conditions[$i]) { '$true' } else { '$false' }))
    }
    $expr = $expr.Replace("&&", " -and ").Replace("||", " -or ").Replace("!", " -not ")
    return [bool](Invoke-Expression $expr)
}

function Test-VersionEqual {
    param([string]$Left, [string]$Right)
    $m1 = [regex]::Match($Left, "^(\d+\.\d+)([A-Za-z]*)$")
    $m2 = [regex]::Match($Right, "^(\d+\.\d+)([A-Za-z]*)$")
    if ($m1.Success -and $m2.Success) {
        return ([double]$m1.Groups[1].Value -eq [double]$m2.Groups[1].Value) -and ($m1.Groups[2].Value.ToUpperInvariant() -eq $m2.Groups[2].Value.ToUpperInvariant())
    }
    return $Left -eq $Right
}

function Test-ItemApplicable {
    param($Item, $ProjectConfig)
    if ($Item.enabled -eq $false) { return $false }

    if ($null -ne $Item.version_filter -and -not [string]::IsNullOrWhiteSpace($ProjectConfig.SoftwareVer)) {
        $m = [regex]::Match($ProjectConfig.SoftwareVer, "-(\d+\.\d+[A-Za-z]?)-")
        if ($m.Success) {
            $currentVersion = $m.Groups[1].Value
            if ($Item.version_filter -is [array]) {
                $hit = $false
                foreach ($v in @($Item.version_filter)) {
                    if (Test-VersionEqual $currentVersion ([string]$v)) { $hit = $true; break }
                }
                if (-not $hit) { return $false }
            }
            elseif ($null -ne $Item.version_filter.include -or $null -ne $Item.version_filter.exclude) {
                foreach ($v in @($Item.version_filter.exclude)) {
                    if (Test-VersionEqual $currentVersion ([string]$v)) { return $false }
                }
                if ($null -ne $Item.version_filter.include) {
                    $hit = $false
                    foreach ($v in @($Item.version_filter.include)) {
                        if (Test-VersionEqual $currentVersion ([string]$v)) { $hit = $true; break }
                    }
                    if (-not $hit) { return $false }
                }
            }
        }
    }

    foreach ($pcb in @($Item.pcb_type)) {
        $pcbText = [string]$pcb
        if ($pcbText.StartsWith("!") -and $ProjectConfig.PcbType -eq $pcbText.Substring(1)) { return $false }
    }
    $includePcb = @($Item.pcb_type | Where-Object { -not ([string]$_).StartsWith("!") })
    $pcbOk = $true
    if ($includePcb.Count -gt 0) {
        $pcbOk = ($includePcb -contains "all") -or ($includePcb -contains $ProjectConfig.PcbType)
    }
    $afeOk = (@($Item.afe_type) -contains "all") -or (@($Item.afe_type) -contains $ProjectConfig.AfeType)
    return $pcbOk -and $afeOk
}

function Find-RemoteFiles {
    param([string]$FileName)
    $key = $FileName.ToLowerInvariant()
    if ($script:FileIndex.ContainsKey($key)) { return $script:FileIndex[$key] }
    return @()
}

function Read-RemotePath {
    param([string]$Path)
    if (-not $script:TextCache.ContainsKey($Path)) {
        $script:TextCache[$Path] = Invoke-SvnText -Command cat -Url "$script:SvnRoot/$Path"
    }
    return $script:TextCache[$Path]
}

function Read-RemoteByName {
    param([string]$FileName)
    $matches = @(Find-RemoteFiles $FileName)
    if ($matches.Count -eq 0) { return $null }
    $preferred = @($matches | Where-Object { $_ -like "*/User/*" -or $_ -like "*/EWARM/*" })
    if ($preferred.Count -gt 0) { $matches = $preferred }
    $path = $matches[0]
    [pscustomobject]@{ Path = $path; Text = Read-RemotePath $path }
}

function Test-StructCondition {
    param($Condition)
    $item = Read-RemoteByName $Condition.file_name
    if ($null -eq $item) { return $false }
    $clean = Remove-CComments $item.Text
    $name = ([regex]::Replace($Condition.struct_name, "(typedef\s+)?struct\s+", "")).Trim()
    $m = [regex]::Match($clean, "(?s)(?:typedef\s+)?struct\s*(?:\w+\s*)?\{(.*?)\}\s*$([regex]::Escape($name))\s*;")
    if (-not $m.Success) { return $false }
    $members = @{}
    foreach ($mm in [regex]::Matches($m.Groups[1].Value, "(?m)^\s*([A-Za-z_][\w\s\*]*?)\s+([A-Za-z_]\w*)(\s*\[[^\]]+\])?\s*;")) {
        $members[$mm.Groups[2].Value.Trim()] = ($mm.Groups[1].Value.Trim() + $mm.Groups[3].Value.Trim())
    }
    foreach ($ele in $Condition.ele_cfg) {
        if (-not $members.ContainsKey($ele.ele_name)) { return $false }
        $actual = (($members[$ele.ele_name] -replace "\s+", " ") -replace "\s*\*\s*", "*").Trim()
        $expect = (([string]$ele.ele_type -replace "\s+", " ") -replace "\s*\*\s*", "*").Trim()
        if ($actual -ne $expect) { return $false }
    }
    return $true
}

function Test-Condition {
    param($Condition, $ProjectConfig)
    switch ($Condition.if_type) {
        "file" {
            return (@(Find-RemoteFiles $Condition.file_name).Count -gt 0) -eq [bool]$Condition.flag
        }
        "struct" {
            return Test-StructCondition $Condition
        }
        "macro" {
            $macroCfg = @($Condition.macro_cfg)
            if (
                $macroCfg.Count -eq 2 -and
                @($macroCfg | Where-Object { $_.macro_name -eq "SOFTWARE_VERSOIN" }).Count -gt 0 -and
                @($macroCfg | Where-Object { $_.macro_name -eq "PACESOFTWARE_VERSOIN" }).Count -gt 0
            ) {
                $software = Get-Macro $macroCfg[0].src_file_name "SOFTWARE_VERSOIN"
                $pace = Get-Macro $macroCfg[1].src_file_name "PACESOFTWARE_VERSOIN"
                if ($null -eq $software -or $null -eq $pace) { return $false }
                $softwareMain = $software.Value.Trim().Trim('"').Trim()
                $paceFull = $pace.Value.Trim().Trim('"').Trim()
                $m = [regex]::Match($paceFull, "([^-]+-[^-]+-[^-]+)")
                $paceMain = $(if ($m.Success) { $m.Groups[1].Value } else { $paceFull })
                return $softwareMain -eq $paceMain
            }
            $results = foreach ($mCfg in $macroCfg) {
                $macro = Get-Macro $mCfg.src_file_name $mCfg.macro_name
                if ($null -eq $macro) { $false; continue }
                if ($null -ne $mCfg.string_max_length -or $null -ne $mCfg.string_min_length) {
                    $v = $macro.Value.Trim().Trim('"')
                    (($null -eq $mCfg.string_min_length -or $v.Length -ge [int]$mCfg.string_min_length) -and
                     ($null -eq $mCfg.string_max_length -or $v.Length -le [int]$mCfg.string_max_length))
                }
                elseif ($mCfg.check_exists_only -eq $true -or $null -eq $mCfg.macro_value) {
                    $true
                }
                elseif ($mCfg.macro_name -eq "SAMPLINGRESISTANCE") {
                    $ProjectConfig.SampleResistor -eq $ProjectConfig.SampleResistorExpected
                }
                else {
                    $macro.Value -eq [string]$mCfg.macro_value
                }
            }
            return -not ($results -contains $false)
        }
        "code" {
            $results = foreach ($code in @($Condition.code_cfg)) {
                $item = Read-RemoteByName $code.file_name
                $expected = if ($null -ne $code.flag) { [bool]$code.flag } else { [bool]$Condition.flag }
                if ($null -eq $item) { $false -eq $expected; continue }
                $body = Get-FunctionBody -Text $item.Text -FunctionName $code.func_name
                $missing = $null -eq $body
                $hit = if ($missing) { $false } else { Test-KeywordsInOrder (Remove-CComments $body) $code.key_list }
                if ($code.allow_function_not_exist -eq $true -and $missing -and -not $hit) { $true } else { $hit -eq $expected }
            }
            return -not ($results -contains $false)
        }
        "line" {
            $results = foreach ($lineCfg in @($Condition.line_cfg)) {
                $item = Read-RemoteByName $lineCfg.file_name
                $expected = if ($null -ne $lineCfg.flag) { [bool]$lineCfg.flag } else { $true }
                if ($null -eq $item) { $false -eq $expected; continue }
                $hit = $false
                foreach ($line in ($item.Text -split "`r?`n")) {
                    if (Test-KeywordsInOrder $line.Trim() $lineCfg.key_list) { $hit = $true; break }
                }
                $hit -eq $expected
            }
            return -not ($results -contains $false)
        }
        "logic" { return $true }
        "ewp_version" {
            foreach ($cfg in @($Condition.ewp_cfg)) {
                $macro = Get-Macro $cfg.src_file_name $cfg.macro_name
                if ($null -eq $macro) { return $false }
                $m = [regex]::Match($macro.Value.Trim().Trim('"'), "-(\d+-[\d\.A-Za-z]+-\d+)")
                if (-not $m.Success) { return $false }
                $expectedVersion = $m.Groups[1].Value
                $ewpFiles = @(Find-RemoteFiles "*.ewp")
                if ($ewpFiles.Count -eq 0) { $ewpFiles = @($script:KnownFiles | Where-Object { $_.ToLowerInvariant().EndsWith(".ewp") }) }
                foreach ($ewp in $ewpFiles) {
                    $text = Read-RemotePath $ewp
                    if ($text -match [regex]::Escape($expectedVersion)) { return $true }
                }
                return $false
            }
            return $true
        }
        default { throw "未知条件类型：$($Condition.if_type)" }
    }
}

$toolDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($RulesJson)) { $RulesJson = Join-Path $toolDir "checkList_item_cfg.json" }
if ([string]::IsNullOrWhiteSpace($ReportPath)) {
    $ReportPath = Join-Path $toolDir ("check_report_svn_remote_{0}.txt" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
}

$script:SvnRoot = $SvnUrl.TrimEnd("/")
$script:TextCache = @{}
$script:KnownFiles = @()
$script:FileIndex = @{}

$urlLeaf = (($script:SvnRoot -split "/")[-1])
$projectDirs = @($urlLeaf)
try {
    $topList = Invoke-SvnText -Command list -Url $script:SvnRoot
    foreach ($line in ($topList -split "`r?`n")) {
        $entry = $line.Trim().TrimEnd("/")
        if (-not $entry) { continue }
        if ($entry -eq "BOOTLOADER" -or $entry -eq "doc") { continue }
        if ($entry.ToUpperInvariant().StartsWith("SST") -and -not ($projectDirs -contains $entry)) {
            $projectDirs += $entry
        }
        try {
            $secondList = Invoke-SvnText -Command list -Url "$script:SvnRoot/$entry"
            foreach ($secondLine in ($secondList -split "`r?`n")) {
                $second = $secondLine.Trim().TrimEnd("/")
                if ($second.ToUpperInvariant().StartsWith("SST")) {
                    $candidate = "$entry/$second"
                    if (-not ($projectDirs -contains $candidate)) {
                        $projectDirs += $candidate
                    }
                }
            }
        }
        catch {
        }
    }
}
catch {
}
$folders = @("User", "User_Lib/inc", "User_Lib/src", "InverterCANProtocol", "Inverter485Protocol", "EWARM")
foreach ($projectDir in $projectDirs) {
    foreach ($folder in $folders) {
        $base = "$projectDir/$folder"
        try {
            $listText = Invoke-SvnText -Command list -Url "$script:SvnRoot/$base" -Recursive
            foreach ($line in ($listText -split "`r?`n")) {
                $item = $line.Trim()
                if ($item -and -not $item.EndsWith("/")) {
                    $script:KnownFiles += "$base/$item"
                }
            }
        }
        catch {
        }
    }
}
$script:KnownFiles = @($script:KnownFiles | Select-Object -Unique)
foreach ($file in $script:KnownFiles) {
    $name = (Get-BaseName $file).ToLowerInvariant()
    if (-not $script:FileIndex.ContainsKey($name)) { $script:FileIndex[$name] = @() }
    $script:FileIndex[$name] += $file
}

$rules = Get-Content -LiteralPath $RulesJson -Raw -Encoding UTF8 | ConvertFrom-Json
$bmsProPath = Join-Path $toolDir "bms_pro_cfg.json"
$bmsPro = Get-Content -LiteralPath $bmsProPath -Raw -Encoding UTF8 | ConvertFrom-Json
$bmsConfig = Get-Macro "Bms_Config.h" "HARDWARE_VERSOIN"
$software = Get-Macro "Bms_Config.h" "PACESOFTWARE_VERSOIN"
$sampling = Get-Macro "Bms_Config.h" "SAMPLINGRESISTANCE"
$currentMacro = Get-Macro "Bms_Config.h" "SOFTWARE_VERSOIN"
$current = 0
if ($null -ne $currentMacro -and $currentMacro.Value -match "S(\d+)A") { $current = [int]$Matches[1] }
$sample = 0
if ($null -ne $sampling) { $sample = [int]([double]$sampling.Value) }
$pcbType = if ($null -ne $bmsConfig) { $bmsConfig.Value.Trim().Trim('"') } else { "0000V000" }
$afeType = "unknown"
$sampleExpected = $sample
foreach ($hw in @($bmsPro.hardWares)) {
    if ([string]$hw.pcb -eq $pcbType) {
        $afeType = [string]$hw.afe
        foreach ($spec in @($hw.spec)) {
            if ([int]$spec.current -eq $current) {
                $sampleExpected = [int]$spec.sample_resistor
                break
            }
        }
        break
    }
}
$projectConfig = [pscustomobject]@{
    PcbType = $pcbType
    SoftwareVer = if ($null -ne $software) { $software.Value.Trim().Trim('"') } else { "P00S000A-00000-0.00-000" }
    Current = $current
    SampleResistor = $sample
    SampleResistorExpected = $sampleExpected
    AfeType = $afeType
}

$results = @()
foreach ($item in @($rules.checks)) {
    if (-not (Test-ItemApplicable -Item $item -ProjectConfig $projectConfig)) {
        $results += [pscustomobject]@{
            id = $item.id
            description = $item.description
            result = $true
            details = @()
            skipped = $true
        }
        continue
    }
    $conditions = @()
    $details = @()
    foreach ($cond in @($item.if_list)) {
        $ret = Test-Condition -Condition $cond -ProjectConfig $projectConfig
        $conditions += [bool]$ret
        $details += [pscustomobject]@{ Result = [bool]$ret; Condition = $cond }
    }
    $final = Test-Logic -Conditions $conditions -Logic $item.if_logic
    $results += [pscustomobject]@{
        id = $item.id
        description = $item.description
        result = $final
        details = $details
        skipped = $false
    }
}

$failed = @($results | Where-Object { -not $_.result })
$lines = @()
$lines += "=================================================="
$lines += "SVN远程工程代码检查报告"
$lines += "=================================================="
$lines += ""
$lines += "检查方式:"
$lines += "--------------------------------------------------"
$lines += "仅读取 SVN 远端文件内容，未 checkout，未 export 工程代码。"
$lines += "--------------------------------------------------"
$lines += ""
$lines += "工程特征配置:"
$lines += "--------------------------------------------------"
$lines += "PCB类型: $($projectConfig.PcbType)"
$lines += "AFE类型: $($projectConfig.AfeType)"
$lines += "软件版本: $($projectConfig.SoftwareVer)"
$lines += "采样电阻个数: $($projectConfig.SampleResistor)"
$lines += "采样电阻预期: $($projectConfig.SampleResistorExpected)"
$lines += "SVN地址: $script:SvnRoot"
$lines += "自检审查版本: $(if ([string]::IsNullOrWhiteSpace($Revision)) { '未指定，使用SVN当前版本' } else { 'r' + $Revision.TrimStart('r', 'R') })"
$lines += "远程索引文件数: $($script:KnownFiles.Count)"
$lines += "--------------------------------------------------"
$lines += ""
$lines += "检查结果总览:"
$lines += "--------------------------------------------------"
$lines += "总检查项: $($results.Count)"
$lines += "通过项: $($results.Count - $failed.Count)"
$lines += "失败项: $($failed.Count)"
$lines += "--------------------------------------------------"
$lines += ""
if ($failed.Count -gt 0) {
    $lines += "失败项明细:"
    $lines += "=================================================="
    foreach ($item in $failed) {
        $lines += "检查项ID: $($item.id)"
        $lines += "描述: $($item.description)"
        foreach ($detail in @($item.details)) {
            if (-not $detail.Result) {
                $lines += "失败条件: $($detail.Condition | ConvertTo-Json -Compress -Depth 10)"
            }
        }
        $lines += "--------------------------------------------------"
    }
}
$lines += "详细检查结果:"
$lines += "=================================================="
foreach ($item in $results) {
    $lines += "检查项ID: $($item.id)"
    $lines += "描述: $($item.description)"
    $lines += "结果: $(if ($item.result) { '通过' } else { '失败' })"
    if ($item.skipped) { $lines += "说明: 项目无需执行该自检项" }
    $lines += "--------------------------------------------------"
}

$lines | Set-Content -LiteralPath $ReportPath -Encoding UTF8
Write-Host "详细报告已生成: $ReportPath"
Write-Host "总检查项: $($results.Count)"
Write-Host "失败项: $($failed.Count)"
exit $(if ($failed.Count -gt 0) { 1 } else { 0 })
