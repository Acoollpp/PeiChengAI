import os
import re
import tempfile
from typing import List, Optional, Dict, Any


class CMacroDefinition:
    """
    C语言宏定义解析类，用于从C文件中提取宏定义信息

    属性:
        file_name: 宏定义所在的文件名
        file_path: 宏定义文件的完整路径
        macro_name: 宏名称
        exists: 宏是否存在
        macro_value: 宏的值
        line_number: 宏定义所在行号
        has_parameters: 宏是否带参数
    """

    def __init__(self, file_list: List[str], filename: str, macro_name: str, verbose: bool = False):
        """
        初始化宏定义解析器

        参数:
            file_list: 要搜索的文件列表
            filename: 目标文件名(不含路径)
            macro_name: 要查找的宏名称
            verbose: 是否显示详细调试信息
        """
        self._file_list = file_list
        self._filename = filename
        self._macro_name = macro_name
        self._verbose = verbose

        # 初始化属性
        self._file_path: Optional[str] = None
        self._exists: bool = False
        self._macro_value: Optional[str] = None
        self._line_number: Optional[int] = None
        self._has_parameters: bool = False

        # 解析宏定义
        self._parse_macro()

    @property
    def file_name(self) -> str:
        """获取文件名"""
        return self._filename

    @property
    def file_path(self) -> Optional[str]:
        """获取文件完整路径"""
        return self._file_path

    @property
    def macro_name(self) -> str:
        """获取宏名称"""
        return self._macro_name

    @property
    def exists(self) -> bool:
        """判断宏是否存在"""
        return self._exists

    @property
    def macro_value(self) -> Optional[str]:
        """获取宏的值"""
        return self._macro_value if self._exists else None

    @property
    def line_number(self) -> Optional[int]:
        """获取行号"""
        return self._line_number if self._exists else None

    @property
    def has_parameters(self) -> bool:
        """判断宏是否带参数"""
        return self._has_parameters if self._exists else False

    def _parse_macro(self):
        """解析宏定义的核心方法"""
        # 匹配 #define 宏定义，处理带参数和不带参数的情况
        macro_pattern = re.compile(
            r'^\s*#\s*define\s+' + re.escape(self._macro_name) +
            r'\s*(\([^)]*\))?\s*(.*?)\s*(?:/\*.*?\*/|//.*?)?$',
            re.MULTILINE
        )

        for file_path in self._file_list:
            if os.path.basename(file_path) == self._filename:
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()

                    for match in macro_pattern.finditer(content):
                        # 计算行号
                        line_number = content[:match.start()].count('\n') + 1

                        self._file_path = os.path.abspath(file_path)
                        self._exists = True
                        self._macro_value = match.group(2).strip()
                        self._line_number = line_number
                        self._has_parameters = match.group(1) is not None

                        if self._verbose:
                            print(f"找到宏定义: {self._macro_name} = {self._macro_value} (行号: {line_number})")
                        return
                except (IOError, UnicodeDecodeError):
                    continue

        if self._verbose:
            print(f"\033[31m✖未找到宏定义:\033[0m {self._macro_name}")

    def is_value_equal(self, value: str, ignore_case: bool = False) -> bool:
        """
        判断宏定义的值是否等于给定值

        参数:
            value: 要比较的值
            ignore_case: 是否忽略大小写

        返回:
            bool: 值是否匹配
        """
        if not self._exists:
            if self._verbose:
                print(f"宏 '{self._macro_name}' 不存在，无法比较值")
            return False

        # if self._verbose:
        #     print(f"\n[值比较] 宏: {self._macro_name} | "
        #           f"实际值: {self._macro_value} (类型: {type(self._macro_value)}) | "
        #           f"期望值: {value} (类型: {type(value)}) | "
        #           f"忽略大小写: {'是' if ignore_case else '否'}")

        if ignore_case:
            result = self._macro_value.lower() == value.lower()
        else:
            result = self._macro_value == value

        if self._verbose:
            print(f"[值比较] 宏: {self._macro_name} | "
                  # f"实际值: {self._macro_value} (类型: {type(self._macro_value)}) | "
                  # f"期望值: {value} (类型: {type(value)}) | "
                  f"实际值: {self._macro_value} | "
                  f"期望值: {value} | "
                  f"忽略大小写: {'是' if ignore_case else '否'} | "
                  f"=>  {'匹配' if result else '\033[31m不匹配\033[0m'}")

        return result

    def is_value_contains(self, substring: str, ignore_case: bool = False) -> bool:
        """
        判断宏定义的值是否包含给定子字符串

        参数:
            substring: 要查找的子字符串
            ignore_case: 是否忽略大小写

        返回:
            bool: 是否包含子字符串
        """
        if not self._exists:
            if self._verbose:
                print(f"宏 '{self._macro_name}' 不存在，无法检查包含关系")
            return False

        if self._verbose:
            print(f"[包含检查] 宏: {self._macro_name}")
            print(f"实际值: {self._macro_value}")
            print(f"查找子串: {substring}")
            print(f"忽略大小写: {'是' if ignore_case else '否'}")

        if ignore_case:
            result = substring.lower() in self._macro_value.lower()
        else:
            result = substring in self._macro_value

        if self._verbose:
            print(f"结果: {'包含' if result else '不包含'}")

        return result

    def get_string_length(self) -> Optional[int]:
        """
        获取宏定义字符串值的长度（去除引号后的实际字符数）
        
        返回:
            int: 字符串长度，如果宏不存在或不是字符串则返回None
        """
        if not self._exists:
            if self._verbose:
                print(f"宏 '{self._macro_name}' 不存在，无法获取字符串长度")
            return None
        
        # 去除引号和空白字符
        value = self._macro_value.strip()
        if value.startswith('"') and value.endswith('"'):
            # 去除首尾引号，获取实际字符串内容
            actual_string = value[1:-1]
            length = len(actual_string)
            
            if self._verbose:
                print(f"[字符串长度] 宏: {self._macro_name}")
                print(f"原始值: {self._macro_value}")
                print(f"字符串内容: {actual_string}")
                print(f"字符串长度: {length}")
            
            return length
        else:
            if self._verbose:
                print(f"宏 '{self._macro_name}' 的值不是字符串格式: {self._macro_value}")
            return None

    def is_string_length_in_range(self, min_length: Optional[int] = None, max_length: Optional[int] = None) -> bool:
        """
        判断宏定义字符串值的长度是否在指定范围内
        
        参数:
            min_length: 最小长度（包含），None表示不限制
            max_length: 最大长度（包含），None表示不限制
        
        返回:
            bool: 长度是否在范围内
        """
        length = self.get_string_length()
        
        if length is None:
            if self._verbose:
                print(f"无法获取字符串长度，检查失败")
            return False
        
        result = True
        if min_length is not None and length < min_length:
            result = False
        if max_length is not None and length > max_length:
            result = False
        
        if self._verbose:
            range_str = ""
            if min_length is not None and max_length is not None:
                range_str = f"[{min_length}, {max_length}]"
            elif min_length is not None:
                range_str = f">= {min_length}"
            elif max_length is not None:
                range_str = f"<= {max_length}"
            
            print(f"[长度范围检查] 宏: {self._macro_name}")
            print(f"实际长度: {length}")
            print(f"期望范围: {range_str}")
            print(f"结果: {'通过' if result else '\033[31m不通过\033[0m'}")
        
        return result

    def to_dict(self) -> Dict[str, Any]:
        """将宏定义信息转换为字典"""
        return {
            'file_name': self._filename,
            'file_path': self._file_path,
            'macro_name': self._macro_name,
            'exists': self._exists,
            'macro_value': self._macro_value,
            'line_number': self._line_number,
            'has_parameters': self._has_parameters
        }

    def __str__(self) -> str:
        """返回友好的字符串表示"""
        if self._exists:
            return (f"Macro '{self._macro_name}' found in {self._file_path}:{self._line_number}\n"
                    f"Value: {self._macro_value}\n"
                    f"Has parameters: {self._has_parameters}")
        else:
            return f"Macro '{self._macro_name}' not found in {self._filename}"

    def __bool__(self) -> bool:
        """判断宏是否存在"""
        return self._exists


def create_test_files() -> List[str]:
    """创建测试用的C头文件，返回文件路径列表"""
    file_paths = []

    # 创建第一个测试文件 (config.h)
    file1 = tempfile.NamedTemporaryFile(prefix="config_", suffix=".h", delete=False, mode='w')
    file1.write("""\
/* 配置文件 */
#define APP_VERSION "1.0.0"
#define MAX_USERS 100
#define ENABLE_LOGGING
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#define DEBUG_LEVEL 3
""")
    file1.close()
    file_paths.append(file1.name)

    # 创建第二个测试文件 (utils.h)
    file2 = tempfile.NamedTemporaryFile(prefix="utils_", suffix=".h", delete=False, mode='w')
    file2.write("""\
// 工具函数宏定义
#define PI 3.1415926
#define SQUARE(x) ((x)*(x))
#define DEFAULT_TIMEOUT 5000
""")
    file2.close()
    file_paths.append(file2.name)

    return file_paths


def demo_cmacro_definition():
    """演示CMacroDefinition类的用法"""
    print("=== 创建测试文件 ===")
    test_files = create_test_files()
    file_names = [os.path.basename(f) for f in test_files]
    print(f"已创建测试文件: {file_names}")

    print("\n=== 测试1: 查找存在的简单宏 ===")
    macro = CMacroDefinition(test_files, file_names[0], "MAX_USERS", verbose=True)
    print(macro)
    if macro:
        print("\n--- 测试相等比较 ---")
        print(f"等于100? {macro.is_value_equal('100')}")
        print(f"等于'100'? {macro.is_value_equal('100')}")
        print(f"等于'50'? {macro.is_value_equal('50')}")

        print("\n--- 测试包含检查 ---")
        print(f"包含'10'? {macro.is_value_contains('10')}")
        print(f"包含'200'? {macro.is_value_contains('200')}")

    print("\n=== 测试2: 查找带参数的宏 ===")
    macro = CMacroDefinition(test_files, file_names[0], "MIN", verbose=True)
    print(macro)
    if macro:
        print(f"是带参数的宏? {macro.has_parameters}")
        print("\n--- 测试值比较 ---")
        print(f"等于特定值? {macro.is_value_equal('((a) < (b) ? (a) : (b))')}")

    print("\n=== 测试3: 查找字符串宏 ===")
    macro = CMacroDefinition(test_files, file_names[0], "APP_VERSION", verbose=True)
    print(macro)
    if macro:
        print("\n--- 测试字符串比较 ---")
        print(f"等于'\"1.0.0\"'? {macro.is_value_equal('\"1.0.0\"')}")
        print(f"等于'1.0.0'? {macro.is_value_equal('1.0.0')}")
        print(f"包含'1.0'? {macro.is_value_contains('1.0')}")
        print(f"包含'2.0'? {macro.is_value_contains('2.0')}")
        print(f"忽略大小写比较? {macro.is_value_equal('\"1.0.0\"', ignore_case=True)}")

    print("\n=== 测试4: 查找不存在的宏 ===")
    macro = CMacroDefinition(test_files, file_names[1], "NON_EXISTENT", verbose=True)
    print(macro)
    print(f"存在? {macro.exists}")
    print(f"尝试比较值: {macro.is_value_equal('test')}")

    # 清理测试文件
    for f in test_files:
        try:
            os.unlink(f)
        except:
            pass


if __name__ == "__main__":
    demo_cmacro_definition()
