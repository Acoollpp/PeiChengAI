import os
import re
from typing import List, Dict, Optional, Union


class CStructRead:  # 修改类名为CStructRead
    """
    增强版C语言结构体定义类，支持多种定义格式
    """

    def __init__(self, file_list: List[str], filename: str, struct_name: str):
        self._file_list = file_list
        self._filename = filename
        self._struct_name = self._normalize_struct_name(struct_name)
        self._file_path = ""
        self._line_number = -1
        self._members = {}  # {成员名: 类型}

        self._parse_struct_definition()

    def validate_members(self, member_list: List[Dict], verbose: bool = False) -> bool:
        """
        验证成员类型是否正确（新增接口函数）

        参数:
            member_list: 成员字典列表，格式示例:
                [
                    {"ele_name": "type", "ele_type": "unsigned char"},
                    {"ele_name": "en_name", "ele_type": "unsigned char[20]"}
                ]

        返回:
            bool: 所有成员存在且类型匹配时返回True，否则False
        """
        for member in member_list:
            ele_name = member.get("ele_name")
            ele_type = member.get("ele_type")

            if not ele_name or not ele_type:
                return False

            if not self.is_member_of_type(ele_name, ele_type, verbose):
                return False
        return True

    def _normalize_struct_name(self, name: str) -> str:
        """标准化结构体名称（移除struct/typedef等关键字）"""
        return re.sub(r'(typedef\s+)?struct\s+', '', name).strip()

    def _find_file_path(self) -> str:
        """查找匹配的文件全路径"""
        for full_path in self._file_list:
            if os.path.basename(full_path) == self._filename:
                return full_path
        raise FileNotFoundError(f"找不到文件: {self._filename}")

    def _parse_struct_definition(self):
        """解析结构体定义（支持多种格式）"""
        # 匹配以下格式：
        # 1. typedef struct { ... } StructName;
        # 2. struct StructName { ... };
        # 3. typedef struct StructName { ... } OtherName;
        pattern = re.compile(
            r'(?:typedef\s+)?struct\s+(?:\w+\s*)?\{([^}]*)\}\s*' +
            re.escape(self._struct_name) + r'\s*;',
            re.DOTALL
        )

        self._file_path = self._find_file_path()

        with open(self._file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            content = self._remove_comments(content)

            match = pattern.search(content)
            if not match:
                # 尝试匹配匿名结构体后跟类型名的情况
                alt_pattern = re.compile(
                    r'typedef\s+struct\s*\{([^}]*)\}\s*' +
                    re.escape(self._struct_name) + r'\s*;',
                    re.DOTALL
                )
                match = alt_pattern.search(content)
                if not match:
                    raise ValueError(f"在文件中未找到结构体定义: {self._struct_name}")
            self._line_number = content[:match.start()].count('\n') + 1
            self._parse_members(match.group(1))

    def _remove_comments(self, content: str) -> str:
        """移除所有注释"""
        content = re.sub(r'/\*.*?\*/', '', content, flags=re.DOTALL)
        content = re.sub(r'//.*?$', '', content, flags=re.MULTILINE)
        return content

    def _parse_members(self, members_block: str):
        """解析结构体成员"""
        # 增强的成员匹配模式，支持：
        # 1. 基础类型：int a;
        # 2. 数组类型：char b[20];
        # 3. 指针类型：void* c;
        # 4. 结构体类型：struct foo d;
        member_pattern = re.compile(
            r'^\s*([\w*]+\s+)\s*(\w+)\s*;',
            re.MULTILINE
        )

        for match in member_pattern.finditer(members_block):
            member_type = match.group(1).strip()
            member_name = match.group(2).strip()
            self._members[member_name] = member_type

    def is_member_of_type(self, member_name: str, expected_type: Union[str, List[str]],
                          verbose: bool = True) -> bool:
        """
        判断成员是否为指定类型（带详细输出）

        参数:
            member_name: 成员名称
            expected_type: 期望的类型（字符串或字符串列表）
            verbose: 是否输出类型比较详情

        返回:
            bool: 如果成员存在且类型匹配则返回True

        示例:
            is_member_of_type("type", "unsigned char", verbose=True)
            输出: [结构体检查] 成员 'type' | 实际类型: unsigned char | 期望类型: unsigned char => 匹配
        """
        if member_name not in self._members:
            if verbose:
                print(f"[结构体检查] 成员 '{member_name}' | 错误: 成员不存在")
            return False

        actual_type = self._members[member_name]
        normalized_actual = self._normalize_type(actual_type)

        if isinstance(expected_type, str):
            normalized_expected = self._normalize_type(expected_type)
            result = normalized_actual == normalized_expected
            if verbose:
                status = "=> 匹配" if result else "=> \033[31m不匹配\033[0m"
                print(f"[结构体检查] 成员 '{member_name}' | "
                      f"实际类型: {actual_type} | "
                      f"期望类型: {expected_type} {status}")
            return result
        elif isinstance(expected_type, list):
            if verbose:
                print(f"[结构体检查] 成员 '{member_name}' | 实际类型: {actual_type}")

            for i, exp_type in enumerate(expected_type):
                normalized_exp = self._normalize_type(exp_type)
                if normalized_actual == normalized_exp:
                    if verbose:
                        print(f"  [{i + 1}/{len(expected_type)}] "
                              f"期望类型: {exp_type} => 匹配")
                    return True
                elif verbose:
                    print(f"  [{i + 1}/{len(expected_type)}] "
                          f"期望类型: {exp_type} => \033[31m不匹配\033[0m")
            return False
        return False

    def _normalize_type(self, type_str: str) -> str:
        """
        标准化类型字符串用于比较：
        1. 移除多余空格
        2. 统一指针符号位置
        3. 忽略const限定符
        """
        # 移除所有多余空格
        type_str = re.sub(r'\s+', ' ', type_str.strip())
        # 统一指针符号位置（如 "char *" -> "char*"）
        type_str = re.sub(r'\s*\*\s*', '*', type_str)
        # 移除const限定符
        type_str = re.sub(r'\bconst\b', '', type_str).strip()
        return type_str

    # 原有属性和方法保持不变...
    @property
    def struct_name(self) -> str:
        return self._struct_name

    @property
    def filename(self) -> str:
        return self._filename

    @property
    def file_path(self) -> str:
        return self._file_path

    @property
    def line_number(self) -> int:
        return self._line_number

    @property
    def members(self) -> Dict[str, str]:
        return self._members.copy()

    def get_member_type(self, member_name: str) -> str:
        return self._members[member_name]

    def __str__(self) -> str:
        members_str = '\n'.join([f"  {t} {n};" for n, t in self._members.items()])
        return (f"struct {self._struct_name} (位于 {self._file_path}:{self._line_number})\n"
                f"{members_str}")


# 修改后的测试用例
if __name__ == "__main__":
    # 创建测试文件
    test_file = "test_protocol.h"
    test_content = """
typedef struct
{
    unsigned char type;
    unsigned char en_name[20];
    unsigned char ch_name[20];
    const char*   description;
    struct inner* ptr;
}ProtcNamePack_t;
"""
    with open(test_file, "w") as f:
        f.write(test_content)

    try:
        print("===== 测试成员类型判断 =====")
        from file_base import get_file_list
        file_list = get_file_list('工程文件', [".c", ".h"], ["BOOTLOADER"])
        struct = CStructRead(  # 使用新类名
            # file_list=[os.path.abspath(test_file)],
            file_list=file_list,
            filename='Para_Manage.h',
            struct_name="BatPara_Typedef"
        )
        print('123')
        # 测试原有功能
        struct.is_member_of_type("type", "unsigned char", verbose=True)
        struct.is_member_of_type("type", "int", verbose=True)
        struct.is_member_of_type("description", ["const char*", "char*"], verbose=True)
        struct.is_member_of_type("nonexist", "int", verbose=True)

        # 测试新增的validate_members接口
        print("\n===== 测试validate_members接口 =====")
        member_list = [
            {"ele_name": "type", "ele_type": "unsigned char"},
            {"ele_name": "en_name", "ele_type": "unsigned char[20]"},
            {"ele_name": "description", "ele_type": "const char*"}
        ]
        result = struct.validate_members(member_list)
        print(f"验证结果: {'通过' if result else '失败'}")

        # 测试包含错误类型的场景
        invalid_member_list = [
            {"ele_name": "type", "ele_type": "int"},  # 错误类型
            {"ele_name": "en_name", "ele_type": "unsigned char[20]"}
        ]
        result = struct.validate_members(invalid_member_list)
        print(f"包含错误类型的验证结果: {'通过' if result else '失败'}")

    finally:
        os.remove(test_file)
