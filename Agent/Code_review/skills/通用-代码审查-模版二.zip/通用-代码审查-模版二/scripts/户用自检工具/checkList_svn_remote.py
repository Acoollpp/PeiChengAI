import argparse
import datetime
import json
import os
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml


def decode_bytes(data: bytes) -> str:
    for encoding in ("utf-8-sig", "utf-8", "gbk", "cp936"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def run_svn(args: List[str], timeout: int = 120) -> bytes:
    tool_dir = Path(__file__).resolve().parent
    helper = tool_dir / "svn_remote_io.ps1"
    if helper.exists() and args:
        command = args[0]
        if command in ("list", "cat"):
            recursive = "-R" in args
            revision = ""
            target = args[-1]
            if "-r" in args:
                idx = args.index("-r")
                if idx + 1 < len(args):
                    revision = args[idx + 1]
            ps_args = [
                "powershell",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(helper),
                "-Command",
                command,
                "-Url",
                target,
            ]
            if revision:
                ps_args += ["-Revision", revision]
            if recursive:
                ps_args += ["-Recursive"]
            proc = subprocess.run(
                ps_args,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=timeout,
                check=False,
            )
            if proc.returncode != 0:
                message = decode_bytes(proc.stderr).strip()
                raise RuntimeError(message or f"svn 命令失败，退出码：{proc.returncode}")
            return proc.stdout

    proc = subprocess.run(
        [
            "svn",
            "--non-interactive",
            "--trust-server-cert-failures=unknown-ca,cn-mismatch,expired,not-yet-valid,other",
            *args,
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
        check=False,
    )
    if proc.returncode != 0:
        message = decode_bytes(proc.stderr).strip()
        raise RuntimeError(message or f"svn 命令失败，退出码：{proc.returncode}")
    return proc.stdout


def load_yaml_config(path: Path) -> Dict[str, Any]:
    raw = path.read_bytes()
    if raw.startswith(b"%TSD-Header-###%"):
        raise ValueError(
            f"{path} 是封装文件，不是明文 YAML。"
            "请提供未封装的 checkList_item_cfg.yml，或先用内部工具导出明文规则。"
        )
    return yaml.safe_load(decode_bytes(raw))


def normalize_url(url: str) -> str:
    return url.rstrip("/")


def base_name(path: str) -> str:
    return path.replace("\\", "/").rstrip("/").split("/")[-1]


def remove_comments(content: str) -> str:
    content = re.sub(r"/\*.*?\*/", "", content, flags=re.DOTALL)
    content = re.sub(r"//.*?$", "", content, flags=re.MULTILINE)
    return content


def evaluate_conditions(conditions: List[bool], logic_str: str) -> bool:
    expr = logic_str.replace("&&", " and ").replace("||", " or ").replace("!", "not ")
    for i, value in enumerate(conditions, 1):
        expr = re.sub(rf"\b{i}\b", str(value), expr)
    return bool(eval(expr, {"__builtins__": {}}, {}))


class RemoteProject:
    def __init__(self, url: str, revision: str = ""):
        self.url = normalize_url(url)
        self.revision = revision
        self._top_entries: Optional[List[str]] = None
        self._project_dirs: Optional[List[str]] = None
        self._all_files: Optional[List[str]] = None
        self._source_files: Optional[List[str]] = None
        self._known_files: Optional[List[str]] = None
        self._file_index: Optional[Dict[str, List[str]]] = None
        self._text_cache: Dict[str, str] = {}

    def _with_revision(self, args: List[str]) -> List[str]:
        if self.revision:
            return [*args[:-1], "-r", self.revision, args[-1]]
        return args

    def all_files(self) -> List[str]:
        if self._all_files is None:
            self._all_files = self.known_files()
        return self._all_files

    def known_files(self) -> List[str]:
        if self._known_files is None:
            folders = [
                "User",
                "User_Lib/inc",
                "User_Lib/src",
                "InverterCANProtocol",
                "Inverter485Protocol",
                "EWARM",
            ]
            files: List[str] = []
            for project_dir in self.project_dirs():
                for folder in folders:
                    base = f"{project_dir}/{folder}"
                    try:
                        args = ["list", "-R", f"{self.url}/{base}"]
                        if self.revision:
                            args = ["list", "-R", "-r", self.revision, f"{self.url}/{base}"]
                        text = decode_bytes(run_svn(args, timeout=30))
                    except Exception:
                        continue
                    for line in text.splitlines():
                        item = line.strip()
                        if item and not item.endswith("/"):
                            files.append(f"{base}/{item}")
            self._known_files = list(dict.fromkeys(files))
        return self._known_files

    def top_entries(self) -> List[str]:
        if self._top_entries is None:
            args = ["list", self.url]
            if self.revision:
                args = ["list", "-r", self.revision, self.url]
            text = decode_bytes(run_svn(args, timeout=30))
            self._top_entries = [line.strip() for line in text.splitlines() if line.strip()]
        return self._top_entries

    def project_dirs(self) -> List[str]:
        if self._project_dirs is None:
            url_leaf = self.url.rstrip("/").split("/")[-1]
            guessed = [url_leaf] if url_leaf else []
            try:
                dirs = [entry.rstrip("/") for entry in self.top_entries() if entry.endswith("/")]
            except Exception:
                dirs = []
            preferred = [d for d in dirs if d.upper().startswith("SST")]
            merged = guessed + preferred + [d for d in dirs if d not in preferred]
            self._project_dirs = list(dict.fromkeys([d for d in merged if d]))
        return self._project_dirs

    def source_files(self) -> List[str]:
        if self._source_files is None:
            result = []
            for path in self.all_files():
                lower = path.lower()
                if "bootloader/" in lower:
                    continue
                if lower.endswith((".c", ".h")):
                    result.append(path)
            self._source_files = result
        return self._source_files

    def find_files(self, filename: str, source_only: bool = True) -> List[str]:
        matches = self.file_index().get(filename.lower(), [])
        if source_only:
            matches = [p for p in matches if p.lower().endswith((".c", ".h"))]
        if len(matches) > 1:
            preferred = [p for p in matches if "/User/" in f"/{p}" or "/EWARM/" in f"/{p}"]
            if preferred:
                return preferred
        return matches

    def file_index(self) -> Dict[str, List[str]]:
        if self._file_index is None:
            index: Dict[str, List[str]] = {}
            for path in self.known_files():
                index.setdefault(base_name(path).lower(), []).append(path)
            self._file_index = index
        return self._file_index

    def read_text_optional(self, rel_path: str) -> Optional[str]:
        try:
            return self.read_text(rel_path)
        except Exception:
            return None

    def find_file(self, filename: str, source_only: bool = True) -> Optional[str]:
        matches = self.find_files(filename, source_only=source_only)
        return matches[0] if matches else None

    def exists_file(self, filename: str) -> bool:
        return self.find_file(filename, source_only=True) is not None

    def read_text(self, rel_path: str) -> str:
        if rel_path not in self._text_cache:
            args = ["cat", f"{self.url}/{rel_path}"]
            if self.revision:
                args = ["cat", "-r", self.revision, f"{self.url}/{rel_path}"]
            self._text_cache[rel_path] = decode_bytes(run_svn(args, timeout=120))
        return self._text_cache[rel_path]

    def read_by_name(self, filename: str, source_only: bool = True) -> Tuple[Optional[str], Optional[str]]:
        rel = self.find_file(filename, source_only=source_only)
        if rel is None:
            return None, None
        return rel, self.read_text(rel)


class MacroDefinition:
    def __init__(self, project: RemoteProject, filename: str, macro_name: str):
        self.filename = filename
        self.macro_name = macro_name
        self.file_path: Optional[str] = None
        self.exists = False
        self.macro_value: Optional[str] = None
        self.line_number: Optional[int] = None
        self._parse(project)

    def _parse(self, project: RemoteProject) -> None:
        rel, content = project.read_by_name(self.filename)
        if content is None:
            return
        pattern = re.compile(
            r"^\s*#\s*define\s+"
            + re.escape(self.macro_name)
            + r"\s*(\([^)]*\))?\s*(.*?)\s*(?:/\*.*?\*/|//.*?)?$",
            re.MULTILINE,
        )
        match = pattern.search(content)
        if match:
            self.file_path = rel
            self.exists = True
            self.macro_value = match.group(2).strip()
            self.line_number = content[: match.start()].count("\n") + 1

    def is_value_equal(self, value: Any) -> bool:
        if not self.exists:
            return False
        return str(self.macro_value) == str(value)

    def string_length_in_range(self, min_length: Optional[int], max_length: Optional[int]) -> bool:
        if not self.exists or self.macro_value is None:
            return False
        value = self.macro_value.strip()
        if not (value.startswith('"') and value.endswith('"')):
            return False
        length = len(value[1:-1])
        if min_length is not None and length < min_length:
            return False
        if max_length is not None and length > max_length:
            return False
        return True


class HardwareConfig:
    def __init__(self, config_path: Path):
        self.config_data = load_yaml_config(config_path)

    def get_afe_by_pcb(self, pcb: str) -> str:
        for item in self.config_data.get("hardWares", []):
            if str(item.get("pcb")) == str(pcb):
                return str(item.get("afe", ""))
        return ""

    def get_sample_resistor_for_current(self, pcb: str, current: int) -> int:
        for item in self.config_data.get("hardWares", []):
            if str(item.get("pcb")) != str(pcb):
                continue
            for spec in item.get("spec", []):
                if int(spec.get("current", -1)) == int(current):
                    return int(spec.get("sample_resistor", 0))
        return 0


class ProjectConfig:
    def __init__(self, project: RemoteProject, tool_dir: Path):
        self.project = project
        self.cfg_table = HardwareConfig(tool_dir / "bms_pro_cfg.yml")
        self.software_ver = self._macro_string("Bms_Config.h", "PACESOFTWARE_VERSOIN", "P00S000A-00000-0.00-000")
        self.pcb_type = self._macro_string("Bms_Config.h", "HARDWARE_VERSOIN", "0000V000")
        self.afe_type = self.cfg_table.get_afe_by_pcb(self.pcb_type)
        self.current = self._detect_current()
        self.sample_resistor = self._detect_sample_resistor()
        self.sample_resistor_exp = self.cfg_table.get_sample_resistor_for_current(self.pcb_type, self.current)
        self.upgrade_config = self._detect_upgrade_config()

    def _macro_string(self, filename: str, macro_name: str, default: str) -> str:
        macro = MacroDefinition(self.project, filename, macro_name)
        if macro.exists and macro.macro_value is not None:
            return macro.macro_value.strip().strip('"\'')
        return default

    def _detect_current(self) -> int:
        macro = MacroDefinition(self.project, "Bms_Config.h", "SOFTWARE_VERSOIN")
        if macro.exists and macro.macro_value:
            match = re.search(r"S(\d+)A", macro.macro_value)
            if match:
                return int(match.group(1))
        macro = MacroDefinition(self.project, "Bms_Config.h", "LIMIT_START_CURRENT")
        if macro.exists and macro.macro_value:
            try:
                return int(macro.macro_value) // 1000
            except ValueError:
                return 0
        return 0

    def _detect_sample_resistor(self) -> int:
        macro = MacroDefinition(self.project, "Bms_Config.h", "SAMPLINGRESISTANCE")
        if macro.exists and macro.macro_value:
            try:
                return int(float(macro.macro_value))
            except ValueError:
                return 0
        return 0

    def _detect_upgrade_config(self) -> Optional[str]:
        rel, content = self.project.read_by_name("Data_Init.c")
        if content is None:
            return None
        body = find_function_body(content, "Upgrade_UpdateParameters")
        if body is None:
            return None
        match = re.search(r"UpgradeConfig\s*\|\=\s*(0x[0-9A-Fa-f]+|\d+)\s*;", body)
        return match.group(1) if match else None


class CheckItem:
    def __init__(self, item_config: Dict[str, Any]):
        self.id = item_config["id"]
        self.description = item_config["description"]
        self.pcb_type = item_config.get("pcb_type", ["all"])
        self.afe_type = item_config.get("afe_type", ["all"])
        self.enabled = item_config.get("enabled", True)
        self.if_list = item_config.get("if_list", [])
        self.if_logic = item_config.get("if_logic", "")
        self.version_filter = item_config.get("version_filter", None)

    def is_applicable(self, pcb_type: str, afe_type: str, software_ver: str = "") -> bool:
        if not self.enabled:
            return False
        if self.version_filter and software_ver:
            version_match = re.search(r"-(\d+\.\d+[A-Za-z]?)-", software_ver)
            if version_match:
                current_version = version_match.group(1)
                if isinstance(self.version_filter, list):
                    if not any(version_equal(current_version, v) for v in self.version_filter):
                        return False
                elif isinstance(self.version_filter, dict):
                    excludes = self.version_filter.get("exclude", [])
                    includes = self.version_filter.get("include", [])
                    if any(version_equal(current_version, v) for v in excludes):
                        return False
                    if includes and not any(version_equal(current_version, v) for v in includes):
                        return False
        exclude_types = [t[1:] for t in self.pcb_type if str(t).startswith("!")]
        if pcb_type in exclude_types:
            return False
        include_types = [t for t in self.pcb_type if not str(t).startswith("!")]
        pcb_ok = ("all" in include_types) or (pcb_type in include_types)
        afe_ok = ("all" in self.afe_type) or (afe_type in self.afe_type)
        return pcb_ok and afe_ok


def version_equal(left: Any, right: Any) -> bool:
    m1 = re.match(r"^(\d+\.\d+)([A-Za-z]*)$", str(left))
    m2 = re.match(r"^(\d+\.\d+)([A-Za-z]*)$", str(right))
    if m1 and m2:
        return float(m1.group(1)) == float(m2.group(1)) and m1.group(2).upper() == m2.group(2).upper()
    return str(left) == str(right)


def find_function_body(content: str, function_name: str) -> Optional[str]:
    clean_name = function_name.strip()
    name_tail = clean_name.split()[-1]
    pattern = re.compile(rf"^(?:\w+\s+)*{re.escape(clean_name)}\s*\([^)]*\)\s*\{{?\s*$", re.MULTILINE)
    match = pattern.search(content)
    if not match:
        pattern = re.compile(rf"\b{re.escape(name_tail)}\s*\([^)]*\)\s*\{{", re.MULTILINE)
        match = pattern.search(content)
    if not match:
        return None
    brace = content.find("{", match.start())
    if brace < 0:
        return None
    depth = 0
    for index in range(brace, len(content)):
        char = content[index]
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return content[match.start() : index + 1]
    return None


def keywords_in_order(text: str, keywords: List[str]) -> bool:
    pos = 0
    for keyword in keywords:
        found = text.find(keyword, pos)
        if found < 0:
            return False
        pos = found + len(keyword)
    return True


class ConditionChecker:
    def __init__(self, project: RemoteProject, project_config: ProjectConfig):
        self.project = project
        self.pro_cfg = project_config

    def check_condition(self, condition: Dict[str, Any]) -> bool:
        if_type = condition["if_type"]
        if if_type == "file":
            return self._check_file_condition(condition)
        if if_type == "struct":
            return self._check_struct_condition(condition)
        if if_type == "macro":
            return self._check_macro_condition(condition)
        if if_type == "code":
            return self._check_code_condition(condition)
        if if_type == "line":
            return self._check_line_condition(condition)
        if if_type == "logic":
            return True
        if if_type == "ewp_version":
            return self._check_ewp_version_condition(condition)
        raise ValueError(f"Unknown condition type: {if_type}")

    def _check_file_condition(self, condition: Dict[str, Any]) -> bool:
        return self.project.exists_file(condition["file_name"]) == condition.get("flag", True)

    def _check_struct_condition(self, condition: Dict[str, Any]) -> bool:
        rel, content = self.project.read_by_name(condition["file_name"])
        if content is None:
            return False
        members = parse_struct_members(content, condition["struct_name"])
        for ele in condition["ele_cfg"]:
            actual = members.get(ele["ele_name"])
            if actual is None:
                return False
            if normalize_type(actual) != normalize_type(ele["ele_type"]):
                return False
        return True

    def _check_macro_condition(self, condition: Dict[str, Any]) -> bool:
        macro_cfg = condition["macro_cfg"]
        if (
            len(macro_cfg) == 2
            and any(m["macro_name"] == "SOFTWARE_VERSOIN" for m in macro_cfg)
            and any(m["macro_name"] == "PACESOFTWARE_VERSOIN" for m in macro_cfg)
        ):
            values = {}
            for macro in macro_cfg:
                macro_read = MacroDefinition(self.project, macro["src_file_name"], macro["macro_name"])
                values[macro["macro_name"]] = macro_read.macro_value
            software_ver = values.get("SOFTWARE_VERSOIN")
            pace_software_ver = values.get("PACESOFTWARE_VERSOIN")
            if not software_ver or not pace_software_ver:
                return False
            software_main = software_ver.strip().strip('"').strip()
            pace_full = pace_software_ver.strip().strip('"').strip()
            pace_match = re.match(r"([^-]+-[^-]+-[^-]+)", pace_full)
            pace_main = pace_match.group(1) if pace_match else pace_full
            return software_main == pace_main

        results = []
        for macro in macro_cfg:
            macro_read = MacroDefinition(self.project, macro["src_file_name"], macro["macro_name"])
            if "string_max_length" in macro or "string_min_length" in macro:
                result = macro_read.string_length_in_range(
                    macro.get("string_min_length"),
                    macro.get("string_max_length"),
                )
            elif macro.get("check_exists_only", False):
                result = macro_read.exists
            elif "macro_value" not in macro:
                result = macro_read.exists
            else:
                result = macro_read.is_value_equal(macro["macro_value"])
                if macro_read.macro_name == "SAMPLINGRESISTANCE":
                    result = self.pro_cfg.sample_resistor == self.pro_cfg.sample_resistor_exp
            results.append(result)
        return all(results)

    def _check_code_condition(self, condition: Dict[str, Any]) -> bool:
        results = []
        for code in condition["code_cfg"]:
            rel, content = self.project.read_by_name(code["file_name"])
            expected_flag = code.get("flag", condition.get("flag", True))
            allow_function_not_exist = code.get("allow_function_not_exist", False)
            if content is None:
                result_temp = False
                function_missing = True
            else:
                body = find_function_body(content, code["func_name"])
                function_missing = body is None
                result_temp = False if body is None else keywords_in_order(remove_comments(body), code["key_list"])
            if allow_function_not_exist and function_missing and not result_temp:
                condition_ret = True
            else:
                condition_ret = result_temp == expected_flag
            results.append(condition_ret)
        return all(results)

    def _check_line_condition(self, condition: Dict[str, Any]) -> bool:
        results = []
        for line_cfg in condition["line_cfg"]:
            rel, content = self.project.read_by_name(line_cfg["file_name"])
            expected_flag = line_cfg.get("flag", True)
            if content is None:
                result_temp = False
            else:
                result_temp = any(keywords_in_order(line.strip(), line_cfg["key_list"]) for line in content.splitlines())
            results.append(result_temp == expected_flag)
        return all(results)

    def _check_ewp_version_condition(self, condition: Dict[str, Any]) -> bool:
        for cfg in condition["ewp_cfg"]:
            macro_read = MacroDefinition(self.project, cfg["src_file_name"], cfg["macro_name"])
            if not macro_read.macro_value:
                return False
            pace_version = macro_read.macro_value.strip().strip('"').strip()
            version_match = re.search(r"-(\d+-[\d\.A-Za-z]+-\d+)", pace_version)
            if not version_match:
                return False
            expected_version = version_match.group(1)
            ewp_files = [
                p
                for p in self.project.all_files()
                if p.lower().endswith(".ewp") and "bootloader/" not in p.lower()
            ]
            for ewp_file in ewp_files:
                try:
                    root = ET.fromstring(self.project.read_text(ewp_file))
                except ET.ParseError:
                    continue
                for option in root.findall(".//option"):
                    name_elem = option.find("name")
                    state_elem = option.find("state")
                    if name_elem is None or state_elem is None:
                        continue
                    if name_elem.text != "IlinkOutputFile" or not state_elem.text:
                        continue
                    file_version_match = re.search(r"-(\d+-[\d\.A-Za-z]+-\d+)\.out", state_elem.text)
                    if file_version_match and file_version_match.group(1) == expected_version:
                        return True
            return False
        return True


def parse_struct_members(content: str, struct_name: str) -> Dict[str, str]:
    name = re.sub(r"(typedef\s+)?struct\s+", "", struct_name).strip()
    clean = remove_comments(content)
    pattern = re.compile(
        r"(?:typedef\s+)?struct\s+(?:\w+\s*)?\{([^}]*)\}\s*" + re.escape(name) + r"\s*;",
        re.DOTALL,
    )
    match = pattern.search(clean)
    if not match:
        return {}
    members = {}
    member_pattern = re.compile(r"^\s*([A-Za-z_][\w\s\*]*?)\s+([A-Za-z_]\w*)(\s*\[[^\]]+\])?\s*;", re.MULTILINE)
    for item in member_pattern.finditer(match.group(1)):
        member_type = item.group(1).strip()
        member_name = item.group(2).strip()
        array_part = item.group(3) or ""
        members[member_name] = f"{member_type}{array_part}".strip()
    return members


def normalize_type(type_str: str) -> str:
    type_str = re.sub(r"\s+", " ", type_str.strip())
    type_str = re.sub(r"\s*\*\s*", "*", type_str)
    type_str = re.sub(r"\bconst\b", "", type_str).strip()
    return type_str


def format_condition_detail(condition: Dict[str, Any]) -> str:
    if_type = condition["if_type"]
    if if_type == "file":
        return f"检查文件 '{condition['file_name']}' 是否存在(期望: {'存在' if condition.get('flag', True) else '不存在'})"
    if if_type == "struct":
        details = [f"{ele['ele_name']}(类型应为:{ele['ele_type']})" for ele in condition["ele_cfg"]]
        return f"检查结构体 '{condition['struct_name']}' 定义: {', '.join(details)}"
    if if_type == "macro":
        details = []
        for macro in condition["macro_cfg"]:
            val_info = f"值应为: {macro['macro_value']}" if "macro_value" in macro else "只需存在"
            details.append(f"{macro['macro_name']}(文件:{macro['src_file_name']}, {val_info})")
        return f"检查宏定义: {'; '.join(details)}"
    if if_type == "code":
        details = []
        for code in condition["code_cfg"]:
            keys = " | ".join(code["key_list"])
            details.append(f"在 {code['file_name']} 的 {code['func_name']} 中检查: {keys}")
        return f"检查代码逻辑: {'; '.join(details)}"
    if if_type == "line":
        details = []
        for line in condition["line_cfg"]:
            keys = " | ".join(line["key_list"])
            details.append(f"在 {line['file_name']} 中检查同一行: {keys}")
        return f"检查关键行: {'; '.join(details)}"
    return str(condition)


class CheckListProcessor:
    def __init__(self, url: str, tool_dir: Path, rules_path: Path, revision: str = ""):
        self.url = normalize_url(url)
        self.check_items_config = load_yaml_config(rules_path)
        self.check_items_version = self.check_items_config["version"]
        self.project = RemoteProject(self.url, revision)
        self.project_config = ProjectConfig(self.project, tool_dir)
        self.condition_checker = ConditionChecker(self.project, self.project_config)

    def process_check_items(self) -> List[Dict[str, Any]]:
        results = []
        for item_config in self.check_items_config["checks"]:
            check_item = CheckItem(item_config)
            if not check_item.is_applicable(
                self.project_config.pcb_type,
                self.project_config.afe_type,
                self.project_config.software_ver,
            ):
                results.append(
                    {
                        "id": check_item.id,
                        "description": check_item.description,
                        "result": True,
                        "details": [],
                        "if_list": check_item.if_list,
                        "skipped": True,
                    }
                )
                continue

            conditions = []
            details = []
            for idx, condition in enumerate(check_item.if_list, 1):
                item_result = self.condition_checker.check_condition(condition)
                conditions.append(item_result)
                details.append((idx, item_result))
            final_result = evaluate_conditions(conditions, check_item.if_logic)
            results.append(
                {
                    "id": check_item.id,
                    "description": check_item.description,
                    "result": final_result,
                    "details": details,
                    "if_list": check_item.if_list,
                    "skipped": False,
                }
            )
        return results

    def generate_report(self, results: List[Dict[str, Any]], report_file: Path) -> None:
        failed_items = [item for item in results if not item["result"]]
        with report_file.open("w", encoding="utf-8") as f:
            f.write("=" * 50 + "\n")
            f.write("SVN远程工程代码检查报告\n")
            f.write("=" * 50 + "\n\n")
            f.write("检查方式:\n")
            f.write("-" * 50 + "\n")
            f.write("仅读取 SVN 远端文件内容，未 checkout，未 export 工程代码。\n")
            f.write("-" * 50 + "\n\n")
            f.write("工程特征配置:\n")
            f.write("-" * 50 + "\n")
            f.write(f"PCB类型: {self.project_config.pcb_type}\n")
            f.write(f"AFE类型: {self.project_config.afe_type}\n")
            f.write(f"软件版本: {self.project_config.software_ver}\n")
            f.write(f"电流规格: {self.project_config.current}\n")
            f.write(f"采样电阻个数: {self.project_config.sample_resistor}\n")
            f.write(f"采样电阻预期: {self.project_config.sample_resistor_exp}\n")
            f.write(f"SVN地址: {self.url}\n")
            f.write("-" * 50 + "\n\n")
            f.write("检查结果总览:\n")
            f.write("-" * 50 + "\n")
            f.write(f"总检查项: {len(results)}\n")
            f.write(f"通过项: {len(results) - len(failed_items)}\n")
            f.write(f"失败项: {len(failed_items)}\n")
            f.write("-" * 50 + "\n\n")
            if failed_items:
                f.write("失败项明细:\n")
                f.write("=" * 50 + "\n")
                for idx, item in enumerate(failed_items, 1):
                    f.write(f"{idx}. ID: {item['id']}\n")
                    f.write(f"   描述: {item['description']}\n")
                    f.write("   失败原因:\n")
                    for cond_idx, (_, cond_result) in enumerate(item["details"], 1):
                        if not cond_result:
                            condition = item["if_list"][cond_idx - 1]
                            f.write(f"     - 条件{cond_idx}: {format_condition_detail(condition)}\n")
                f.write("=" * 50 + "\n\n")
            f.write("详细检查结果:\n")
            f.write("=" * 50 + "\n")
            for item in results:
                f.write(f"检查项ID: {item['id']}\n")
                f.write(f"描述: {item['description']}\n")
                f.write(f"结果: {'通过' if item['result'] else '失败'}\n")
                if item.get("skipped"):
                    f.write("说明: 项目无需执行该自检项\n")
                elif not item["result"]:
                    f.write("失败详情:\n")
                    for cond_idx, (_, cond_result) in enumerate(item["details"], 1):
                        condition = item["if_list"][cond_idx - 1]
                        f.write(
                            f"  {cond_idx}. {format_condition_detail(condition)} -> "
                            f"{'满足' if cond_result else '不满足'}\n"
                        )
                f.write("-" * 50 + "\n")


def main() -> int:
    tool_dir = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="户用 SVN 远程自检工具")
    parser.add_argument("url", help="SVN 工程地址")
    parser.add_argument("-r", "--revision", default="", help="指定 SVN revision")
    parser.add_argument("--rules", default=str(tool_dir / "checkList_item_cfg.yml"), help="明文检查规则 YAML")
    parser.add_argument("--report", default="", help="报告输出路径")
    args = parser.parse_args()

    rules_path = Path(args.rules)
    report_path = Path(args.report) if args.report else tool_dir / f"check_report_svn_remote_{datetime.datetime.now():%Y%m%d_%H%M%S}.txt"

    processor = CheckListProcessor(args.url, tool_dir, rules_path, args.revision)
    results = processor.process_check_items()
    processor.generate_report(results, report_path)
    failed_count = sum(1 for item in results if not item["result"])
    print(f"详细报告已生成: {report_path}")
    print(f"总检查项: {len(results)}")
    print(f"失败项: {failed_count}")
    return 1 if failed_count else 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        print(f"错误: {exc}", file=sys.stderr)
        sys.exit(2)
