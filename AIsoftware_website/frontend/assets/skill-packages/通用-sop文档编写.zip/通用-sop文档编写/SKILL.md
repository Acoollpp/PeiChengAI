---
name: 通用-sop文档编写
description: 用于编写中文 SOP、操作手册、标准流程文档，或把粗略步骤、截图、流程图、会议记录整理成可复用、可执行、可检查的 SOP 文档。
---

# SOP Document Writer

## Overview

This skill helps produce Chinese SOP documents in a DingTalk-friendly Markdown format.
It turns rough process notes, screenshots, flowcharts, and informal descriptions into structured SOPs with clear steps, controls, and acceptance criteria.

## Input Checklist

Before writing, identify:
- business topic or task name
- source material type: rough notes, process description, screenshots, flowchart, or draft SOP
- target readers: operators, trainees, reviewers, or managers
- any required sections, screenshots, or wording style

If key information is missing, ask focused follow-up questions first.

## Output Format

Default to DingTalk-compatible Markdown.

Follow these constraints:
- keep heading depth within 4 levels
- avoid Markdown task-list syntax like `- [ ]` and `- [x]`
- keep table cells to single-line plain text where possible
- do not nest Markdown formatting inside code blocks
- use image placeholders instead of ASCII diagrams

Use this placeholder format for screenshots or diagrams:

> [Image Placeholder] Insert {image description} here

## Recommended Structure

Write the SOP using this structure unless the user explicitly asks for another one:

1. Overall Description
1.1 Purpose
1.2 Scope
1.3 Writing Principles

2. Core Procedure
2.1 Task Description
2.2 Step-by-Step Process
2.3 Key Control Points
2.4 Efficiency Suggestions
2.5 Common Mistakes and Risk Warnings

3. Deliverables and Acceptance Criteria

4. Application and Maintenance
4.1 Usage Scenarios
4.2 Update Mechanism

## Writing Guidance

### 1. Overall Description

For `1.1 Purpose`, clearly state the value of the SOP and make sure the outcome is executable, reusable, checkable, and traceable.

For `1.2 Scope`, specify which team, role, or business process the SOP applies to.

For `1.3 Writing Principles`, keep these ideas:
- one SOP should focus on one task
- write toward deliverable outcomes
- avoid relying on personal experience only

### 2. Core Procedure

For `2.1 Task Description`, answer:
- when this task is triggered
- what target result is expected
- how completion is judged

For `2.2 Step-by-Step Process`:
- organize steps in chronological order
- state actor, tool, action, and output for each phase
- if there are conditional branches, present them in a table

For `2.3 Key Control Points`:
- separate mandatory actions from prohibited actions
- focus on high-risk and high-impact controls
- keep the list concise

For `2.4 Efficiency Suggestions`:
- state where the suggestion applies
- explain what to do and why it improves efficiency
- list reusable resources such as templates, scripts, or tools when available

For `2.5 Common Mistakes and Risk Warnings`:
- use a table with columns: number, error scenario, cause, avoidance method
- prefer real and practical failure patterns

### 3. Deliverables and Acceptance Criteria

List the expected outputs and include concrete, verifiable completion criteria.

### 4. Application and Maintenance

Cover:
- daily execution
- onboarding and training
- incident review and accountability
- when the SOP should be updated after process or tool changes

## Quality Check

Before finalizing, verify:
- all required sections are present
- numbering is complete and consistent
- key controls are specific and actionable
- risks and common mistakes are concrete
- acceptance criteria are testable
- all required screenshots or diagrams have placeholders
- language is concise, professional, and unambiguous
